@echo off
if "%OS%"=="Windows_NT" goto windows
call DOSUNIN.BAT %1
goto done
:windows
call "%~dp0WINUNINS.BAT" %*
:done
