@echo off
if "%OS%"=="Windows_NT" goto windows
call DOSINST.BAT %1
goto done
:windows
call "%~dp0WINSTALL.BAT" %*
:done
