NOVEMBER RAIN V4 - DOSBOX INSTALLER FIX

The previous batch used Windows CMD commands. This release includes a separate
DOSBox-compatible installer and uninstaller. All game resources are identical
to V3, including the by Alain il Professore credit and approved 3D guitar.

1. Close Stunts. Extract the ENTIRE ZIP into the Stunts game directory.
2. In DOSBox, change to that directory. Type INSTALLE and press Enter.
3. Start the game as usual. Select car ROSE and track NORAIN2.
4. To restore the previous files, type DESINST in the same DOSBox directory.

Keep the PAYLOAD folder, NRCOPY.COM, NRABS.TAG, NRREADY.TAG and NRDOS.BAK.
Backups are completed and verified before changing any game resources.
Re-running the installer keeps the original DOS backup.

Windows: double-click INSTALLE.bat as before. DESINST.bat restores the backup.
If a previous Windows install is active (NRRAIN.BAK/READY), uninstall it from
Windows before switching to DOSBox installation. For an active DOSBox install,
restore from DOSBox before switching to Windows installation.
The first-run SETLOCAL error alone did not constitute a successful install.

Tested in DOSBox 0.74-3: install, repeat install preserving the original backup,
exact uninstall, missing payload, invalid backup, active Windows backup guard,
and NRCOPY binary copy/verification. Windows CMD was not executed here.
