# Ferrari 643 F1 1991 — V14

Corrections du casque et du clignotement des rapports, depuis la V13 livrée.

- Casque : le sommet auxiliaire de taille est réorienté verticalement sur car0,
  car1 et car2. Le moteur utilise ce sommet dans sa profondeur moyenne : son
  ancien décalage latéral pouvait faire passer le bas du casque derrière la caisse.
  Centre, diamètre, primitive sphérique et onze couleurs sont conservés.
- Rapports : GBOX est recouvert dans V13 par INS2 et les poses du volant. Ces
  deux copies opaques sont recadrées pour laisser le chiffre indépendant.
- La barre RPM conserve onze segments et 128 valeurs, avec une largeur de
  33 pixels au lieu de 44. Le cadran des rapports et les chiffres ne bougent pas.
- Les 15 premières lignes du rectangle des poses deviennent fixes dans DASH ;
  cela normalise 37/36 pixels des poses gauche/droite dans cette petite zone.
  Tous les pixels animés du volant à partir de Y161 sont conservés.
- Moteur, rapports, étagement, masse, freinage et comportement : octets identiques V13.

## Installation

Remplacer les QUATRE fichiers ensemble : STDAF643.VSH, STDBF643.VSH,
CARF643.RES et STF643.3SH. Le CAR change uniquement pour l'affichage du régime.
Extraire le dossier dans Stunts puis INSTALL_WIN.CMD / REMOVE_WIN.CMD sous
Windows ; sous DOS/DOSBox entrer dans ce dossier puis INSTALL.BAT / REMOVE.BAT.
Les installateurs conservent les fichiers remplacés et écartent les variantes
compressées concurrentes. ORIGINAL_V13 conserve les quatre binaires précédents.

## Contrôles et limites

648 compositions suivent l'ordre réel GEAR puis WHEEL puis INSTRUMENT puis DOT :
le rapport est effacé dans 648 cas V13, et préservé dans les 648 cas V14.
Une séquence de 768 images le conserve sans le redessiner à chaque image.
128 valeurs du régime vérifient un remplissage monotone. VSH et masques relus.
3264 orientations sont calculées par la transformation/file native C. À inclinaison
nulle, car1/car2 améliorent 13 vues chacun, sans perdre de pixels sur les autres.
La surface visible n'est pas un oracle d'occlusion : la carrosserie doit toujours
cacher le pilote depuis certains angles, et des limites du tri persistent en forte
inclinaison. Aucun nouveau test DOSBox n'a été effectué pour cette V14.

Le chiffre reste temporaire selon le délai natif de changement de rapport.
Cette version corrige l'effacement parasite, sans supprimer ce délai. Les phases
intermédiaires du masque mobile restent celles de V13. N/R restent non sélectionnables.
Les aperçus sont des compositions ou projections de contrôle, pas des captures DOS.

Auteur : Alain il Professore — Hyperion Racing Team.

## Correction du texte descriptif — 11 novembre 2026

La description complète de sept lignes se termine désormais par `by Alain il Professore]`. Le `]` final déclenche l’affichage de la dernière ligne. Seule la ressource edes change ; simd et les trois fichiers graphiques restent identiques à la V14 livrée. En-tête et empreintes sont mis à jour. La reconstruction reproduit les quatre binaires. Comportement du lecteur de texte vérifié dans le désassemblage original ; aucun nouveau test complet DOSBox.
