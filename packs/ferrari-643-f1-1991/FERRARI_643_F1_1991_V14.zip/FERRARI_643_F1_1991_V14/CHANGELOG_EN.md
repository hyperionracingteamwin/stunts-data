# Ferrari 643 F1 1991 — V14

Helmet sorting and gear-display refresh fix, based on delivered V13.

The sphere size endpoint is rotated vertically on car0/car1/car2 to remove its
lateral average-depth bias. Sphere center, diameter and all eleven paints remain.
GBOX was inside both opaque wheel and instrument refresh rectangles. INS2 now
ends before GBOX and the wheel rectangles start below it. The 11-segment RPM
bar is 33 rather than 44 pixels wide; all 128 RPM states remain. 37/36 pixels
in the upper turned-wheel rows become fixed center artwork; all animated wheel
pixels from Y161 downward remain exact. Gear position/atlas and speed stay exact.
Physics and transmission bytes remain identical to V13.

Install all four binaries together. Extract the package into a Stunts subfolder;
use INSTALL_WIN.CMD / REMOVE_WIN.CMD on Windows, or enter that subfolder in
DOS/DOSBox and run INSTALL.BAT / REMOVE.BAT. Backups are retained, including
ORIGINAL_V13. Conflicting packed resource variants are handled by the installers.

Validation: 648 native-order compositions preserve the gear (all 648 V13 cases
erase it); a 768-frame trace preserves it without redrawing it every frame.
128 monotonic RPM states and 3264 native C projection cases were checked.
13 level views improve for each race LOD without level-view coverage regression.
Coverage is not a ground-truth occlusion test. Steep-angle sorting limits remain.
No new DOSBox run for V14. Previews are simulations/projections, not DOS captures.
The stock gear timeout and intermediate atlas animation remain; neutral/reverse
are still not selectable. This fixes competing refresh writes, not that timeout.

By Alain il Professore — Hyperion Racing Team.
