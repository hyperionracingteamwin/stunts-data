# Ferrari 643 F1 1991 — V14

Corrections du casque et du clignotement des rapports, depuis la V13 livrée.

- Casque : le sommet auxiliaire de taille est réorienté verticalement sur car0,
  car1 et car2. Le moteur utilise ce sommet dans sa profondeur moyenne : son
  ancien décalage latéral pouvait faire passer le bas du casque derrière la caisse.
  Centre, diamètre, primitive sphérique et onze couleurs sont conservés.
- Rapports : GBOX est recouvert dans V13 par INS2 et les poses du volant. Ces
  deux copies opaques sont recadrées pour laisser le chiffre indépendant.
- La barre RPM conserve onze segments et 128 valeurs, avec une largeur de
  33 pixels au lieu de 44. Le cadran des rapports et les chiffres ne bougent pas.
- Les 15 premières lignes du rectangle des poses deviennent fixes dans DASH ;
  cela normalise 37/36 pixels des poses gauche/droite dans cette petite zone.
  Tous les pixels animés du volant à partir de Y161 sont conservés.
- Moteur, rapports, étagement, masse, freinage et comportement : octets identiques V13.