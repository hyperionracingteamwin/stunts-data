# Ferrari 643 F1 1991 — V14

Corrections du casque et du clignotement des rapports, depuis la V13 livrée.

- Casque : le sommet auxiliaire de taille est réorienté verticalement sur car0,
  car1 et car2. Le moteur utilise ce sommet dans sa profondeur moyenne : son
  ancien décalage latéral pouvait faire passer le bas du casque derrière la caisse.
  Centre, diamètre, primitive sphérique et onze couleurs sont conservés.
- Rapports : GBOX est recouvert dans V13 par INS2 et les poses du volant. Ces
  deux copies opaques sont recadrées pour laisser le chiffre indépendant.
- La barre RPM conserve onze segments et 128 valeurs, avec une largeur de
  33 pixels au lieu de 44. Le cadran des rapports et les chiffres ne bougent pas.
- Les 15 premières lignes du rectangle des poses deviennent fixes dans DASH ;
  cela normalise 37/36 pixels des poses gauche/droite dans cette petite zone.
  Tous les pixels animés du volant à partir de Y161 sont conservés.
- Moteur, rapports, étagement, masse, freinage et comportement : octets identiques V13.

## Correction du texte descriptif — 11 novembre 2026

La description complète de sept lignes se termine désormais par `by Alain il Professore]`. Le `]` final déclenche l’affichage de la dernière ligne. Seule la ressource edes change ; simd et les trois fichiers graphiques restent identiques à la V14 livrée. En-tête et empreintes sont mis à jour. La reconstruction reproduit les quatre binaires. Comportement du lecteur de texte vérifié dans le désassemblage original ; aucun nouveau test complet DOSBox.

## Correction de la ligne supérieure — 11 novembre 2026

Seule la ressource roof factice de 1x1 pixel, placée en (319,199), est retirée de STDAF643.VSH. Sa hauteur réservait à tort une ligne non rafraîchie en haut de l’écran. Sans roof, la vue 3D commence à y=0, comme pour PMIN et FW12. Les 14 autres blocs STDA, dont dash, dast/dasm, ins2, gbox et les poses du volant, sont identiques. CAR avec edes corrigé, STDB et 3SH inchangés. Masques et reconstruction vérifiés ; aucun test visuel DOSBox. Voir ROOF_FIX_VALIDATION.json.
