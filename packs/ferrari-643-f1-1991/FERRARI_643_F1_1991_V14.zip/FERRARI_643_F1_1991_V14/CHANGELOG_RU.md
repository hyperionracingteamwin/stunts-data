# Ferrari 643 — V14

Исправлены боковое смещение глубины сферы шлема и перекрытие индикатора передачи
областями перерисовки приборов и руля. Размер, центр и 11 цветов шлема сохранены.
Полоса оборотов содержит 11 сегментов и 128 состояний; ширина уменьшена до 33 пикселей.
Физика и передаточные числа V13 сохранены. Устанавливать все четыре файла вместе.
INSTALL_WIN.CMD / REMOVE_WIN.CMD — Windows; INSTALL.BAT / REMOVE.BAT — DOS.
Исходные файлы находятся в ORIGINAL_V13. Проверены 648 композиций, 768 последовательных
кадров и 3264 проекции. Новый тест DOSBox не выполнен. Время исчезновения передачи
остаётся штатным; ограничения сортировки при больших наклонах сохраняются.

## Description text fix — 11 November 2026

The seven-line description now ends with `by Alain il Professore]`. The final separator makes the original menu draw the last line. Only edes changed; physics and graphics are unchanged. Checksums and portable rebuild sources are updated. See EDES_FIX_VALIDATION.json; no new full DOSBox playtest.

## Open-cockpit top scanline fix — 11 November 2026

Removed only the dummy 1x1 roof from STDAF643.VSH so the original 3D viewport begins at y=0. All other STDA resource blocks, CAR with corrected edes, STDB and 3SH are unchanged. See ROOF_FIX_VALIDATION.json. No live DOSBox test.
