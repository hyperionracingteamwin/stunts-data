"""Ferrari 643 V14: sphere sorting and disjoint native dashboard writes."""
from pathlib import Path
import sys,struct,json,copy,shutil,hashlib
import numpy as np
from PIL import Image,ImageDraw
W=Path(__file__).resolve().parent;ROOT=W.parent
PORTABLE=(W/'native_utils.py').exists();BASE=W if PORTABLE else ROOT/'work_f643_v13'
sys.path.insert(0,str(BASE))
from native_utils import unpack,pack,pix,bmp,info,sha,PAL,native_blit
sys.path.insert(0,str(BASE/'tools'))
from shape_io import shape,save_shape
P=W.parent if PORTABLE else W/'package/FERRARI_643_F1_1991_V14';SRC=P/'ORIGINAL_V13' if PORTABLE else ROOT/'work_f643_v13/package/FERRARI_643_F1_1991_V13'
P.mkdir(parents=True,exist_ok=True);(P/'ORIGINAL_V13').mkdir(exist_ok=True);(P/'PREVIEWS').mkdir(exist_ok=True)
names=['STDAF643.VSH','STDBF643.VSH','CARF643.RES','STF643.3SH']
original={n:(SRC/n).read_bytes() for n in names}
for n in names:(P/'ORIGINAL_V13'/n).write_bytes(original[n])
a=unpack(original[names[0]]);b=unpack(original[names[1]]);c=unpack(original[names[2]]);rs=unpack(original[names[3]])
oa=copy.deepcopy(a);ob=copy.deepcopy(b);s=bytearray(c['simd'])
# Compact the same eleven progressive segments so INS2 can stop before GBOX.
# All speed digits and GBOX remain at their V13 screen coordinates.
def bar(im,x,y):
 d=ImageDraw.Draw(im);d.rectangle((138-x,148-y,181-x,150-y),fill=20)
 for xx in range(138,171,3):d.rectangle((xx-x,148-y,xx+1-x,150-y),fill=24)
 return im
for k in ['dash','dast','whl1','whl2','whl3','ins2']:
 m=info(a[k]);im=bar(pix(a[k],'L'),m['x'],m['y']);a[k]=a[k][:16]+im.tobytes()+a[k][16+m['w']*m['h']:]
# INS2's opaque rectangular copy used to erase GBOX. Restrict its right edge.
for k in ['ins1','inm1','ins2','ins3','inm3']:
 m=info(a[k]);a[k]=bmp(a[k],pix(a[k],'L').crop((0,0,40,m['h'])),m['x'],m['y'],m['ax'],m['ay'])
# The top fifteen wheel rows are static panel/rim. Baking them in DASH avoids
# clearing the independently animated gear on a wheel-pose change. Below Y161
# every wheel pixel remains identical to V13. Only 37/36 upper pixels of the
# turned variants are normalized to the center artwork.
normalized={}
center_upper=np.array(pix(a['whl2'],'L'))[:15].copy()
for k in ['whl1','whl2','whl3']:
 m=info(a[k]);im=pix(a[k],'L');normalized[k]=int(np.count_nonzero(np.array(im)[:15]!=center_upper))
 a[k]=bmp(a[k],im.crop((0,15,m['w'],m['h'])),m['x'],m['y']+15,m['ax'],m['ay']-15)
redline=struct.unpack_from('<H',s,12)[0]
for i in range(128):s[516+2*i]=4+round(32*min(i*128/redline,1))
dot=Image.new('L',(33,3));mask=Image.new('L',(33,3),255)
for x in range(33):
 for y in range(3):
  if x%3==2:dot.putpixel((x,y),20);mask.putpixel((x,y),0)
  else:dot.putpixel((x,y),16);mask.putpixel((x,y),15)
for k,im in [('dot ',dot),('dota',mask),('dot1',Image.new('L',(33,3))),('dot2',Image.new('L',(33,3)))]:
 m=info(b[k]);b[k]=bmp(b[k],im,m['x'],m['y'],m['ax'],m['ay'])
c['simd']=bytes(s)
# Full description; original menu flushes a line only on ']'.
c['edes']=b'FERRARI 643 F1-91]ALAIN PROST #27]V12 3.5L - 710 HP]Mid Engine, RW Drive]3499cc V12]0-60 mph: 2.30 sec]by Alain il Professore]\x00'
helmet={}
for k in ['car0','car1','car2']:
 sh=shape(rs[k]);pr=next(p for p in sh['p'] if p['t']==11);ci,ri=pr['ix'];center=sh['v'][ci].copy();old=sh['v'][ri].copy();diameter=round(sum((x-y)**2 for x,y in zip(center,old))**.5)
 assert sum(ri in p['ix'] for p in sh['p'])==1
 sh['v'][ri]=[center[0],center[1]+diameter,center[2]];rs[k]=save_shape(sh)
 helmet[k]={'center_unchanged':center,'size_vertex_before':old,'size_vertex_after':sh['v'][ri],'diameter_unchanged':diameter,'all_11_helmet_colors':pr['m']}
result=dict(zip(names,[pack(a),pack(b),pack(c),pack(rs)]))
for n,data in result.items():(P/n).write_bytes(data)
# Physical/transmission data and all palettes / atlas blocks must remain exact.
changes=[i for i,(x,y) in enumerate(zip(c['simd'],unpack(original[names[2]])['simd'])) if x!=y]
assert all(516<=i<772 and i%2==0 for i in changes)
for k in a:
 if k not in {'dash','dast','whl1','whl2','whl3','ins1','inm1','ins2','ins3','inm3'}:assert a[k]==oa[k],k
for k in b:
 if k not in {'dot ','dota','dot1','dot2'}:assert b[k]==ob[k],k
assert a['gbox']==oa['gbox'] and b['gnob']==ob['gnob'] and b['gnab']==ob['gnab']
audit={'base':'delivered V13 / Library version 7','helmet':helmet,'native_write_conflict_before':{'gear':[177,154,182,161],'instruments':[134,144,188,164],'wheel':[90,146,230,200]},'native_write_regions_after':{'gear':[177,154,182,161],'instruments':[134,144,174,164],'wheel':[90,161,230,200],'RPM_stencil':[138,148,171,151]},'RPM_segments_preserved':11,'RPM_points_preserved':128,'upper_wheel_pixels_normalized':normalized,'CAR_display_only_changed_offsets':changes,'physics_and_gear_ratios_byte_identical':True,'gear_atlas_GBOX_digits_palettes_and_alpha_masks_unchanged':True,'changed_STDA':[k for k in a if a[k]!=oa[k]],'changed_STDB':[k for k in b if b[k]!=ob[k]],'sha256':{n:sha(v) for n,v in result.items()}}
(P/'AUDIT_V14.json').write_text(json.dumps(audit,indent=2))
for n in ['INSTALL_WIN.CMD','REMOVE_WIN.CMD','SETUP_WIN.ps1','INSTALL.BAT','REMOVE.BAT']:
 if (SRC/n).exists():(P/n).write_bytes((SRC/n).read_bytes().replace(b'V13',b'V14'))
 else:assert PORTABLE and (P/n).is_file()
print(json.dumps({'package':str(P),'changed_STDA':audit['changed_STDA'],'changed_STDB':audit['changed_STDB'],'mechanics':'unchanged','upper_wheel_pixels_normalized':normalized}))
