from pathlib import Path
import json,shutil,zipfile,hashlib,sys,copy
from PIL import Image,ImageDraw
W=Path(__file__).resolve().parent;ROOT=W.parent;P=W/'package/FERRARI_643_F1_1991_V14'
sys.path.insert(0,str(ROOT/'work_f643_v13'));from native_draw import draw
sys.path.insert(0,str(ROOT/'work_f643_v13/tools'));from shape_io import unpack,shape
assert json.loads((P/'VALIDATION_V14.json').read_text())['status']=='PASS'
for k in ['car0','car1','car2']:
 for variant in ['before','after']:
  shutil.copy2(W/(k+'_'+variant+'.png'),P/'PREVIEWS'/(k+'_'+variant+'_NATIVE_PROJECTION.png'))
# A close side comparison of the actual race model, where the lower hemisphere
# previously lost pixels. Scale only by integer nearest-neighbour factors.
sheet=Image.new('RGB',(1280,460),'#20252b');dd=ImageDraw.Draw(sheet)
for j,variant in enumerate(['before','after']):
 rows=json.loads((W/('car1_'+variant+'.json')).read_text());row=next(r for r in rows if r['yaw']==896 and r['pitch']==0)
 sh=shape(unpack((W/('car1_'+variant+'.3SH')).read_bytes())['car0'])
 rs=unpack((P/('ORIGINAL_V13/STF643.3SH' if variant=='before' else 'STF643.3SH')).read_bytes());orig=shape(rs['car1']);mapping={p['i']+1+(p['i']>=44):p for p in orig['p']}
 row=copy.deepcopy(row)
 for p in row['queue']:p['material']=mapping[p['material']]['m'][8]
 im=draw(row);sheet.paste(im.resize((640,400),Image.Resampling.NEAREST),(j*640,30));dd.text((j*640+10,8),'V13' if j==0 else 'V14',fill='white')
sheet.save(P/'PREVIEWS/CASQUE_AVANT_APRES.png')
readmes={
'FR':'''# Ferrari 643 F1 1991 — V14

Corrections du casque et du clignotement des rapports, depuis la V13 livrée.

- Casque : le sommet auxiliaire de taille est réorienté verticalement sur car0,
  car1 et car2. Le moteur utilise ce sommet dans sa profondeur moyenne : son
  ancien décalage latéral pouvait faire passer le bas du casque derrière la caisse.
  Centre, diamètre, primitive sphérique et onze couleurs sont conservés.
- Rapports : GBOX est recouvert dans V13 par INS2 et les poses du volant. Ces
  deux copies opaques sont recadrées pour laisser le chiffre indépendant.
- La barre RPM conserve onze segments et 128 valeurs, avec une largeur de
  33 pixels au lieu de 44. Le cadran des rapports et les chiffres ne bougent pas.
- Les 15 premières lignes du rectangle des poses deviennent fixes dans DASH ;
  cela normalise 37/36 pixels des poses gauche/droite dans cette petite zone.
  Tous les pixels animés du volant à partir de Y161 sont conservés.
- Moteur, rapports, étagement, masse, freinage et comportement : octets identiques V13.

## Installation

Remplacer les QUATRE fichiers ensemble : STDAF643.VSH, STDBF643.VSH,
CARF643.RES et STF643.3SH. Le CAR change uniquement pour l'affichage du régime.
Extraire le dossier dans Stunts puis INSTALL_WIN.CMD / REMOVE_WIN.CMD sous
Windows ; sous DOS/DOSBox entrer dans ce dossier puis INSTALL.BAT / REMOVE.BAT.
Les installateurs conservent les fichiers remplacés et écartent les variantes
compressées concurrentes. ORIGINAL_V13 conserve les quatre binaires précédents.

## Contrôles et limites

648 compositions suivent l'ordre réel GEAR puis WHEEL puis INSTRUMENT puis DOT :
le rapport est effacé dans 648 cas V13, et préservé dans les 648 cas V14.
Une séquence de 768 images le conserve sans le redessiner à chaque image.
128 valeurs du régime vérifient un remplissage monotone. VSH et masques relus.
3264 orientations sont calculées par la transformation/file native C. À inclinaison
nulle, car1/car2 améliorent 13 vues chacun, sans perdre de pixels sur les autres.
La surface visible n'est pas un oracle d'occlusion : la carrosserie doit toujours
cacher le pilote depuis certains angles, et des limites du tri persistent en forte
inclinaison. Aucun nouveau test DOSBox n'a été effectué pour cette V14.

Le chiffre reste temporaire selon le délai natif de changement de rapport.
Cette version corrige l'effacement parasite, sans supprimer ce délai. Les phases
intermédiaires du masque mobile restent celles de V13. N/R restent non sélectionnables.
Les aperçus sont des compositions ou projections de contrôle, pas des captures DOS.

Auteur : Alain il Professore — Hyperion Racing Team.
''',
'EN':'''# Ferrari 643 F1 1991 — V14

Helmet sorting and gear-display refresh fix, based on delivered V13.

The sphere size endpoint is rotated vertically on car0/car1/car2 to remove its
lateral average-depth bias. Sphere center, diameter and all eleven paints remain.
GBOX was inside both opaque wheel and instrument refresh rectangles. INS2 now
ends before GBOX and the wheel rectangles start below it. The 11-segment RPM
bar is 33 rather than 44 pixels wide; all 128 RPM states remain. 37/36 pixels
in the upper turned-wheel rows become fixed center artwork; all animated wheel
pixels from Y161 downward remain exact. Gear position/atlas and speed stay exact.
Physics and transmission bytes remain identical to V13.

Install all four binaries together. Extract the package into a Stunts subfolder;
use INSTALL_WIN.CMD / REMOVE_WIN.CMD on Windows, or enter that subfolder in
DOS/DOSBox and run INSTALL.BAT / REMOVE.BAT. Backups are retained, including
ORIGINAL_V13. Conflicting packed resource variants are handled by the installers.

Validation: 648 native-order compositions preserve the gear (all 648 V13 cases
erase it); a 768-frame trace preserves it without redrawing it every frame.
128 monotonic RPM states and 3264 native C projection cases were checked.
13 level views improve for each race LOD without level-view coverage regression.
Coverage is not a ground-truth occlusion test. Steep-angle sorting limits remain.
No new DOSBox run for V14. Previews are simulations/projections, not DOS captures.
The stock gear timeout and intermediate atlas animation remain; neutral/reverse
are still not selectable. This fixes competing refresh writes, not that timeout.

By Alain il Professore — Hyperion Racing Team.
''',
'RU':'''# Ferrari 643 — V14

Исправлены боковое смещение глубины сферы шлема и перекрытие индикатора передачи
областями перерисовки приборов и руля. Размер, центр и 11 цветов шлема сохранены.
Полоса оборотов содержит 11 сегментов и 128 состояний; ширина уменьшена до 33 пикселей.
Физика и передаточные числа V13 сохранены. Устанавливать все четыре файла вместе.
INSTALL_WIN.CMD / REMOVE_WIN.CMD — Windows; INSTALL.BAT / REMOVE.BAT — DOS.
Исходные файлы находятся в ORIGINAL_V13. Проверены 648 композиций, 768 последовательных
кадров и 3264 проекции. Новый тест DOSBox не выполнен. Время исчезновения передачи
остаётся штатным; ограничения сортировки при больших наклонах сохраняются.
'''}
for lang,txt in readmes.items():
 (P/f'README_{lang}.md').write_text(txt,encoding='utf-8')
 (P/f'CHANGELOG_{lang}.md').write_text(txt.split('\n\n## Installation')[0] if lang=='FR' else txt,encoding='utf-8')
S=P/'SOURCES';S.mkdir(exist_ok=True);(S/'tools').mkdir(exist_ok=True);(S/'references').mkdir(exist_ok=True)
for n in ['build_v14.py','validate_v14.py','probe_helmet.py','package_v14.py']:shutil.copy2(W/n,S/n)
for n in ['native_utils.py','native_draw.py','inspect_cockpit.py']:shutil.copy2(ROOT/'work_f643_v13'/n,S/n)
for n in ['shape_io.py','stda_maker.py','run_review.mjs','review.wasm']:shutil.copy2(ROOT/'work_f643_v13/tools'/n,S/'tools'/n)
for n in ['defaults.conf','stressed-vga-palette.txt']:
 src=ROOT/'work_f643_v13/references'/n
 if not src.exists():src=ROOT/'work_f643_v3/references'/n
 shutil.copy2(src,S/'references'/n)
(S/'tools/native/vendor').mkdir(parents=True,exist_ok=True);shutil.copy2(ROOT/'work_f643_v13/tools/native/vendor/full_data.c',S/'tools/native/vendor/full_data.c')
(S/'REBUILD.md').write_text('''Reconstruction requires Python 3 + Pillow + NumPy, and Node.js for native queue checks.
From the extracted package, run:
  python SOURCES/build_v14.py
  python SOURCES/probe_helmet.py
  python SOURCES/validate_v14.py
The scripts detect the portable folder layout. ORIGINAL_V13 must remain present.
build_v14.py deterministically reconstructs the four top-level binaries.
probe_helmet.py generates comparison queues in SOURCES; validate_v14.py uses them.
review.wasm is the existing V13 C-transform review binary; no game executable is included.
''')
for n in ['STDAF643.VSH','STDBF643.VSH','CARF643.RES','STF643.3SH']:
 assert unpack((P/n).read_bytes())
manifest=[]
for f in sorted(P.rglob('*')):
 if f.is_file() and '__pycache__' not in f.parts and f.name!='CONTENTS_SHA256.txt':manifest.append(hashlib.sha256(f.read_bytes()).hexdigest()+'  '+f.relative_to(P).as_posix())
(P/'CONTENTS_SHA256.txt').write_text('\n'.join(manifest)+'\n')
dest=W/'FERRARI_643_F1_1991_V14.zip'
with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED,9) as z:
 for f in sorted(P.rglob('*')):
  if f.is_file() and '__pycache__' not in f.parts:z.write(f,f.relative_to(P.parent))
with zipfile.ZipFile(dest) as z:
 assert z.testzip() is None
 for name in ['STDAF643.VSH','STDBF643.VSH','CARF643.RES','STF643.3SH']:assert z.read(P.name+'/'+name)==(P/name).read_bytes()
 count=len(z.namelist())
print(json.dumps({'zip':str(dest),'files':count,'bytes':dest.stat().st_size,'CRC':'PASS','sha256':hashlib.sha256(dest.read_bytes()).hexdigest()}))
