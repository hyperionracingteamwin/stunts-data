Reconstruction requires Python 3 + Pillow + NumPy, and Node.js for native queue checks.
From the extracted package, run:
  python SOURCES/build_v14.py
  python SOURCES/probe_helmet.py
  python SOURCES/validate_v14.py
The scripts detect the portable folder layout. ORIGINAL_V13 must remain present.
build_v14.py deterministically reconstructs the four top-level binaries.
probe_helmet.py generates comparison queues in SOURCES; validate_v14.py uses them.
review.wasm is the existing V13 C-transform review binary; no game executable is included.

The edes text fix is integrated in build_v14.py and checked by validate_v14.py.
See ../EDES_FIX_VALIDATION.json for the text-only patch checks.
