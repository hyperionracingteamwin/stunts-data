from pathlib import Path
import sys,struct,json,itertools
import numpy as np
from PIL import Image,ImageDraw
W=Path(__file__).resolve().parent;ROOT=W.parent
PORTABLE=(W/'native_utils.py').exists();BASE=W if PORTABLE else ROOT/'work_f643_v13'
sys.path.insert(0,str(BASE))
from native_utils import unpack,pack,pix,info,VSH,native_blit
from inspect_cockpit import pal
sys.path.insert(0,str(BASE/'tools'))
from shape_io import shape
P=W.parent if PORTABLE else W/'package/FERRARI_643_F1_1991_V14';OLD=P/'ORIGINAL_V13'
def load(p):return [unpack((p/n).read_bytes()) for n in ['STDAF643.VSH','STDBF643.VSH','CARF643.RES']]
def static(a):
 cv=Image.new('L',(320,200),9);d=ImageDraw.Draw(cv);d.rectangle((0,95,319,199),fill=27);d.polygon([(145,95),(175,95),(280,199),(40,199)],fill=8)
 for k,op in [('dash','COPY'),('dasm','AND'),('dast','OR'),('whl2','COPY')]:native_blit(cv,a,k,op)
 return cv
def gear(cv,a,b,s,g):
 gm=info(a['gbox']);x,y=struct.unpack_from('<hh',s,28+g*4);native_blit(cv,a,'gbox')
 for k,op in [('gnab','AND'),('gnob','OR')]:
  m=info(b[k]);sp=pix(b[k],'L');dest=Image.new('L',(gm['w'],gm['h']),255 if op=='AND' else 0);dest.paste(sp,(x-m['ax'],y-m['ay']))
  dst=np.array(cv.crop((gm['x'],gm['y'],gm['x']+gm['w'],gm['y']+gm['h'])));arr=np.array(dest);res=dst&arr if op=='AND' else dst|arr
  cv.paste(Image.fromarray(res),(gm['x'],gm['y']))
 return cv
def instruments(cv,a,b,s,rpm,speed,pose,wheel=True):
 if wheel:native_blit(cv,a,pose)
 im=pix(a['ins2'],'L');d=ImageDraw.Draw(im);i=min(127,rpm//128);d.line([struct.unpack_from('<hh',s,510),tuple(s[516+2*i:518+2*i])],fill=15)
 for j,ch in enumerate(str(speed).rjust(3)):
  if ch!=' ':
   # Digits are OR sprites in the actual game, not opaque replacement blits.
   di=pix(b['dig'+ch],'L');x,y=s[302+2*j:304+2*j];box=(x,y,x+di.width,y+di.height);im.paste(Image.fromarray(np.array(im.crop(box))|np.array(di)),(x,y))
 if pose!='whl2':im=Image.fromarray((np.array(im)&np.array(pix(a['inm'+pose[-1]],'L')))|np.array(pix(a['ins'+pose[-1]],'L')))
 m=info(a['ins2']);cv.paste(im,(m['x'],m['y']));native_blit(cv,b,'dota','AND');native_blit(cv,b,'dot ','OR');return cv
def cropgear(cv,a):
 m=info(a['gbox']);return cv.crop((m['x'],m['y'],m['x']+m['w'],m['y']+m['h'])).tobytes()
a,b,c=load(P);s=c['simd'];oa,ob,oc=load(OLD);os=oc['simd'];testcount=0;old_failures=0
for g,pose,rpm,speed in itertools.product(range(1,7),['whl1','whl2','whl3'],[2944,6528,10496,13056],[0,9,10,99,100,165,199,200,255]):
 cv=gear(static(a),a,b,s,g);expected=cropgear(cv,a);instruments(cv,a,b,s,rpm,speed,pose);assert cropgear(cv,a)==expected,(g,pose,rpm,speed);testcount+=1
 oldcv=gear(static(oa),oa,ob,os,g);oldexpected=cropgear(oldcv,oa);instruments(oldcv,oa,ob,os,rpm,speed,pose)
 old_failures+=cropgear(oldcv,oa)!=oldexpected
# Test real ordering over a continuous trace: GEAR updates only on knob changes;
# instrument updates and pose changes continue on every following frame.
frames=[];cv=static(a);trace=0
for g in range(1,7):
 gear(cv,a,b,s,g);expected=cropgear(cv,a)
 for i in range(128):
  pose=['whl1','whl2','whl3'][(i//8)%3];instruments(cv,a,b,s,i*128,(i*2)%256,pose);assert cropgear(cv,a)==expected;trace+=1
  if i%8==0:frames.append(pal(cv).resize((960,600),Image.Resampling.NEAREST))
frames[0].save(P/'PREVIEWS/RAPPORTS_SANS_EFFACEMENT_SIMULATION.gif',save_all=True,append_images=frames[1:],duration=90,loop=0,disposal=2)
prev=set()
for i in range(128):
 cv=instruments(static(a),a,b,s,i*128,165,'whl2');black={(x,y) for y in range(148,151) for x in range(138,171) if cv.getpixel((x,y))==31};assert prev<=black;prev=black
assert len(prev)==22
sheet=Image.new('RGB',(1280,445),'#20252b');d=ImageDraw.Draw(sheet)
for j,(aa,bb,ss,label) in enumerate([(oa,ob,os,'V13: native order'),(a,b,s,'V14: native order')]):
 for i,pose in enumerate(['whl1','whl2','whl3']):
  cv=gear(static(aa),aa,bb,ss,3);instruments(cv,aa,bb,ss,10496,165,pose);sheet.paste(pal(cv).convert('RGB'),(i*320,j*220+22));d.text((i*320+5,j*220+5),label+' / '+pose,fill='white')
sheet.crop((0,0,960,445)).save(P/'PREVIEWS/COMPARAISON_ORDRE_NATIF.png')
for key in ['whl1','whl2','whl3']:
 cv=gear(static(a),a,b,s,3);instruments(cv,a,b,s,10496,165,key);pal(cv).save(P/'PREVIEWS'/f'{key}_320x200.png');pal(cv).resize((1280,800),Image.Resampling.NEAREST).save(P/'PREVIEWS'/f'{key}_x4.png')
for nm in ['STDAF643.VSH','STDBF643.VSH']:VSH((P/nm).read_bytes())
models={}
oldrs=unpack((OLD/'STF643.3SH').read_bytes());rs=unpack((P/'STF643.3SH').read_bytes())
for k in rs:
 if not k.startswith('car'):assert rs[k]==oldrs[k];continue
 sh=shape(rs[k]);osh=shape(oldrs[k]);assert sh['p']==osh['p'];sphere=next(p for p in sh['p'] if p['t']==11);ci,ri=sphere['ix'];assert sh['v'][:ri]+sh['v'][ri+1:]==osh['v'][:ri]+osh['v'][ri+1:];assert len(sh['v'])<=255 and len(sh['p'])<=255 and sh['nj']==11
 assert sum((x-y)**2 for x,y in zip(sh['v'][ci],sh['v'][ri]))==sum((x-y)**2 for x,y in zip(osh['v'][ci],osh['v'][ri]))
 before=json.loads((W/(k+'_before_coverage.json')).read_text());after=json.loads((W/(k+'_after_coverage.json')).read_text());h=next(pr for pr in sh['p'] if pr['t']==11)
 # Positive/negative inclination can correctly hide the helmet behind bodywork.
 # Do not equate increased screen coverage with globally correct occlusion.
 models[k]={'vertices':len(sh['v']),'primitives':len(sh['p']),'native_projection_cases':1088,'sphere_primitive_and_center_and_size_preserved':True,'only_one_size_vertex_changed':True,'paintjobs':11,'level_views_more_helmet_visible':sum(y['visible']>x['visible'] for x,y in zip(before,after) if x['pitch']==0),'level_views_less_helmet_visible':sum(y['visible']<x['visible'] for x,y in zip(before,after) if x['pitch']==0)}
assert all(models[k]['level_views_less_helmet_visible']==0 for k in models)
for kk,mm in [('dast','dasm'),('ins1','inm1'),('ins3','inm3')]:
 ip,mp=pix(a[kk],'L'),pix(a[mm],'L');assert ip.size==mp.size and set(mp.tobytes())<={0,255};assert all(m==0 or p==0 for p,m in zip(ip.tobytes(),mp.tobytes()))
for k in c:
 if k!='simd':assert c[k]==oc[k]
assert s[:516]==os[:516]
result={'status':'PASS','gear_survives_native_GEAR_WHEEL_INSTRUMENT_DOT_order_cases':testcount,'same_cases_failing_on_V13':old_failures,'continuous_frames_gear_survives_without_redrawing_it':trace,'RPM_128_states_monotonic':True,'RPM_11_segments_preserved':True,'models':models,'geometry_native_C_projection_total':3264,'original_physics_and_transmission_bytes_unchanged':True,'VSH_reparsed':True,'native_masks_valid':True,'DOSBox_test_this_release':False,'limits':['The native gear-change animation and timeout remain; this corrects competing refresh writes, not the engine timeout.','3D painter sorting still permits residual occlusion differences at steep inclinations.','Previews are resource compositions / native C projection queues, not DOSBox screenshots.']}
(P/'VALIDATION_V14.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
