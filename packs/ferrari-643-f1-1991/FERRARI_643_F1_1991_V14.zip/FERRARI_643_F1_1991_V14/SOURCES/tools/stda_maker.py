#!/usr/bin/env python3
"""STDA Maker: conservative Stunts 1.1 VGA VSH bitmap importer/exporter.

By Alain il Professore — Hyperion Racing Team.
Requires Pillow: python -m pip install Pillow

No network, no deletion, no overwrite of source. Does not modify RES, 3SH or physics.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import struct
import sys
import tempfile
import zipfile
from dataclasses import dataclass
from pathlib import Path
from PIL import Image

MASK_IDS = {"dasm", "inm1", "inm3"}
PAIRS = {"dast": "dasm", "ins1": "inm1", "ins3": "inm3"}
IMAGE_EXTS = {".png", ".bmp", ".gif", ".tif", ".tiff", ".jpg", ".jpeg", ".webp"}
SCRIPT_DIR = Path(__file__).resolve().parent
DEFAULT_PALETTE = SCRIPT_DIR.parent / "references" / "stressed-vga-palette.txt"


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def palette_from_file(path: Path) -> list[tuple[int, int, int]]:
    tokens = []
    for ln in path.read_text(encoding="utf-8").splitlines():
        if ln.startswith("# ") or ln.startswith("# VGA") or ln.startswith("# Source") or ln.startswith("# In "):
            continue
        tokens.extend(re.findall(r"#[0-9a-fA-F]{6}\b", ln))
    if len(tokens) != 256:
        raise ValueError(f"Palette must contain exactly 256 #RRGGBB colors, found {len(tokens)}")
    return [tuple(bytes.fromhex(t[1:])) for t in tokens]


@dataclass
class Bitmap:
    name: str
    offset: int
    length: int
    width: int
    height: int
    ax: int
    ay: int
    x: int
    y: int
    unknown: bytes
    data: bytes


class VSH:
    def __init__(self, raw: bytes):
        self.raw = raw
        if len(raw) < 6:
            raise ValueError("VSH too short")
        declared, count = struct.unpack_from("<IH", raw)
        if declared != len(raw):
            raise ValueError(f"VSH file length mismatch: header={declared}, actual={len(raw)}")
        if count == 0 or count > 512 or len(raw) < 6+8*count:
            raise ValueError(f"Invalid VSH resource directory: {count} entries")
        self.ids = [raw[6+4*i:10+4*i].decode("ascii") for i in range(count)]
        if len(set(self.ids)) != count:
            raise ValueError("Duplicate VSH resource IDs")
        base = 6+8*count
        offsets = list(struct.unpack_from("<"+"I"*count, raw, 6+4*count))
        if offsets[0] != 0 or any(a >= b for a,b in zip(offsets,offsets[1:])):
            raise ValueError("Corrupt VSH resource offsets")
        self.base = base
        self.res = {}
        for i, (name, off) in enumerate(zip(self.ids, offsets)):
            start = base+off
            end = base+offsets[i+1] if i+1<count else len(raw)
            if start+16 > end:
                raise ValueError(f"Resource {name} truncated")
            w,h,ax,ay,x,y = struct.unpack_from("<6H", raw, start)
            if w <= 0 or h <= 0 or w*h > 10_000_000 or 16+w*h > end-start:
                raise ValueError(f"Resource {name} has invalid pixel count: {w}x{h}, data={end-start}")
            remainder=raw[start+16+w*h:end]
            if len(remainder) > 31 or any(remainder):
                raise ValueError(f"Resource {name} has {len(remainder)} extra non-pixel bytes "
                                 "(or non-zero padding): possible row-stride corruption; repair before importing")
            unknown = raw[start+12:start+16]
            if unknown[2] & 0x30:
                raise ValueError(f"Resource {name} uses interlaced/transposed storage; importer refuses unsafe rewrite")
            self.res[name.lower()] = Bitmap(name, start, end-start, w,h,ax,ay,x,y,unknown, raw[start+16:start+16+w*h])

    def patched(self, replacements: dict[str, bytes]):
        out = bytearray(self.raw)
        for name, pixels in replacements.items():
            b = self.res[name]
            if len(pixels) != b.width*b.height:
                raise ValueError(f"Replacement {name}: expected {b.width*b.height} pixels, found {len(pixels)}")
            out[b.offset+16:b.offset+16+len(pixels)] = pixels
        result=bytes(out)
        check=VSH(result)
        for name in self.res:
            if name not in replacements and check.res[name].data != self.res[name].data:
                raise AssertionError(f"Unrequested resource {name} changed")
        return result


def as_png(native: Bitmap, palette: list[tuple[int,int,int]], data: bytes | None = None, mask: bytes | None = None) -> Image.Image:
    raw = native.data if data is None else data
    if native.name.lower() in MASK_IDS:
        return Image.frombytes("L", (native.width,native.height), raw)
    rgb = bytearray(native.width*native.height*4)
    for i, v in enumerate(raw):
        j=i*4
        if mask is not None:
            alpha = 0 if mask[i] == 255 else 255
        else:
            alpha = 0 if v == 255 else 255
        color=palette[v if v != 255 else 0]
        rgb[j:j+4]=bytes((*color,alpha))
    return Image.frombytes("RGBA", (native.width,native.height),bytes(rgb))


def check_dimensions(img: Image.Image, bitmap: Bitmap, full_canvas: bool) -> Image.Image:
    if img.size == (bitmap.width,bitmap.height):
        return img
    if full_canvas and img.size == (320,200):
        if bitmap.x+bitmap.width > 320 or bitmap.y+bitmap.height > 200:
            raise ValueError(f"{bitmap.name} cannot be cropped from full 320x200 canvas; outside screen")
        return img.crop((bitmap.x,bitmap.y,bitmap.x+bitmap.width,bitmap.y+bitmap.height))
    raise ValueError(f"{bitmap.name}: image size {img.size}, expected {bitmap.width}x{bitmap.height}; "
                     "wrong dimensions are refused (use --full-canvas only for a real 320x200 source)")


def convert_mask(img: Image.Image) -> bytes:
    rgba=img.convert("RGBA")
    values=[]
    for r,g,b,a in rgba.getdata():
        if a!=255:
            raise ValueError("Mask must be opaque black or white (RGB/gray 8 bit); alpha channel is not allowed")
        if (r,g,b)==(0,0,0): values.append(0)
        elif (r,g,b)==(255,255,255): values.append(255)
        else: raise ValueError(f"Mask has non-binary pixel {(r,g,b)}. Use exact black 0 and white 255")
    return bytes(values)


def quantize(img: Image.Image, palette: list[tuple[int,int,int]], transparency: bool, magenta_alpha: bool):
    # Use a fixed palette. Reserve 255 (white in source palette) for transparency only.
    p=Image.new("P",(1,1))
    flat=[]
    for c in palette[:255]: flat.extend(c)
    flat += [0,0,0]  # duplicate index 0 to discourage use of reserved index 255
    p.putpalette(flat)
    rgba=img.convert("RGBA")
    rgb=rgba.convert("RGB")
    q=rgb.quantize(palette=p,dither=Image.Dither.NONE)
    raw=bytearray(q.tobytes())
    rgba_bytes=rgba.tobytes()
    alpha=[False]*len(raw)
    for i,v in enumerate(raw):
        if v==255: raw[i]=0
        j=i*4
        invisible=rgba_bytes[j+3] < 128 or (magenta_alpha and rgba_bytes[j]==255 and rgba_bytes[j+1]==0 and rgba_bytes[j+2]==255)
        alpha[i]=invisible
        if transparency and invisible: raw[i]=255
    return bytes(raw), alpha


def assignments_from_files(vsh: VSH, images: list[Path], sets: list[str]):
    assigns={}
    for spec in sets:
        if '=' not in spec: raise ValueError(f"Invalid --set {spec!r}, expected ID=image.png")
        name,filename=spec.split('=',1)
        key=name.lower()
        if key not in vsh.res: raise ValueError(f"Unknown VSH ID {name}. Use list to see all resources")
        path=Path(filename)
        if not path.is_file(): raise FileNotFoundError(path)
        if key in assigns: raise ValueError(f"Duplicate image assignment for {name}")
        assigns[key]=path
    for path in images:
        if not path.is_file(): raise FileNotFoundError(path)
        if path.suffix.lower() not in IMAGE_EXTS: raise ValueError(f"Unsupported image format: {path}")
        stem=path.stem.lower()
        # Name matching is intentionally strict to avoid guessing a resource.
        # Supports exact 'ins1.png' and prefix/suffix 'VMET_ins1_final.png'.
        candidates=[key for key in vsh.res if re.search(r"(?:^|[_\- .])"+re.escape(key)+r"(?:$|[_\- .])",stem)]
        if len(candidates) != 1:
            raise ValueError(f"Cannot unambiguously map {path.name} to one resource ID "
                             f"({candidates}). Rename to ID.png or use --set ID={path}")
        key=candidates[0]
        if key in assigns: raise ValueError(f"Duplicate image assignment for {key}")
        assigns[key]=path
    if not assigns: raise ValueError("No PNG images provided")
    return assigns


def make_replacements(vsh: VSH, palette, assigns, full_canvas=False, magenta_alpha=False):
    result={}
    alpha_of={}
    actions=[]
    for key,path in assigns.items():
        b=vsh.res[key]
        with Image.open(path) as source:
            im=check_dimensions(source.copy(),b,full_canvas)
        if key in MASK_IDS:
            result[key]=convert_mask(im)
            actions.append(f"{key}: replaced binary mask from {path.name}")
        else:
            raw, alpha=quantize(im,palette,transparency=True,magenta_alpha=magenta_alpha)
            result[key]=raw
            alpha_of[key]=alpha
            actions.append(f"{key}: imported {path.name} ({b.width}x{b.height})")

    for parent, mask_name in PAIRS.items():
        if parent not in vsh.res or mask_name not in vsh.res:
            continue
        if parent not in result and mask_name not in result:
            continue
        b=vsh.res[parent]; m=vsh.res[mask_name]
        if (b.width,b.height,b.x,b.y)!=(m.width,m.height,m.x,m.y):
            raise ValueError(f"{parent}/{mask_name} dimension or origin mismatch in source VSH")
        original_mask=vsh.res[mask_name].data
        # If parent has actual alpha and no standalone mask, generate AND mask.
        if parent in result and mask_name not in result and any(alpha_of[parent]):
            result[mask_name]=bytes(255 if transparent else 0 for transparent in alpha_of[parent])
            actions.append(f"{mask_name}: generated from PNG alpha of {parent}")
        if mask_name in result:
            mask=result[mask_name]
            if parent not in result:
                # Preserve original opaque content but clear pixels made transparent.
                result[parent]=vsh.res[parent].data
                actions.append(f"{parent}: synchronized to new {mask_name}")
        else:
            mask=original_mask
        if parent in result:
            pixels=bytearray(result[parent])
            for i,mv in enumerate(mask):
                if mv==255:
                    pixels[i]=0  # native AND/OR composition: OR sprite must be zero for transparent pixels
                elif pixels[i]==255:
                    # Native index 255 is transparent for standalone shapes but not a valid opaque OR pixel
                    pixels[i]=0
            result[parent]=bytes(pixels)
    # Masks are binary by design. Don't auto-edit unrelated sprites.
    for key,data in result.items():
        if key in MASK_IDS and any(x not in (0,255) for x in data):
            raise AssertionError(f"Internal mask error: {key}")
    return result,actions


def inspect(vsh:VSH, out=None):
    lines=[]
    for key in vsh.ids:
        b=vsh.res[key.lower()]
        lines.append(dict(id=b.name,width=b.width,height=b.height,x=b.x,y=b.y,anchorX=b.ax,anchorY=b.ay,bytes=len(b.data)))
    if out:
        Path(out).write_text(json.dumps(lines,indent=2,ensure_ascii=False),encoding="utf-8")
    return lines


def export_all(vsh:VSH, palette, directory:Path):
    directory.mkdir(parents=True,exist_ok=True)
    for key in vsh.ids:
        b=vsh.res[key.lower()]
        partner=PAIRS.get(key.lower())
        mask=vsh.res[partner].data if partner in vsh.res else None
        as_png(b,palette,mask=mask).save(directory/f"{key}.png")
    (directory/"RESOURCE_MAP.json").write_text(json.dumps(inspect(vsh),indent=2),encoding="utf-8")


def main(argv=None):
    ap=argparse.ArgumentParser(description="Inject PNG bitmaps into a native STDAxxxx.VSH (non-destructive)")
    sub=ap.add_subparsers(dest="action",required=True)
    for cmd in ("list","export","inject"):
        p=sub.add_parser(cmd)
        p.add_argument("vsh",type=Path)
        p.add_argument("--palette",type=Path,default=DEFAULT_PALETTE,
                       help="256-color Stressed RGB palette file; use your verified game palette if available")
        if cmd=="export": p.add_argument("--out",type=Path,required=True)
        if cmd=="inject":
            p.add_argument("images",nargs="*",type=Path)
            p.add_argument("--set",action="append",default=[],metavar="ID=IMAGE.png")
            p.add_argument("--images-zip",type=Path,action="append",default=[],help="ZIP containing named PNGs to inject")
            p.add_argument("--out",type=Path,required=True)
            p.add_argument("--full-canvas",action="store_true",help="crop a full 320x200 PNG at the resource's native x/y")
            p.add_argument("--magenta-as-alpha",action="store_true",help="explicitly treat RGB #FF00FF as transparent")
    args=ap.parse_args(argv)
    raw=args.vsh.read_bytes()
    vsh=VSH(raw)
    pal=palette_from_file(args.palette)
    if args.action=="list":
        print(json.dumps(inspect(vsh),indent=2,ensure_ascii=False));return 0
    if args.action=="export":
        export_all(vsh,pal,args.out)
        print(f"Exported {len(vsh.res)} resources into {args.out}");return 0
    if args.out.resolve()==args.vsh.resolve():
        raise ValueError("Refusing to overwrite input. Specify a different --out path")
    if args.out.suffix.lower()!=".vsh": raise ValueError("Output file must have .VSH extension")
    with tempfile.TemporaryDirectory(prefix="stda-maker-") as tmp:
        extracted=[]
        for zno,filename in enumerate(args.images_zip):
            with zipfile.ZipFile(filename) as archive:
                candidates=[item for item in archive.infolist()
                            if not item.is_dir() and Path(item.filename).suffix.lower() in IMAGE_EXTS]
                if len(candidates)>100:
                    raise ValueError(f"ZIP {filename}: more than 100 images; too many")
                names=set()
                for item in candidates:
                    if item.file_size > 15_000_000:
                        raise ValueError(f"ZIP {filename}: {item.filename} exceeds 15MB")
                    basename=Path(item.filename).name
                    if basename.lower() in names:
                        raise ValueError(f"ZIP {filename} has duplicate base filename: {basename}")
                    names.add(basename.lower())
                    path=Path(tmp)/str(zno)/basename
                    path.parent.mkdir(parents=True,exist_ok=True)
                    path.write_bytes(archive.read(item))
                    extracted.append(path)
        assigns=assignments_from_files(vsh,args.images+extracted,args.set)
        replacements,actions=make_replacements(vsh,pal,assigns,args.full_canvas,args.magenta_as_alpha)
        new=vsh.patched(replacements)
    args.out.parent.mkdir(parents=True,exist_ok=True)
    args.out.write_bytes(new)
    audit={
        "tool":"STDA Maker","input":str(args.vsh),"output":str(args.out),
        "source_sha256":sha256(raw),"output_sha256":sha256(new),
        "source_bytes":len(raw),"output_bytes":len(new),
        "changed_resources":[k for k in replacements if vsh.res[k].data!=VSH(new).res[k].data],
        "preserved_resources":[k for k in vsh.res if k not in replacements],
        "source_palette":str(args.palette),"input_assignments":{k:str(v) for k,v in assigns.items()},
        "notes":actions,"dosbox_tested":False,
        "reminder":"Remove/rename competing compressed STDAXXXX.PVS where Stunts may prefer it."
    }
    audit_path=args.out.with_suffix(".audit.json")
    audit_path.write_text(json.dumps(audit,indent=2,ensure_ascii=False),encoding="utf-8")
    print(json.dumps({"output":str(args.out),"audit":str(audit_path),"changed":audit["changed_resources"]},ensure_ascii=False))
    return 0


if __name__=="__main__":
    try: sys.exit(main())
    except (ValueError,FileNotFoundError,OSError) as ex:
        print("STDA Maker ERROR:",ex,file=sys.stderr)
        sys.exit(2)

