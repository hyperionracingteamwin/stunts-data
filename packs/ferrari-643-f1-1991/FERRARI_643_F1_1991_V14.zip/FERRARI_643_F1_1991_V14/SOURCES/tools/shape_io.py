import struct,json,pathlib,collections
ROOT=pathlib.Path(__file__).parent
def unpack(b):
 n=struct.unpack_from('<H',b,4)[0]; base=6+n*8
 ids=[b[6+4*i:10+4*i].decode('ascii') for i in range(n)]
 offs=list(struct.unpack_from('<'+'I'*n,b,6+4*n))
 return {name:b[base+off:base+min([p for p in offs if p>off]+[len(b)-base])] for name,off in zip(ids,offs)}
def pack(rs):
 data=b''; offs=[]
 for name,r in rs.items(): offs.append(len(data)); data+=r
 return struct.pack('<IH',6+8*len(rs)+len(data),len(rs))+''.join(rs).encode('ascii')+struct.pack('<'+'I'*len(rs),*offs)+data
def shape(b):
 nv,np,nj,res=b[:4]; v=[list(struct.unpack_from('<hhh',b,4+6*i)) for i in range(nv)]; pos=4+6*nv
 c1=struct.unpack_from('<'+'I'*np,b,pos);pos+=4*np
 c2=struct.unpack_from('<'+'I'*np,b,pos);pos+=4*np
 ps=[]
 for i in range(np):
  t,f=b[pos:pos+2]; mats=list(b[pos+2:pos+2+nj]);pos+=2+nj; count=t if t<=10 else {11:2,12:6}.get(t,0)
  ix=list(b[pos:pos+count]);pos+=count
  ps.append(dict(i=i,t=t,f=f,m=mats,ix=ix,c1=c1[i],c2=c2[i]))
 return dict(v=v,p=ps,nj=nj,padding=b[pos:].hex(),reserved=res)
def save_shape(s):
 v,p,nj=s['v'],s['p'],s['nj']
 b=bytes([len(v),len(p),nj,s['reserved']])+b''.join(struct.pack('<hhh',*x) for x in v)
 b+=b''.join(struct.pack('<I',x['c1']) for x in p)+b''.join(struct.pack('<I',x['c2']) for x in p)
 b+=b''.join(bytes([x['t'],x['f']]+x['m']+x['ix']) for x in p)
 return b+b'\0\0\0'
if __name__=='__main__':
 r=unpack(next((ROOT/'inputs').glob('*.3SH')).read_bytes())
 shapes={k:shape(b) for k,b in r.items()}
 (ROOT/'mesh.json').write_text(json.dumps(shapes,indent=2))
 for k,s in shapes.items():
  if not k.startswith('car'):continue
  print(k,'vertices',len(s['v']),'primitives',len(s['p']),'flags',collections.Counter(p['f'] for p in s['p']),'padding',s['padding'])
  with (ROOT/(k+'_dump.txt')).open('w') as out:
   for p in s['p']:
    coords=[s['v'][i] for i in p['ix']]
    out.write(f"{p['i']:3d} T{p['t']} F{p['f']} M{p['m'][0]:2d} C{p['c1']:08x}/{p['c2']:08x} {coords}\n")
 print('wrote mesh dumps')
