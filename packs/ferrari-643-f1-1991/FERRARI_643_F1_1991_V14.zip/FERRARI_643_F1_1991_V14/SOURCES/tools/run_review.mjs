import fs from 'node:fs';import {WASI} from 'node:wasi';
const [wasmpath,input,output,ys='16',ps='64']=process.argv.slice(2);
const wasi=new WASI({version:'preview1',args:['review',input,output,ys,ps],preopens:{'.':process.cwd()},returnOnExit:true});
const module=await WebAssembly.instantiate(fs.readFileSync(wasmpath),{wasi_snapshot_preview1:wasi.wasiImport});
process.exitCode=wasi.start(module.instance);
