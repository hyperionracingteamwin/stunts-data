from pathlib import Path
import sys,struct,json
import numpy as np
from PIL import Image,ImageDraw
from native_utils import unpack,pix,info,native_blit,line_points,PAL,sha
W=Path(__file__).resolve().parent;P=W/'package/FERRARI_643_F1_1991_V13'
if not P.exists():P=W.parent

def pal(im):
 im=im.convert('P');im.putpalette([v for c in PAL for v in c]);return im

def render(a,b,s,rpm=7000,key='whl2',speed=165,gear=3):
 cv=Image.new('L',(320,200),9);d=ImageDraw.Draw(cv);d.rectangle((0,95,319,199),fill=27);d.polygon([(145,95),(175,95),(280,199),(40,199)],fill=8)
 for k,op in [('dash','COPY'),('dasm','AND'),('dast','OR'),(key,'COPY')]:native_blit(cv,a,k,op)
 panel=pix(a['ins2'],'L');d=ImageDraw.Draw(panel);index=min(rpm//128,struct.unpack_from('<H',s,514)[0]-1);pivot=struct.unpack_from('<hh',s,510);endpoint=s[516+2*index:518+2*index];d.line([pivot,tuple(endpoint)],fill=15)
 for j,ch in enumerate(str(speed).rjust(3)):
  if ch!=' ':panel.paste(pix(b['dig'+ch],'L'),tuple(s[302+2*j:304+2*j]))
 if key!='whl2':
  mk='inm'+key[-1];ik='ins'+key[-1];panel=Image.frombytes('L',panel.size,bytes((p&m)|v for p,m,v in zip(panel.tobytes(),pix(a[mk],'L').tobytes(),pix(a[ik],'L').tobytes())))
 m=info(a['ins2']);cv.paste(panel,(m['x'],m['y']))
 native_blit(cv,b,'dota','AND');native_blit(cv,b,'dot ','OR')
 if gear is not None:
  g=info(a['gbox']);px,py=struct.unpack_from('<hh',s,28+gear*4);am=info(b['gnob']);cv.paste(pix(b['gnob'],'L').crop((am['ax']-px,am['ay']-py,am['ax']-px+5,am['ay']-py+7)),(g['x'],g['y']))
 return cv

def main():
 a=unpack((P/'STDAF643.VSH').read_bytes());b=unpack((P/'STDBF643.VSH').read_bytes());s=unpack((P/'CARF643.RES').read_bytes())['simd'];pre=P/'PREVIEWS';pre.mkdir(exist_ok=True)
 assert struct.unpack_from('<H',s,174)[0]==15
 tests=[]
 for key in ['whl1','whl2','whl3']:
  previous=set();counts=[]
  for i in range(128):
   im=render(a,b,s,i*128,key);black={(x,y) for y in range(148,151) for x in range(138,182) if im.getpixel((x,y))==31};assert previous<=black,(key,i);previous=black;counts.append(len(black))
  assert counts[-1]==33,(key,counts[-1]);tests.append({'pose':key,'128_steps_monotonic':True,'black_pixels_full':33})
  pal(render(a,b,s,10496,key)).resize((1280,960),Image.Resampling.NEAREST).save(pre/(key.upper()+'_V13_4_3.png'))
 frames=[];sheet=Image.new('RGB',(1280,240*3),'#20252b');d=ImageDraw.Draw(sheet)
 for j,key in enumerate(['whl1','whl2','whl3']):
  for i,rpm in enumerate([2944,6528,10496,13056]):
   im=pal(render(a,b,s,rpm,key));sheet.paste(im.resize((320,240),Image.Resampling.NEAREST).convert('RGB'),(i*320,j*240));d.text((i*320+5,j*240+4),f'{key} / {rpm} RPM',fill='white')
 sheet.save(pre/'LCD_12_ETATS_V13.png')
 for rpm in list(range(2816,13185,256))+list(range(13056,2815,-256)):frames.append(pal(render(a,b,s,rpm)).resize((960,720),Image.Resampling.NEAREST))
 frames[0].save(pre/'LCD_ACCELERATION_DECELERATION.gif',save_all=True,append_images=frames[1:],duration=100,loop=0,disposal=2)
 pairs=[]
 for rs,listed in [(a,[('dast','dasm'),('ins1','inm1'),('ins3','inm3')]),(b,[('gnob','gnab')])]:
  for ik,mk in listed:
   ip,mp=pix(rs[ik],'L'),pix(rs[mk],'L');assert ip.size==mp.size;assert info(rs[ik])['x']==info(rs[mk])['x'] and info(rs[ik])['y']==info(rs[mk])['y'];assert set(mp.tobytes())<=set([0,255]);assert all(m==0 or p==0 for p,m in zip(ip.tobytes(),mp.tobytes()));pairs.append([ik,mk])
 # Native bitwise truth table for every gray and both possible white indices.
 mapping={str(i):(i&15)|16 for i in range(256)};assert mapping['15']==31 and all(mapping[str(i)]==i for i in range(16,32))
 for k in a:
  if not k.startswith('!') and k not in ['dasm','inm1','inm3']:assert 255 not in pix(a[k],'L').tobytes(),k
 result={'384_native_coordinate_RPM_state_compositions':tests,'native_AND_OR_LCD_truth_table':mapping,'mask_pairs_valid':pairs,'DOT_stencil_intentionally_nonbinary':True,'DOT_position_fixed_all_31_entries':len(set(tuple(s[234+2*i:236+2*i]) for i in range(31)))==1,'gear_window_separate_from_INS2_live_digits':True,'render_kind':'resource composition using native COPY AND OR and one-pixel line semantics; not a DOS screenshot'}
 (P/'VALIDATION_COCKPIT_V13.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items() if k!='native_AND_OR_LCD_truth_table'}))
if __name__=='__main__':main()
