"""Ferrari 643 V4 — genuine VGA resources, native mask/COPY distinction.
Artwork prepared with image_gen; reconstruction uses Python 3 + Pillow.
"""
from pathlib import Path
import sys,struct,json,hashlib,zipfile,math,argparse,shutil
from PIL import Image,ImageDraw
W=Path(__file__).resolve().parent
sys.path.insert(0,str(W/'tools'))
if not (W/'tools/stda_maker.py').exists():sys.path.insert(0,str(W.parent/'work_f643_v3/tools'))
from stda_maker import VSH,as_png,palette_from_file
PAL=palette_from_file(W/'references/stressed-vga-palette.txt' if (W/'references/stressed-vga-palette.txt').exists() else W.parent/'work_f643_v3/references/stressed-vga-palette.txt')
def sha(b):return hashlib.sha256(b).hexdigest()
def unpack(data):
 size,n=struct.unpack_from('<IH',data);assert size==len(data)
 keys=[data[6+i*4:10+i*4].decode('ascii') for i in range(n)];ofs=struct.unpack_from('<'+'I'*n,data,6+4*n);base=6+8*n
 assert ofs[0]==0 and all(x<y for x,y in zip(ofs,ofs[1:]))
 return {k:data[base+o:base+ofs[i+1] if i+1<n else len(data)] for i,(k,o) in enumerate(zip(keys,ofs))}
def pack(rs):
 ofs=[];length=0
 for value in rs.values():ofs.append(length);length+=len(value)
 return struct.pack('<IH',6+8*len(rs)+length,len(rs))+''.join(rs).encode()+struct.pack('<'+'I'*len(rs),*ofs)+b''.join(rs.values())
def pix(raw,mode='P'):
 w,h=struct.unpack_from('<HH',raw);im=Image.frombytes(mode,(w,h),raw[16:16+w*h])
 if mode=='P':im.putpalette([v for c in PAL for v in c])
 return im
def bmp(old,im,x,y,ax=0,ay=0):return struct.pack('<6H',im.width,im.height,ax&65535,ay&65535,x,y)+old[12:16]+im.tobytes()
def indices(im):return Image.frombytes('L',im.size,im.tobytes())
def quant(im):
 p=Image.new('P',(1,1));p.putpalette([v for c in PAL[:255] for v in c]+list(PAL[0]))
 q=im.convert('RGB').quantize(palette=p,dither=Image.Dither.NONE)
 # Any opaque pixel mapped to the duplicated last palette entry is black, not 255.
 data=bytes(0 if v==255 else v for v in q.tobytes());q=Image.frombytes('P',im.size,data);q.putpalette([v for c in PAL for v in c]);return q
def info(b):return dict(zip(['w','h','ax','ay','x','y'],struct.unpack_from('<6H',b)))|{'control':b[12:16].hex(),'sha256':sha(b)}
def line_points(x0,y0,x1,y1):
 dx=abs(x1-x0);sx=1 if x0<x1 else -1;dy=-abs(y1-y0);sy=1 if y0<y1 else -1;e=dx+dy
 while True:
  yield x0,y0
  if (x0,y0)==(x1,y1):break
  t=2*e
  if t>=dy:e+=dy;x0+=sx
  if t<=dx:e+=dx;y0+=sy
def native_blit(canvas,rs,k,op='COPY',xy=None):
 import numpy as np
 im=pix(rs[k],'L');m=info(rs[k]);x,y=xy or (m['x'],m['y']);x0,y0=max(0,x),max(0,y);x1,y1=min(canvas.width,x+im.width),min(canvas.height,y+im.height)
 if x0>=x1 or y0>=y1:return
 v=np.array(im.crop((x0-x,y0-y,x1-x,y1-y)));old=np.array(canvas.crop((x0,y0,x1,y1)))
 result=v if op=='COPY' else np.bitwise_and(old,v) if op=='AND' else np.bitwise_or(old,v)
 canvas.paste(Image.fromarray(result),(x0,y0))
