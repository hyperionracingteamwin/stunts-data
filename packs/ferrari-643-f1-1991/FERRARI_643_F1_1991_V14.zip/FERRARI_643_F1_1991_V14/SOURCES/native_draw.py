from pathlib import Path
import sys,json,re,copy
W=Path(__file__).resolve().parent;sys.path.insert(0,str(W/'tools'))
from shape_io import unpack,pack,shape,save_shape
import numpy as np
from PIL import Image,ImageDraw
P=W/'package/FERRARI_643_F1_1991_V13'
if not P.exists():P=W.parent
PRE=P/'PREVIEWS';PRE.mkdir(exist_ok=True)
t=(W/'references/defaults.conf').read_text();PAL=[tuple(bytes.fromhex(x)) for x in re.findall(r'#([0-9a-fA-F]{6})',t.split('[materials]')[0])];COLORS=list(map(int,re.findall(r'\d+',t.split('colors=')[1].split('patterns=')[0])));PATTERNS=list(map(int,re.findall(r'\d+',t.split('patterns=')[1].split('\n[')[0])))
t=(W/'tools/native/vendor/full_data.c').read_text();BITS=[int(x)&65535 for x in re.findall(r'-?\d+',t.split('material_pattern2_list[SHAPE3D_MATERIAL_COUNT] = {')[1].split('};')[0])]
def hull(points):
 a=sorted(set(map(tuple,points)))
 def cross(o,p,q):return (p[0]-o[0])*(q[1]-o[1])-(p[1]-o[1])*(q[0]-o[0])
 lo=[];hi=[]
 for p in a:
  while len(lo)>1 and cross(lo[-2],lo[-1],p)<=0:lo.pop()
  lo.append(p)
 for p in a[::-1]:
  while len(hi)>1 and cross(hi[-2],hi[-1],p)<=0:hi.pop()
  hi.append(p)
 return lo[:-1]+hi[:-1]
def draw(row,braking=False):
 im=Image.new('RGB',(320,200),'#a4a4a4');d=ImageDraw.Draw(im)
 for p in row['queue']:
  mat=p['material'];mat=47 if braking and mat==46 else mat;pts=list(map(tuple,p['points']));color=PAL[COLORS[mat]]
  if p['type']==0 and len(pts)>=3:
   if not PATTERNS[mat]:d.polygon(pts,fill=color)
   else:
    mask=Image.new('L',im.size,0);ImageDraw.Draw(mask).polygon(pts,fill=255);a=np.array(mask);yy,xx=np.indices(a.shape);a[((BITS[mat]>>((yy%4)*4+xx%4))&1)==0]=0;im.paste(color,(0,0,320,200),Image.fromarray(a))
  elif p['type']==1:d.line(pts,fill=color)
  elif p['type']==2 and len(pts)>=2:
   # Native sphere record stores screen size in the next WORD, not a second point.
   x,y=pts[0];size=pts[1][0];height=size-(size>>2)+(size>>4);ry=max(1,height//2);rx=max(1,height-ry);rx+=rx>>2;d.ellipse((x-rx,y-ry,x+rx,y+ry),fill=color)
  elif p['type']==3:
   rings=p['wheel_rings'];near=list(map(tuple,rings[:16]));rim=list(map(tuple,rings[16:32]));far=list(map(tuple,rings[32:]));boundary=hull(near+far)
   if len(boundary)>=3:d.polygon(boundary,fill=PAL[COLORS[mat+1]])
   d.polygon(near,fill=color);d.polygon(rim,fill=PAL[COLORS[mat+2]])
 return im
