from pathlib import Path
import sys,json,copy,subprocess
W=Path(__file__).resolve().parent;ROOT=W.parent
PORTABLE=(W/'native_utils.py').exists();BASE=W if PORTABLE else ROOT/'work_f643_v13'
sys.path.insert(0,str(BASE/'tools'))
sys.path.insert(0,str(BASE))
from shape_io import unpack,pack,shape,save_shape
from native_draw import draw
from PIL import Image,ImageDraw
import numpy as np
SRC=ROOT/'ORIGINAL_V13' if PORTABLE else ROOT/'work_f643_v13/package/FERRARI_643_F1_1991_V13'
rs=unpack((SRC/'STF643.3SH').read_bytes())
for name in ['car0','car1','car2']:
 s=shape(rs[name]);h=next(p for p in s['p'] if p['t']==11);ci,ri=h['ix'];c=s['v'][ci];r=s['v'][ri];size=round(sum((a-b)**2 for a,b in zip(c,r))**.5)
 # This point defines diameter, not a visible mesh edge. Vertical orientation
 # removes the unwanted lateral average-depth bias while keeping its length.
 s['v'][ri]=[c[0],c[1]+size,c[2]]
 rs[name]=save_shape(s)
 for variant,ss in [('before',shape(unpack((SRC/'STF643.3SH').read_bytes())[name])),('after',s)]:
  ss=copy.deepcopy(ss);scale=1 if name=='car0' else 20
  ss['v']=[[v*scale for v in p] for p in ss['v']];mp={}
  for p in ss['p']:
   marker=p['i']+1+(p['i']>=44);mp[marker]=copy.deepcopy(p);p['m']=[marker]*ss['nj']
  prefix=W/(name+'_'+variant);prefix.with_suffix('.3SH').write_bytes(pack({'car0':save_shape(ss)}))
  subprocess.run(['node',str(BASE/'tools/run_review.mjs'),str(BASE/'tools/review.wasm'),str(prefix.with_suffix('.3SH').relative_to(ROOT)),str(prefix.with_suffix('.json').relative_to(ROOT)),'16','64'],cwd=ROOT,check=True,capture_output=True)
  rows=json.loads(prefix.with_suffix('.json').read_text());helm=next(k for k,p in mp.items() if p['t']==11)
  stats=[];frames=[]
  for row in rows:
   # Native painter order, marker IDs; measure how much of helmet silhouette
   # remains after all subsequent primitives have been painted.
   mask=Image.new('L',(320,200));d=ImageDraw.Draw(mask);area=None
   for p in row['queue']:
    if p['material']==helm:
     x,y=p['points'][0];size=p['points'][1][0];ht=size-(size>>2)+(size>>4);ry=max(1,ht//2);rx=max(1,ht-ry);rx+=rx>>2
     box=(x-rx,y-ry,x+rx,y+ry);d.ellipse(box,fill=255);area=int(np.count_nonzero(mask));
    elif area is not None and p['type']==0:d.polygon(list(map(tuple,p['points'])),fill=0)
   if area:stats.append({'yaw':row['yaw'],'pitch':row['pitch'],'area':area,'visible':int(np.count_nonzero(mask))})
   for p in row['queue']:p['material']=mp[p['material']]['m'][8]
  prefix.with_name(prefix.name+'_coverage.json').write_text(json.dumps(stats))
  sheet=Image.new('RGB',(1280,5*225),'#20252b');d=ImageDraw.Draw(sheet)
  for j,pitch in enumerate([-128,-64,0,64,128]):
   for i,yaw in enumerate([128,384,640,896]):
    row=next(r for r in rows if r['yaw']==yaw and r['pitch']==pitch);im=draw(row);sheet.paste(im,(i*320,j*225+25));d.text((i*320+5,j*225+5),f'{name} {variant} yaw{yaw} pitch{pitch}',fill='white')
  sheet.save(prefix.with_suffix('.png'))
(W/'candidate.3SH').write_bytes(pack(rs))
print('Native sphere projection probes completed for all three models.')
