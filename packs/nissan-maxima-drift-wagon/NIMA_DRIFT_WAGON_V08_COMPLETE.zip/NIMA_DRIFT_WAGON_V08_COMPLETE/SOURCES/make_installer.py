"""Installer lives in the pack folder and modifies only its parent Stunts folder."""
from pathlib import Path

NATIVE=['CARNIMA.RES','STDANIMA.VSH','STDBNIMA.VSH','STNIMA.3SH']
COMPRESSED=['STDANIMA.PVS','STDANIMA.XVS','STDBNIMA.PVS','STDBNIMA.XVS','STNIMA.P3S']
MANAGED=NATIVE+COMPRESSED
GAME=['STUNTS.COM','STUNTS.EXE','STUNTS_K.EXE','GAME.EXE','LOAD.EXE']
TARGET='..\\'
BACKUP=TARGET+'NIMABAK\\'

def write(path,lines):
    path.write_bytes(('\r\n'.join(lines)+'\r\n').encode('ascii'))

def build(root):
    root=Path(root);root.mkdir(exist_ok=True,parents=True)
    pre=['@echo off','if "%OS%"=="Windows_NT" goto WIN','goto START',':WIN',
         'cd /d "%~dp0"',':START']
    ins=pre+['echo NIMA Drift Wagon V08 - INSTALL / INSTALLATION']
    for n in NATIVE+['../NIMAUNIN.BAT']:
        path='NIMAUNIN.BAT' if n.startswith('../') else 'NIMADATA\\'+n
        ins.append('if not exist '+path+' goto NODATA')
    for n in GAME:ins.append('if exist '+TARGET+n+' goto GAMEOK')
    ins+=['goto NOGAME',':GAMEOK','if exist '+BACKUP+'READY.NIM goto BACKED',
          'if exist '+BACKUP+'NUL goto BADBAK','if exist '+TARGET+'NIMABAK goto BADBAK',
          'md '+TARGET+'NIMABAK','if not exist '+TARGET+'NIMABAK goto BKFAIL']
    for i,n in enumerate(MANAGED):
        ins+=['if not exist '+TARGET+n+' goto B'+str(i),
              'copy /b '+TARGET+n+' '+BACKUP+n+' >nul',
              'if errorlevel 1 goto BKFAIL',':B'+str(i)]
    ins+=['echo NIMA original-file backup >'+BACKUP+'READY.NIM',
          'if not exist '+BACKUP+'READY.NIM goto BKFAIL',':BACKED']
    for i,n in enumerate(MANAGED):
        ins+=['if not exist '+TARGET+n+' goto D'+str(i),'del '+TARGET+n+' >nul',
              'if exist '+TARGET+n+' goto FAIL',':D'+str(i)]
    for n in NATIVE:
        ins+=['copy /b NIMADATA\\'+n+' '+TARGET+n+' >nul','if errorlevel 1 goto FAIL',
              'if not exist '+TARGET+n+' goto FAIL']
    ins+=['echo NIMA V08 installed >'+BACKUP+'ACTIVE.NIM',
          'echo Installed. Select Maxima Drift Wagon / NIMA in Stunts.',
          'echo Installe. Choisir Maxima Drift Wagon / NIMA dans Stunts.',
          'echo To restore previous files, run NIMAUNIN.BAT.', 'goto END',
          ':FAIL','echo Installation failed. Attempting restoration.',
          'call NIMAUNIN.BAT /AUTO','goto END',
          ':BKFAIL','echo Backup incomplete. No game file was changed.',
          'echo Keep NIMABAK and check available space or file access.','goto END',
          ':BADBAK','echo NIMABAK exists without a complete backup marker.',
          'echo No game file changed. Check this folder before retrying.','goto END',
          ':NODATA','echo Missing payload or NIMAUNIN.BAT. Extract the complete ZIP.','goto END',
          ':NOGAME','echo Place this complete pack folder DIRECTLY INSIDE your Stunts folder.',
          'echo Placer ce dossier complet DIRECTEMENT DANS le dossier Stunts.','goto END',
          ':BADDIR','echo Cannot open the batch file folder.',':END','pause']
    un=pre+['echo NIMA Drift Wagon - UNINSTALL / DESINSTALLATION',
            'if not exist '+BACKUP+'READY.NIM goto NOBAK']
    for i,n in enumerate(MANAGED):
        un+=['if not exist '+TARGET+n+' goto U'+str(i),'del '+TARGET+n+' >nul',
             'if exist '+TARGET+n+' goto FAIL',':U'+str(i)]
    for i,n in enumerate(MANAGED):
        un+=['if not exist '+BACKUP+n+' goto R'+str(i),
             'copy /b '+BACKUP+n+' '+TARGET+n+' >nul','if errorlevel 1 goto FAIL',
             'if not exist '+TARGET+n+' goto FAIL',':R'+str(i)]
    # Delete snapshots only after EVERY original file has been restored.
    for n in MANAGED:
        un+=['if exist '+BACKUP+n+' del '+BACKUP+n+' >nul']
    un+=['if exist '+BACKUP+'ACTIVE.NIM del '+BACKUP+'ACTIVE.NIM >nul',
         'del '+BACKUP+'READY.NIM >nul','rd '+TARGET+'NIMABAK',
         'echo Previous NIMA files restored. Other cars and mods are untouched.',
         'echo Anciens fichiers NIMA restaures. Autres voitures et mods conserves.',
         'goto END',':FAIL','echo Restore incomplete. The original backup is kept in NIMABAK.',
         'echo Close Stunts, fix file access or disk space, then run NIMAUNIN again.',
         'goto END',':NOBAK','echo No complete NIMA backup found. No game file changed.',
         'goto END',':BADDIR','echo Cannot open the batch file folder.',
         ':END','if "%1"=="/AUTO" goto DONE','pause',':DONE']
    write(root/'NIMAINST.BAT',ins);write(root/'NIMAUNIN.BAT',un)

if __name__=='__main__':build(Path(__file__).parent/'installer')
