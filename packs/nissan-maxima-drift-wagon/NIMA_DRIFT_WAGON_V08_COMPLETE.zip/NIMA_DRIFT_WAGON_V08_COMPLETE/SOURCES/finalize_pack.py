"""Assemble V08 with a same-name ZIP root folder and parent-target installer."""
from pathlib import Path
import hashlib,json,shutil,subprocess,sys,tempfile,zipfile
from PIL import Image,ImageDraw,ImageFont
from build_model import render,build,parse_shape,NPAINT,PAINTS,PAL,colors
from validate_pack import resources
from make_installer import build as installer,MANAGED
from test_installer import Batch,restored

ROOT=Path(__file__).resolve().parent;WORK=ROOT.parent;OUT=ROOT/'complete'
PACK='NIMA_DRIFT_WAGON_V08_COMPLETE'
NATIVE=['CARNIMA.RES','STDANIMA.VSH','STDBNIMA.VSH','STNIMA.3SH']
SOURCES=['build_model.py','build_dashboard.py','validate_pack.py','defaults.conf','CARNIMA_V02.RES',
         'STDBNIMA_V03.VSH','cockpit_photo.png','gbox_photo.png','wheel_photo.png']
old=WORK/'nima_v07/complete'
unchanged=[n for n in NATIVE if (old/n).read_bytes()==(OUT/n).read_bytes()]
assert unchanged==NATIVE[1:3]
prior_shapes=resources(old/'STNIMA.3SH')
new_shapes=resources(OUT/'STNIMA.3SH')
assert all(prior_shapes[k]==new_shapes[k] for k in ['car0','car1','car2'])
old_sim=resources(old/'CARNIMA.RES')['simd'];new_sim=resources(OUT/'CARNIMA.RES')['simd']
assert old_sim[:0xea]==new_sim[:0xea] and old_sim[0x128:]==new_sim[0x128:]
assert sum(a!=b for a,b in zip(old_sim,new_sim))==57
shapes=resources(OUT/'STNIMA.3SH');expected_wheels=[38]*8+[76,80,64]
for name,b in shapes.items():
 v,p,n=parse_shape(b);assert n==11
 if name.startswith('car'):
  assert sum(x['mats']==[45]*11 for x in p)==2
  for wheel in p[:4]:assert wheel['mats']==expected_wheels
for detailed in [True,False]:
 model=build(detailed)
 assert sum(p['tag']=='sunroof' for p in model.prims)==1
 assert all(set(p['mats'])<={39,20} for p in model.prims if p['tag']=='splitter')

with tempfile.TemporaryDirectory(prefix='nima_v08_rebuild_') as td:
 p=Path(td)
 for n in SOURCES:shutil.copyfile(ROOT/n,p/n)
 for script in ['build_model.py','build_dashboard.py']:
  subprocess.run([sys.executable,str(p/script)],check=True,capture_output=True)
 for n in NATIVE:assert (p/'complete'/n).read_bytes()==(OUT/n).read_bytes(),n

base_tests=json.loads((old/'NATIVE_TESTS.json').read_text())
queue=json.loads(subprocess.run([str(ROOT/'validate_model'),str(OUT/'STNIMA.3SH'),str(ROOT/'native_queue_view.json')],check=True,capture_output=True,text=True).stdout)
tests={'native_loader':base_tests['native_loader'],'loader_evidence_reused_for_identical_dashboard_bytes':True,
       'native_queue':queue,'restunts_bb11_commit':'20682046eb620e40150fcf60e0a3ae51d97831b8',
       'dos_gameplay_test':False,'deterministic_rebuild_all_four_files':True,'unchanged_from_V07':unchanged}
(OUT/'NATIVE_TESTS.json').write_text(json.dumps(tests,indent=2)+'\n')
a=json.loads((OUT/'DASHBOARD_AUDIT.json').read_text());a.update(native_loader_test=tests['native_loader'],
    native_3d_queue_test=queue,deterministic_rebuild=True,dos_gameplay_test=False)
a['sha256']={n:hashlib.sha256((OUT/n).read_bytes()).hexdigest() for n in NATIVE}
(OUT/'DASHBOARD_AUDIT.json').write_text(json.dumps(a,indent=2)+'\n')
audit={'sunroof':{'state':'closed smoked glass','native_material':20,'corner_design_mm':[-420,420,130,-350],
                  'roof_y_mm':1280,'coplanar_overlay':False,'all_three_car_models':True},
       'splitter':{'main_material':39,'main_RGB':'#202020','edge_material':20,'edge_RGB':'#383838'},
       'paint_jobs':11,'new_paints':PAINTS[8:],'wheel_material_triplets':[[m,m+1,m+2] for m in [76,80,64]],
       'roof_vertex_budget':'Four roof-glass vertices added; four internal engine-rib vertices freed; outer body unchanged',
       'engine_bay':'Shared-edge black backing prevents far-side stripe colours showing through hood aperture'}
audit['sakura']={'variants':4,'petals_per_variant':1,'native_units':'car1 / on-track',
 'faces_per_variant':4,'vertices_per_variant':6,'stock_motion_retained':True,
 'unchanged_car_models':['car0','car1','car2'],'shared_2d_blast_unchanged':True}
for k in ['exp0','exp1','exp2','exp3']:
 v,p,n=parse_shape(shapes[k]);assert len(v)==6 and len(p)==4
 assert max(v.max(0)-v.min(0))<16 and abs(v.mean(0)).max()<2
 audit['sakura'][k]={'bounds_native':[v.min(0).tolist(),v.max(0).tolist()]}
audit['steering_alignment']=json.loads((OUT/'STEERING_ALIGNMENT.json').read_text())
audit['changed_CARNIMA_byte_range']=['0xea','0x127'];audit['changed_CARNIMA_byte_count']=57
(OUT/'RETOUCHES_V08.json').write_text(json.dumps(audit,indent=2)+'\n')

font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',18)
small=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',13)
trio=Image.new('RGB',(1200,440),'#171c22');d=ImageDraw.Draw(trio)
for i,(paint,desc) in enumerate([(8,'Argent + magenta / roues chromées'),(9,'Or + violet / roues dorées'),(10,'Cyan + bleu nuit / roues cyan')]):
 trio.paste(render(shapes['car0'],paint=paint,size=(400,340),elev=22),(i*400,35))
 d.text((i*400+14,9),PAINTS[paint]['name'],font=font,fill='white')
 d.text((i*400+14,382),desc,font=small,fill='#cbd0d8')
d.text((14,417),'Inspection des ressources exportées — pas une capture du jeu.',font=small,fill='#cbd0d8')
trio.save(OUT/'TOKYO_DRIFT_TRIO_V08.png')
detail=Image.new('RGB',(1100,430),'#171c22');d=ImageDraw.Draw(detail)
for i,(yaw,elev,title) in enumerate([(35,31,'Toit ouvrant fumé intégré au pavillon'),(0,12,'Lame anthracite et arête graphite')]):
 detail.paste(render(shapes['car0'],yaw=yaw,elev=elev,size=(550,370)),(i*550,32))
 d.text((i*550+12,8),title,font=small,fill='white')
detail.save(OUT/'TOIT_ET_LAME_V08.png')


# Positions/rotations illustrate the actual meshes at car1 scale, not a replay.
extra=[]
for j in range(18):
 angle=j*2.39996323;r=13+1.15*j
 offset=(r*__import__('math').cos(angle),15+(j%6)*3,r*__import__('math').sin(angle))
 extra.append((shapes['exp'+str(j%4)],offset,(j*31,j*47,j*59)))
scene=render(shapes['car1'],size=(1100,570),elev=20,extra=extra)
sakura_im=Image.new('RGB',(1100,650),'#191e24');sakura_im.paste(scene,(0,40))
d=ImageDraw.Draw(sakura_im)
d.text((18,14),'Sakura — 18 petits pétales roses et blancs / échelle car1',font=font,fill='white')
d.text((18,626),'Disposition illustrative des maillages natifs ; trajectoires et animation en jeu non capturées.',font=small,fill='#cbd0d8')
sakura_im.save(OUT/'SAKURA_V08.png')

dest=ROOT/PACK;dest.mkdir(exist_ok=True)
for n in ['NIMADATA','SOURCES','AUDITS','APERCUS']:(dest/n).mkdir(exist_ok=True)
for n in NATIVE:shutil.copyfile(OUT/n,dest/'NIMADATA'/n)
installer(dest)
for n in ['READMEFR.TXT','READMEEN.TXT','CHANGES.TXT']:
 (dest/n).write_bytes((ROOT/n).read_text().replace('\n','\r\n').encode('utf-8'))
shutil.copyfile(ROOT/'ASTUCES_CONSTRUCTION_STUNTS_MAJ.md',dest/'ASTUCES_CONSTRUCTION_STUNTS_MAJ.md')
for p in OUT.glob('*.png'):shutil.copyfile(p,dest/'APERCUS'/p.name)
for p in OUT.glob('*.json'):shutil.copyfile(p,dest/'AUDITS'/p.name)
shutil.copyfile(ROOT/'INSTALLER_TESTS.json',dest/'AUDITS/INSTALLER_TESTS.json')
for n in SOURCES+['validate_loader.c','validate_model.c','make_installer.py','test_installer.py','model_geometry.json','PROMPTS_IMAGEGEN.txt','finalize_pack.py']:
 shutil.copyfile(ROOT/n,dest/'SOURCES'/n)
shutil.copytree(ROOT/'bitmap_sources',dest/'SOURCES/bitmap_sources',dirs_exist_ok=True)
for source,target in [('AUDIT_NIMA_V01.json','AUDIT_MOTEUR_V01.json'),('COURBE_NIMA_V01.csv','COURBE_MOTEUR.csv')]:
 shutil.copyfile(WORK/'output'/source,dest/'AUDITS'/target)
shutil.copyfile(WORK/'output/COURBE_NIMA_V01.png',dest/'APERCUS/COURBE_MOTEUR.png')
shutil.copyfile(WORK/'nima_v05/complete/DASHBOARD_ET_GBOX_V05.png',dest/'APERCUS/DASHBOARD_ET_GBOX.png')

# End-to-end checks using the actual shipped folder and native binary payload.
e2e=[]
with tempfile.TemporaryDirectory(prefix='nima_v08_pack_') as td:
 for nt in [False,True]:
  game=Path(td)/('Stunts Windows with spaces' if nt else 'STUNTS');game.mkdir()
  (game/'GAME.EXE').write_bytes(b'fixture only, not executed');(game/'CAROTHER.RES').write_bytes(b'do not change')
  pack=game/PACK;shutil.copytree(dest,pack)
  originals={}
  if not nt:
   # Simulate an active V07 installation with its original backup in Stunts.
   backup=game/'NIMABAK';backup.mkdir();(backup/'READY.NIM').write_text('V07 original backup')
   for n in MANAGED:
    originals[n]=('pre-V07-'+n).encode();(backup/n).write_bytes(originals[n])
   for n in NATIVE:(game/n).write_bytes((old/n).read_bytes())
  vm=Batch(Path(td) if nt else pack,nt=nt)
  vm.run(pack/'NIMAINST.BAT')
  for n in NATIVE:assert (game/n).read_bytes()==(dest/'NIMADATA'/n).read_bytes()
  assert not any((pack/n).exists() for n in NATIVE)
  vm.run(pack/'NIMAINST.BAT');vm.run(pack/'NIMAUNIN.BAT');restored(game,originals)
  e2e.append({'mode':'Windows branch, spaced path' if nt else 'DOS subset, V07 backup upgrade','status':'PASS'})
e={'status':'PASS','real_payload_parent_install_and_restore':e2e,'actual_shell_execution':False}
(dest/'AUDITS/PACK_LAYOUT_TESTS.json').write_text(json.dumps(e,indent=2)+'\n')
for n in ['NIMAINST.BAT','NIMAUNIN.BAT']:
 b=(dest/n).read_bytes();assert b==(ROOT/'installer'/n).read_bytes()
 assert b'\r\n' in b and all(c<128 for c in b) and b'SETLOCAL' not in b.upper()
lines=[]
for p in sorted(dest.rglob('*')):
 if p.is_file() and p.name!='SHA256SUMS.txt':lines.append(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(dest).as_posix())
(dest/'SHA256SUMS.txt').write_text('\n'.join(lines)+'\n')
archive=WORK/'output'/(PACK+'.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,9) as z:
 for p in sorted(dest.rglob('*')):
  if p.is_file():z.write(p,Path(PACK)/p.relative_to(dest))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and {n.split('/')[0] for n in z.namelist()}=={archive.stem}
 for line in z.read(PACK+'/SHA256SUMS.txt').decode().splitlines():
  h,n=line.split('  ',1);assert hashlib.sha256(z.read(PACK+'/'+n)).hexdigest()==h
for n in ['TOKYO_DRIFT_TRIO_V08.png','TOIT_ET_LAME_V08.png','ALIGNEMENT_VOLANT_V08.png','SAKURA_V08.png','CENTRE_4x3.png']:shutil.copyfile(OUT/n,WORK/'output'/n)
print(json.dumps({'archive':str(archive),'root_folder':archive.stem,'bytes':archive.stat().st_size,'manifest_files_verified':len(lines),
                  'native_queue_cases':3168,'brake_state_cases':66,'petal_cases':4224,'installer_filesystem_scenarios':1028,
                  'real_payload_parent_layout_scenarios':2,'native_rebuild':'PASS','unchanged_native_files':unchanged},indent=2))
