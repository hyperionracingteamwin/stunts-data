#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "externs.h"
#include "shape3d.h"
#include "shape3d_internal.h"
#include "car_model.h"
#include "projection.h"
#undef printf
#undef memcpy
legacy_u8 atantable[257];
legacy_u8 vector_saved_z_low, vector_saved_z_high;
static legacy_u8 queue_bytes[POLYINFO_SUPERSIGHT_DATA_SIZE+32];
static struct SHAPE3D shape;
static struct TRANSFORMEDSHAPE3D instance;
static struct RECTANGLE bounds;
static int append_mode;
static void setup(legacy_u8 *raw,int high,int yaw,int pitch,int paint) {
 memset(&shape,0,sizeof(shape));memset(&instance,0,sizeof(instance));
 shape3d_init_shape((legacy_s8*)raw,&shape);
 instance.shapeptr=&shape;instance.rectptr=&bounds;
 instance.ts_flags=10;instance.culling_distance=1024;instance.material=paint;
 instance.pos.x=0;instance.pos.y=high?-100:-5;instance.pos.z=high?2300:115;
 instance.rotvec.x=0;instance.rotvec.y=pitch;instance.rotvec.z=yaw;
 bounds.left=bounds.top=32767;bounds.right=bounds.bottom=-32768;
 projection_focal_length_x=256;projection_focal_length_y=256;
 select_rect_rc.left=0;select_rect_rc.right=319;select_rect_rc.top=0;select_rect_rc.bottom=199;
 mat_temp=*mat_rot_zxy(0,0,0,MATRIX_ROTATION_ORDER_ZXY);
 backlights_paint_override=BACKLIGHT_PAINT_NORMAL;
 polyinfoptr=queue_bytes;if(!append_mode)polyinfo_reset();
}
static void dump(FILE *f) {
 fprintf(f,"[");
 polyinfo_index record_index=POLYINFO_LEGACY_PRIMITIVE_CAPACITY;
 for(unsigned i=0;i<polyinfonumpolys;i++) {
  record_index=(polyinfo_index)polygon_next_index[record_index];
  assert(record_index<polyinfonumpolys);
  legacy_u8 *r=polyinfoptr+polygon_record_offsets[record_index];
  unsigned n=r[3];assert(n<=20);
  if(i)fprintf(f,",");
  fprintf(f,"{\"depth\":%u,\"material\":%u,\"type\":%u,\"points\":[",LEGACY_READ_U16_LE(r),r[2],r[4]);
  for(unsigned j=0;j<n;j++)fprintf(f,"%s[%d,%d]",j?",":"",LEGACY_READ_S16_LE(r+6+4*j),LEGACY_READ_S16_LE(r+8+4*j));
  fprintf(f,"]}");
 }
 fprintf(f,"]\n");
}
int main(int argc,char **argv) {
 assert(argc==3);FILE *f=fopen(argv[1],"rb");assert(f);
 static legacy_u8 file[65536];size_t size=fread(file,1,sizeof(file),f);fclose(f);
 assert(size>20);unsigned n=LEGACY_READ_U16_LE(file+4),start=6+8*n,cases=0;
 assert(n==7);unsigned brake_cases=0;
 for(unsigned si=0;si<3;si++) {
  legacy_u8 *raw=file+start+LEGACY_READ_U32_LE(file+6+4*n+4*si);
  assert(raw[0]<=255 && raw[1]<=255 && raw[2]==11);
  unsigned p=4+6*raw[0]+8*raw[1];
  for(unsigned wheel=0;wheel<4;wheel++) {
   assert(raw[p]==12);unsigned indices=p+2+raw[2];
   for(unsigned k=0;k<6;k++)assert(raw[indices+k]==8+6*wheel+k);
   p=indices+6;
  }
  for(int paint=0;paint<raw[2];paint++)for(int pitch=-96;pitch<=96;pitch+=96)for(int yaw=0;yaw<1024;yaw+=32) {
   setup(raw,si==0,yaw,pitch,paint);
   assert(shape3d_transform_and_queue(&instance)==0);
   assert(polyinfonumpolys>30 && polyinfonumpolys<=raw[1]);cases++;
  }
  for(int paint=0;paint<raw[2];paint++)for(int braking=0;braking<2;braking++) {
   setup(raw,si==0,0,0,paint);
   backlights_paint_override=braking?BACKLIGHT_PAINT_BRAKING:BACKLIGHT_PAINT_NORMAL;
   assert(shape3d_transform_and_queue(&instance)==0);
   unsigned expected=braking?47:46,lights=0;
   for(unsigned j=0;j<polyinfonumpolys;j++) {
    legacy_u8 *record=polyinfoptr+polygon_record_offsets[j];
    assert(record[2]!=45);
    if(record[2]==expected)lights++;
    assert(record[2]!=(braking?46:47));
   }
   assert(lights==2);brake_cases++;
  }
  if(si==0) {
   f=fopen(argv[2],"w");assert(f);setup(raw,1,620,60,0);
   assert(shape3d_transform_and_queue(&instance)==0);dump(f);fclose(f);
  }
 }
 unsigned petal_cases=0;
 for(unsigned si=3;si<7;si++) {
  legacy_u8 *raw=file+start+LEGACY_READ_U32_LE(file+6+4*n+4*si);
  assert(raw[0]==6 && raw[1]==4 && raw[2]==11);
  for(int paint=0;paint<raw[2];paint++)for(int pitch=-96;pitch<=96;pitch+=96)for(int yaw=0;yaw<1024;yaw+=32) {
   setup(raw,0,yaw,pitch,paint);
   assert(shape3d_transform_and_queue(&instance)==0);
   assert(polyinfonumpolys>0 && polyinfonumpolys<=raw[1]);petal_cases++;
  }
 }
 unsigned burst_cases=0,max_burst_polys=0;
 for(int paint=0;paint<11;paint++)for(int yaw=0;yaw<1024;yaw+=128) {
  legacy_u8 *body=file+start+LEGACY_READ_U32_LE(file+6+4*n+4);
  append_mode=0;setup(body,0,yaw,0,paint);
  assert(shape3d_transform_and_queue(&instance)==0);
  append_mode=1;
  for(unsigned j=0;j<18;j++) {
   legacy_u8 *petal=file+start+LEGACY_READ_U32_LE(file+6+4*n+4*(3+j%4));
   setup(petal,0,(yaw+j*57)%1024,((int)(j%3)-1)*64,paint);
   instance.pos.x=((int)(j%6)-3)*9;instance.pos.y=-12-(j/6)*9;
   assert(shape3d_transform_and_queue(&instance)==0);
  }
  assert(polyinfonumpolys<POLYINFO_LEGACY_PRIMITIVE_CAPACITY);
  if(polyinfonumpolys>max_burst_polys)max_burst_polys=polyinfonumpolys;
  burst_cases++;
 }
 printf("{\"native_queue_cases\":%u,\"native_brake_cases\":%u,\"native_petal_cases\":%u,\"native_burst_cases\":%u,\"max_burst_polygons\":%u,\"brake_selector\":45,\"normal\":46,\"braking\":47,\"wheel_vertices_8_to_31\":true,\"status\":\"PASS\"}\n",cases,brake_cases,petal_cases,burst_cases,max_burst_polys);
 return 0;
}
