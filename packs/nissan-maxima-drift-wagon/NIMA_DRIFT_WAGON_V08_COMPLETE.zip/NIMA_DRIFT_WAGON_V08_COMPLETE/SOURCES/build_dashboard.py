"""NIMA V05: full photographic cabin, compact wheel, native moving parts."""
from pathlib import Path
import math,struct,json,hashlib
import numpy as np
from PIL import Image,ImageDraw
from build_model import PAL,OUT,res_pack

ROOT=Path(__file__).resolve().parent
ASSETS=ROOT/'bitmap_sources';ASSETS.mkdir(exist_ok=True)
DASHY=97
WHEEL=(124,149)
SPEED=(105,123);TACH=(143,123)
IX,IY,IW,IH=87,106,75,31
WX,WY,WW,WH=62,97,125,103
GX,GY,GW,GH=273,164,40,36

def indexed(a):
 im=Image.fromarray(np.asarray(a,dtype=np.uint8),'P');im.putpalette(PAL.flatten().tolist());return im
def rgb(a):return Image.fromarray(PAL[np.asarray(a,dtype=np.uint8)],'RGB')
def quant(im):
 a=np.asarray(im.convert('RGB'),dtype=np.int32)
 # Native VGA palette, never reserve white index 255 as an opaque color.
 return ((a[:,:,None,:]-PAL[:255].astype(int)[None,None,:,:])**2).sum(-1).argmin(-1).astype(np.uint8)
def bitmap(a,x=0,y=0,anchor=(0,0)):
 a=np.asarray(a,dtype=np.uint8);h,w=a.shape
 return struct.pack('<6h4B',w,h,*anchor,x,y,1,2,4,8)+a.tobytes()
def res_read(b):
 total,n=struct.unpack_from('<IH',b);assert total==len(b);start=6+8*n
 names=[b[6+4*i:10+4*i].decode() for i in range(n)];off=struct.unpack_from('<'+'I'*n,b,6+4*n)
 return {k:b[start+off[i]:start+(off[i+1] if i+1<n else len(b)-start)] for i,k in enumerate(names)}
def getbmp(b):
 w,h,ax,ay,x,y=struct.unpack_from('<6h',b)
 return x,y,np.frombuffer(b[16:16+w*h],np.uint8).reshape(h,w).copy(),(ax,ay)

source=Image.open(ROOT/'cockpit_photo.png').convert('RGB').resize((320,200),Image.Resampling.LANCZOS)
raw=quant(source)
# Keep the full photographed lower cabin in its original image proportions.
# Only the window above DASHY is delegated to the native 3D road renderer.
base=raw.copy()
# Main gauge components use the original photographic bezels, slightly enlarged
# within the native instrument panel for readable labels at 320x200.
for center,srcx in [(SPEED,105),(TACH,143)]:
 bezel=source.crop((srcx-18,107,srcx+18,137)).resize((38,34),Image.Resampling.LANCZOS)
 base[center[1]-17:center[1]+17,center[0]-19:center[0]+19]=quant(bezel)
FONT={
 '0':['111','101','101','101','111'],'1':['010','110','010','010','111'],
 '2':['111','001','111','100','111'],'3':['111','001','111','001','111'],
 '4':['101','101','111','001','001'],'5':['111','100','111','001','111'],
 '6':['111','100','111','101','111'],'7':['111','001','010','010','010'],
 '8':['111','101','111','101','111'],'9':['111','101','111','001','111'],
 'M':['101','111','111','101','101'],'P':['110','101','110','100','100'],
 'H':['101','101','111','101','101'],'R':['110','101','110','101','101'],
 ' ':['000']*5}
def label(d,x,y,text,color=17,center=False):
 if center:x-=(len(text)*4-1)//2
 for ch in text:
  for yy,line in enumerate(FONT.get(ch,FONT[' '])):
   for xx,v in enumerate(line):
    if v=='1':d.point((x+xx,y+yy),fill=color)
  x+=4
def tip(c,value,maximum,rx,ry):
 a=math.radians(140+260*min(max(value,0),maximum)/maximum)
 return round(c[0]+rx*math.cos(a)),round(c[1]+ry*math.sin(a))

# Preserve the photographic silver bezels and the recessed gauge shading.
# Only functional marks/labels are placed inside their existing empty faces.
im=indexed(base);d=ImageDraw.Draw(im)
for c in [SPEED,TACH]:
 x,y=c;d.ellipse((x-16,y-14,x+16,y+14),fill=0)
for value in range(0,181,10):
 d.line([tip(SPEED,value,180,15,13),tip(SPEED,value,180,14,12)],fill=17)
for value in [0,60,120]:
 x,y=tip(SPEED,value,180,8 if value else 10,8);label(d,x,y-2,str(value),17,True)
label(d,SPEED[0],SPEED[1]+8,'MPH',24,True)
for value in range(17):
 d.line([tip(TACH,value,16,15,13),tip(TACH,value,16,14,12)],fill=12 if value>=15 else 17)
for value in [0,2,4,6,8]:
 x,y=tip(TACH,value,8,11,10);label(d,x,y-2,str(value),12 if value==8 else 17,True)
label(d,TACH[0],TACH[1]+8,'RPM',24,True)
for c in [SPEED,TACH]:d.rectangle((c[0]-1,c[1]-1,c[0]+1,c[1]+1),fill=27)
base=np.asarray(im).copy()

# The photographic wheel has actual alpha in its openings. Rotate it before
# aspect correction and palette conversion; no procedural glove or arm exists.
wheel=Image.open(ROOT/'wheel_photo.png').convert('RGBA')
alpha=np.array(wheel.getchannel('A'));yy,xx=np.where(alpha>=128)
crop=(int(xx.min()),int(yy.min()),int(xx.max())+1,int(yy.max())+1)
wheel=wheel.crop(crop)
side=max(wheel.size);square=Image.new('RGBA',(side,side));square.alpha_composite(wheel,((side-wheel.width)//2,(side-wheel.height)//2));wheel=square

def radial_band(image,angle):
 # Read the actual cut-out rim, before VGA aspect correction. Spokes can join
 # the inner edge near horizontal; only the outer edge is trusted there.
 alpha=np.asarray(image.getchannel('A'));radius=np.arange(side*.36,side*.51,.25)
 a=math.radians(angle);c=(side-1)/2
 xx=np.rint(c+radius*math.sin(a)).astype(int);yy=np.rint(c-radius*math.cos(a)).astype(int)
 inside=(xx>=0)&(xx<side)&(yy>=0)&(yy<side)
 radius=radius[inside];v=alpha[yy[inside],xx[inside]]>=128
 runs=np.split(np.where(v)[0],np.where(np.diff(np.where(v)[0])>1)[0]+1)
 run=max(runs,key=lambda r:radius[r[-1]])
 return float(radius[run[0]]),float(radius[run[-1]])

rim_thickness=float(np.median([hi-lo for a in range(-60,61,5) for lo,hi in [radial_band(wheel,a)]]))
steering_points=[];rim_targets={}
for i in range(31):
 angle=i*2.5;key='whl2' if i<=10 else 'whl3'
 rotated=wheel.rotate(0 if i<=10 else -35,Image.Resampling.BICUBIC,expand=False)
 # The stock engine reflects X about table[0] for negative steering. Average
 # both sides of the photograph so one symmetric table follows both rims.
 radii=[]
 for sign in [-1,1]:
  frame=rotated if sign>0 else wheel.rotate(0 if i<=10 else 35,Image.Resampling.BICUBIC,expand=False)
  lo,hi=radial_band(frame,sign*angle)
  radii.append(hi-rim_thickness/2)
 radius=sum(radii)/2;a=math.radians(angle)
 # The 8x8 Renault marker has centroid (3.5,3.5), anchor (4,4).
 # Account for that half pixel instead of anchoring its upper-left corner.
 x=125+round(radius*125/side*math.sin(a))
 y=round(WHEEL[1]-radius*105/side*math.cos(a)+.5)
 steering_points.append((x,y))
 for sign,rad in zip([-1,1],radii):
  rim_targets[sign*i]=(WHEEL[0]+sign*rad*125/side*math.sin(a),WHEEL[1]-rad*105/side*math.cos(a))
layers={};opaque={};composites={}
for key,angle in [('whl1',35),('whl2',0),('whl3',-35)]:
 frame=wheel.rotate(angle,Image.Resampling.BICUBIC,expand=False).resize((125,105),Image.Resampling.LANCZOS)
 a=np.asarray(frame);mask=a[:,:,3]>=128;pixels=quant(frame)
 layer=np.zeros((200,320),np.uint8);op=np.zeros((200,320),bool)
 h=min(200-WY,105);layer[WY:WY+h,WX:WX+WW]=pixels[:h]
 op[WY:WY+h,WX:WX+WW]=mask[:h]
 layers[key]=layer;opaque[key]=op;comp=base.copy();comp[op]=layer[op];composites[key]=comp

blocks={};meta={}
def add(k,a,x,y,anchor=(0,0)):
 a=np.asarray(a,dtype=np.uint8);blocks[k]=bitmap(a,x,y,anchor)
 meta[k]={'width':a.shape[1],'height':a.shape[0],'xy':[int(x),int(y)],'anchor':list(anchor)}
 indexed(a).save(ASSETS/(k.strip()+'.png'))

add('dash',base[DASHY:,:],0,DASHY)
# The headliner stays at screen top; the independent pillar joins its original
# upper endpoint to the repositioned dashboard, without shrinking its width.
roof=raw[:7];add('roof',roof,0,0)
pillar_rgb=source.crop((0,7,56,DASHY)).resize((56,DASHY-7),Image.Resampling.LANCZOS)
pa=quant(pillar_rgb)
pm=Image.new('1',(56,DASHY-7));pd=ImageDraw.Draw(pm)
pd.polygon([(0,0),(13,0),(47,DASHY-8),(31,DASHY-8)],fill=1)
op=np.asarray(pm)>0;pa[~op]=0
add('dast',pa,0,7);add('dasm',np.where(op,0,255).astype(np.uint8),0,7)
for k in layers:add(k,composites[k][WY:WY+WH,WX:WX+WW],WX,WY)

# Center-pose panel supplies the rim underlay. Left/right masks restore exactly
# the photographed foreground; absent center-pose parts are restored too.
panel=composites['whl2'][IY:IY+IH,IX:IX+IW].copy();add('ins2',panel,IX,IY)
for suffix,key in [('1','whl1'),('3','whl3')]:
 current=composites[key][IY:IY+IH,IX:IX+IW]
 current_op=opaque[key][IY:IY+IH,IX:IX+IW]
 center_op=opaque['whl2'][IY:IY+IH,IX:IX+IW]
 restore=current_op|center_op
 yy,xx=np.where(restore)
 if len(xx):
  x0,x1,y0,y1=int(xx.min()),int(xx.max())+1,int(yy.min()),int(yy.max())+1
  mk=restore[y0:y1,x0:x1]
  add('ins'+suffix,np.where(mk,current[y0:y1,x0:x1],0).astype(np.uint8),x0,y0)
  add('inm'+suffix,np.where(mk,0,255).astype(np.uint8),x0,y0)
 else:
  add('ins'+suffix,np.zeros((1,1),np.uint8),0,0);add('inm'+suffix,np.full((1,1),255,np.uint8),0,0)

# A native gear-change overlay with photo-derived chrome knob, separate from
# the static hydraulic handbrake already in the dashboard photograph.
gbox=quant(Image.open(ROOT/'gbox_photo.png').convert('RGB').resize((GW,GH),Image.Resampling.LANCZOS))
gi=indexed(gbox)
add('gbox',np.asarray(gi),GX,GY)
primary=res_pack(blocks);(OUT/'STDANIMA.VSH').write_bytes(primary)

secondary={}
# Keep the existing chrome knob and native mask; only its gbox base changes.
previous_secondary=res_read((ROOT/'STDBNIMA_V03.VSH').read_bytes())
_,_,knob,_=getbmp(previous_secondary['gnob'])
_,_,knob_mask,_=getbmp(previous_secondary['gnab']);kop=knob_mask==0
secondary['gnob']=previous_secondary['gnob'];secondary['gnab']=previous_secondary['gnab']
# Steering marker: same 8x8 round silhouette and VGA yellow as the Renault.
dot=np.array([[0,0,0,0,0,0,0,0],
              [0,0,0,71,71,0,0,0],
              [0,0,71,71,71,71,0,0],
              [0,71,71,71,71,71,71,0],
              [0,71,71,71,71,71,71,0],
              [0,0,71,71,71,71,0,0],
              [0,0,0,71,71,0,0,0],
              [0,0,0,0,0,0,0,0]],dtype=np.uint8)
secondary['dot ']=bitmap(dot,0,0,(4,4));secondary['dota']=bitmap(np.where(dot!=0,0,255).astype(np.uint8),0,0,(4,4))
for k in ['dot1','dot2']:secondary[k]=bitmap(np.zeros((8,24),np.uint8))
for n in range(10):
 im=Image.new('P',(8,7),0);im.putpalette(PAL.flatten().tolist());label(ImageDraw.Draw(im),2,1,str(n),15)
 secondary['dig'+str(n)]=bitmap(np.asarray(im))
(OUT/'STDBNIMA.VSH').write_bytes(res_pack(secondary))

initial=ROOT/'CARNIMA_V02.RES'
if not initial.exists():initial=ROOT.parent/'nima_work/complete/CARNIMA.RES'
car=res_read(initial.read_bytes());before=car['simd'];s=bytearray(before)
def word(off,v):struct.pack_into('<H',s,off,v)
knobpts=[(20,18),(12,8),(12,28),(20,8),(20,28),(28,8),(28,28)]
for i,p in enumerate(knobpts):struct.pack_into('<hh',s,0x1c+4*i,*p)
for off,v in [(0xae,12),(0xc8,18),(0xca,22),(0xcc,43),(0xce,52),(0xd0,14)]:word(off,v)
# Rear track follows the new rear wheel axes: ±855 mm, round to physical units.
rear=round(.855/.06096*64)
struct.pack_into('<h',s,0xd2+2*6,rear);struct.pack_into('<h',s,0xd2+3*6,-rear)
for i,p in enumerate(steering_points):s[0xea+2*i:0xec+2*i]=bytes(p)
struct.pack_into('<hhh',s,0x128,SPEED[0]-IX,SPEED[1]-IY,73)
struct.pack_into('<hhh',s,0x1fe,TACH[0]-IX,TACH[1]-IY,64)
for off,c,maximum,count,step,rx,ry in [(0x12e,SPEED,180,104,2.5,11,9),(0x204,TACH,8000,128,128,11,9)]:
 for i in range(count):
  x,y=tip(c,i*step,maximum,rx,ry);s[off+2*i:off+2*i+2]=bytes([x-IX,y-IY])
car['simd']=bytes(s);(OUT/'CARNIMA.RES').write_bytes(res_pack(car,align=False))
assert car['edes'].endswith(b']\0') and s[:0x1c]==before[:0x1c] and s[0x3a:0xa2]==before[0x3a:0xa2]

def line_pixels(a,b):
 im=Image.new('1',(320,200));ImageDraw.Draw(im).line([a,b],fill=1);return np.asarray(im)>0
hits={};centerglyph_hits=0
for k in layers:
 hits[k]=0
 for c,off,count in [(SPEED,0x12e,73),(TACH,0x204,64)]:
  for i in range(count):
   x,y=s[off+2*i:off+2*i+2];hits[k]+=int(np.count_nonzero(line_pixels(c,(IX+x,IY+y))&opaque[k]))

def marker_position(steer):
 x,y=steering_points[abs(steer)]
 return (2*steering_points[0][0]-x if steer<0 else x),y

marker_checks=[]
for steer in range(-30,31):
 key='whl1' if steer<-10 else 'whl3' if steer>10 else 'whl2'
 x,y=marker_position(steer);cy,cx=np.where(dot!=0)
 covered=bool(opaque[key][y-4+cy,x-4+cx].all())
 target=rim_targets[steer];error=math.dist((x-.5,y-.5),target)
 marker_checks.append({'steering':steer,'xy':[x,y],'centroid':[x-.5,y-.5],
                        'measured_rim_midpoint':target,'error_pixels':error,'all_pixels_on_rim':covered})
assert all(p['all_pixels_on_rim'] for p in marker_checks)
assert max(p['error_pixels'] for p in marker_checks)<1.5
(OUT/'STEERING_ALIGNMENT.json').write_text(json.dumps({'positions':marker_checks,
 'source_rim_thickness_px':rim_thickness,'sprite_centroid':[3.5,3.5],'sprite_anchor':[4,4],
 'native_negative_x_reflection':True,'max_error_pixels':max(p['error_pixels'] for p in marker_checks)},indent=2)+'\n')

def preview(key='whl2',speed=90,rpm=5400,gear=None,steer=None):
 # Test scenery, independent of the photographic source outside the cockpit.
 a=np.full((200,320),131,np.uint8);a[92:]=108
 im=indexed(a);dd=ImageDraw.Draw(im);dd.polygon([(138,92),(182,92),(320,136),(0,136)],fill=25);a=np.asarray(im).copy()
 a[DASHY:]=base[DASHY:];a[:7]=roof
 sub=a[7:DASHY,:56];sub[op]=pa[op]
 a[WY:WY+WH,WX:WX+WW]=composites[key][WY:WY+WH,WX:WX+WW]
 a[IY:IY+IH,IX:IX+IW]=panel
 im=indexed(a);dd=ImageDraw.Draw(im)
 for c,off,idx in [(SPEED,0x12e,min(72,int(speed/2.5))),(TACH,0x204,min(63,int(rpm/128)))]:
  x,y=s[off+2*idx:off+2*idx+2];dd.line([c,(IX+x,IY+y)],fill=12)
 a=np.asarray(im).copy()
 if key!='whl2':
  suffix=key[-1];x,y,ar,_=getbmp(blocks['ins'+suffix]);_,_,mk,_=getbmp(blocks['inm'+suffix]);h,w=ar.shape
  sub=a[IY+y:IY+y+h,IX+x:IX+x+w];sub[mk==0]=ar[mk==0]
 # Center marker uses the same native sprite, mask and anchor as STDB.
 if steer is None:steer={'whl1':-20,'whl2':0,'whl3':20}[key]
 x,y=marker_position(steer);sub=a[y-4:y+4,x-4:x+4];dop=dot!=0;sub[dop]=dot[dop]
 if gear is not None:
  a[GY:GY+GH,GX:GX+GW]=np.asarray(gi);kx,ky=knobpts[gear];xx,yy=GX+kx-6,GY+ky-6
  sub=a[yy:yy+12,xx:xx+12];sub[kop]=knob[kop]
 return rgb(a)

for k,tag in [('whl1','GAUCHE'),('whl2','CENTRE'),('whl3','DROITE')]:
 preview(k).save(OUT/(tag+'_320x200.png'));preview(k).resize((960,720),Image.Resampling.NEAREST).save(OUT/(tag+'_4x3.png'))
preview('whl2',120,7400,3).resize((960,720),Image.Resampling.NEAREST).save(OUT/'CHANGEMENT_RAPPORT.png')
sheet=Image.new('RGB',(960,264),'#17191e');dd=ImageDraw.Draw(sheet)
for i,k in enumerate(['whl1','whl2','whl3']):
 sheet.paste(preview(k).resize((320,240),Image.Resampling.NEAREST),(i*320,24));dd.text((i*320+8,6),['Gauche','Centre','Droite'][i],fill='white')
sheet.save(OUT/'DASHBOARD_TROIS_POSES.png')
sheet=Image.new('RGB',(125*5*2,103*3*2+75),'#17191e');dd=ImageDraw.Draw(sheet)
for j,steer in enumerate([-30,-25,-20,-15,-10,-5,0,5,10,15,20,25,30]):
 key='whl1' if steer<-10 else 'whl3' if steer>10 else 'whl2'
 tile=preview(key,steer=steer).crop((WX,WY,WX+WW,WY+WH)).resize((250,206),Image.Resampling.NEAREST)
 xx=j%5*250;yy=j//5*231;sheet.paste(tile,(xx,yy+25));dd.text((xx+8,yy+7),'Steering '+str(steer),fill='white')
sheet.save(OUT/'ALIGNEMENT_VOLANT_V08.png')

audit={'version':'NIMA V08 / 2026-10-27','hands_present':False,
 'full_lower_cabin_photo_implemented':True,'source_vertical_shift':0,'dashboard_top':DASHY,
 'left_mirror_removed':True,'gbox_source':'Dedicated photographic black leather gaiter bitmap',
 'gauge_centers_screen':{'speed_mph':SPEED,'tach_rpm':TACH},'wheel_center_screen':WHEEL,
 'gauge_layout':'Two native animated gauges inside upper steering-wheel opening',
 'boost_gauge':'Separate static photographic boost gauge on right, no native pressure signal',
 'hydraulic_handbrake':'Static photographic lever and black ribbed grip on console; no new input binding',
 'native_needle_intersections_with_wheel':hits,
 'center_pose_native_occlusion_supported':False,
 'resources':meta,'stda_bytes':len(primary),'stdb_bytes':(OUT/'STDBNIMA.VSH').stat().st_size,
 'stda_two_raw_buffers_estimate':2*len(primary),'engine_and_gearing_preserved':True,
 'rear_track_design_mm':1710,'eyes_above_axle_car1_units':14,
 'needle_color_index':12,'speed_unit':'mph','tach_unit':'rpm x 1000',
 'source_generation':'Photographic bitmap sources generated from user Nissan photographs and R5 quality reference; native palette conversion and calibrated animated parts',
 'preview_note':'Native resource composites over test scenery, not DOS gameplay screenshots',
 'native_loader_test':'pending','native_3d_queue_test':'pending',
 'sha256':{n:hashlib.sha256((OUT/n).read_bytes()).hexdigest() for n in ['CARNIMA.RES','STDANIMA.VSH','STDBNIMA.VSH','STNIMA.3SH']}}
(OUT/'DASHBOARD_AUDIT.json').write_text(json.dumps(audit,indent=2)+'\n')
print(json.dumps({'stda':len(primary),'stdb':audit['stdb_bytes'],'needle_intersections':hits},indent=2))
