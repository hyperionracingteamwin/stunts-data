#include <assert.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

 #include "externs.h"
 #include "fileio.h"
 #include "memmgr.h"
 #include "platform.h"
 #include "resource.h"
 #include "shape2d.h"

#undef printf
#define TEST_PARAGRAPH_BYTES 16U
#define TEST_ARENA_START 4096U
#define TEST_ARENA_END 32768U
#define TEST_SHAPE_COUNT 5U
#define TEST_SHAPE_WIDTH 160U
#define TEST_SHAPE_HEIGHT 96U
#define TEST_SHAPE_BYTES (SHAPE2D_HEADER_SIZE + TEST_SHAPE_WIDTH * TEST_SHAPE_HEIGHT)
#define TEST_RESOURCE_BYTES (6U + TEST_SHAPE_COUNT * (8U + TEST_SHAPE_BYTES))
#define TEST_RESOURCE_PARAGRAPHS (TEST_RESOURCE_BYTES / TEST_PARAGRAPH_BYTES + 1U)

legacy_u8 palmap[16];
legacy_s8 *shapeexts[] = {""};

static union {
	legacy_u32 alignment;
	legacy_u8 bytes[TEST_ARENA_END * TEST_PARAGRAPH_BYTES];
} test_memory;
static legacy_u8 resource_fixture[300000];
static legacy_u32 fixture_bytes;

static legacy_u32 load_count;

void fatal_error(const legacy_s8 *format, ...)
{
	fprintf(stderr, "Unexpected shape loader error: %s\n", format);
	abort();
}

void *_memcpy(void *destination, const void *source, legacy_u16 length)
{
	return memmove(destination, source, length);
}

void far *__fmemcpy(void far *destination, const void far *source, legacy_u16 length)
{
	return memmove(destination, source, length);
}

void far *dos_memory_make_pointer(legacy_u16 segment, legacy_u16 offset)
{
	size_t address = (size_t)segment * TEST_PARAGRAPH_BYTES + offset;
	assert(address < sizeof(test_memory.bytes));
	return test_memory.bytes + address;
}

legacy_u16 dos_memory_pointer_segment(const void far *pointer)
{
	ptrdiff_t address = (const legacy_u8 *)pointer - test_memory.bytes;
	assert(address >= 0 && (size_t)address < sizeof(test_memory.bytes));
	return (legacy_u16)((size_t)address / TEST_PARAGRAPH_BYTES);
}

legacy_u16 dos_memory_pointer_offset(const void far *pointer)
{
	ptrdiff_t address = (const legacy_u8 *)pointer - test_memory.bytes;
	assert(address >= 0 && (size_t)address < sizeof(test_memory.bytes));
	return (legacy_u16)((size_t)address % TEST_PARAGRAPH_BYTES);
}

void far *dos_memory_get_psp(void)
{
	return dos_memory_make_pointer(TEST_ARENA_START - 16U, 0U);
}

legacy_u16 dos_memory_allocate(legacy_u16 paragraphs)
{
	assert(paragraphs <= TEST_ARENA_END - TEST_ARENA_START);
	return TEST_ARENA_START;
}

legacy_u16 dos_memory_resize(legacy_u16 segment, legacy_u16 paragraphs)
{
	assert(segment == TEST_ARENA_START);
	assert(paragraphs <= TEST_ARENA_END - TEST_ARENA_START);
	return paragraphs;
}

const legacy_s8 *file_find(const legacy_s8 *name)
{
	(void)name;
	abort();
}

void far *file_decomp(const legacy_s8 *name, legacy_s16 fatal)
{
	(void)name;
	(void)fatal;
	abort();
}

void far *file_load_binary(const legacy_s8 *name, legacy_s16 fatal)
{
	assert(strcmp((const char *)name, "TEST.VSH") == 0);
	assert(fatal != 0);
	load_count++;
	legacy_u8 *resource = mmgr_alloc_resbytes(name, fixture_bytes);
	memmove(resource, resource_fixture, fixture_bytes);
	return resource;
}


int main(int argc,char **argv) {
 assert(argc==2); FILE *f=fopen(argv[1],"rb"); assert(f);
 fixture_bytes=fread(resource_fixture,1,sizeof(resource_fixture),f);fclose(f);
 assert(fixture_bytes>20 && fixture_bytes<sizeof(resource_fixture));
 memset(test_memory.bytes,0xa5,sizeof(test_memory.bytes));
 mmgr_alloc_resmem(TEST_ARENA_END);
 unsigned available=200000/16;
 mmgr_alloc_pages("PINNED",TEST_ARENA_END-TEST_ARENA_START-available);
 legacy_u8 *resource=file_load_shape2d_res_fatal("TEST.VSH");
 unsigned count=resource_file_count(resource_fixture), decoded_pixels=0;size_t last_end=0;
 assert(resource_file_count(resource)==count);
 for(unsigned i=0;i<count;i++) {
  legacy_u8 *dst=resource_file_data(resource,i),*src=resource_file_data(resource_fixture,i);
  assert(memcmp(dst,src,16)==0);
  unsigned w=LEGACY_READ_U16_LE(src),h=LEGACY_READ_U16_LE(src+2),n=w*h,out=0;
  legacy_u8 *code=dst+16,*pixels=src+16;
  for(;;) {
   int c=LEGACY_S8_FROM_BITS(*code++);if(!c)break;
   unsigned len=c<0?-c:c;assert(out+len<=n);
   for(unsigned j=0;j<len;j++) assert(pixels[out++]==(c<0?*code++:*code));
   if(c>0)code++;
  }
  assert(out==n);decoded_pixels+=n;last_end=(size_t)(code-resource);
 }
 printf("{\"file\":\"%s\",\"raw\":%lu,\"rle_end\":%lu,\"resource_count\":%u,\"pixels_checked\":%u,\"budget\":200000,\"status\":\"PASS\"}\n",argv[1],(unsigned long)fixture_bytes,(unsigned long)last_end,count,decoded_pixels);
 return 0;
}
