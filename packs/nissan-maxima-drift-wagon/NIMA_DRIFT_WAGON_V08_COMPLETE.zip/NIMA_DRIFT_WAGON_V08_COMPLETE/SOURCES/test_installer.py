"""Execute the shipped flat BAT subset against temporary filesystem fixtures.

This tests file preservation and rollback, NOT a real Windows/DOS shell.
"""
from pathlib import Path
import re,shlex,shutil,tempfile,json
from make_installer import build,MANAGED,NATIVE

class Batch:
    def __init__(self,cwd,nt=False,fail=None):
        self.cwd=Path(cwd);self.nt=nt;self.error=0;self.fail=fail;self.failed=False
    def path(self,s):
        s=s.strip('"').replace('\\','/')
        return (self.cwd/s).resolve()
    def exists(self,s):
        if s.upper().endswith('\\NUL'):return self.path(s[:-4]).is_dir()
        return self.path(s).exists()
    def run(self,script,arg=''):
        script=Path(script).resolve();lines=script.read_text().splitlines()
        labels={s[1:].upper():i for i,s in enumerate(lines) if s.startswith(':')}
        pc=0;steps=0
        def cmd(line):
            nonlocal pc
            line=line.strip().lstrip('@');lo=line.lower()
            if not line or line.startswith(':') or lo.startswith('rem '):return
            if lo.startswith('goto '):pc=labels[line[5:].strip().upper()];return
            if lo.startswith('if '):
                m=re.match(r'if (not )?exist (\S+) (.+)',line,re.I)
                if m:
                    yes=self.exists(m[2]);yes=not yes if m[1] else yes
                    if yes:cmd(m[3])
                    return
                m=re.match(r'if errorlevel (\d+) (.+)',line,re.I)
                if m:
                    if self.error>=int(m[1]):cmd(m[2])
                    return
                m=re.match(r'if "([^"]*)"=="([^"]*)" (.+)',line,re.I)
                assert m,line
                if m[1]==m[2]:cmd(m[3])
                return
            left,sep,target=line.partition('>');parts=shlex.split(left,posix=False)
            op=parts[0].lower();self.error=0
            if op in ['pause'] or lo=='echo off':return
            if op=='echo':
                if sep and target.strip().lower()!='nul':
                    try:self.path(target.strip()).write_text(left[5:].strip()+'\n')
                    except OSError:self.error=1
                return
            if op=='cd':
                assert self.nt and parts[1].lower()=='/d'
                p=self.path(parts[2])
                if p.is_dir():self.cwd=p
                else:self.error=1
                return
            if op=='call':self.run(self.path(parts[1]),parts[2] if len(parts)>2 else '');return
            key=(op,parts[2] if op=='copy' else parts[1])
            if self.fail and not self.failed and self.fail(op,parts):
                self.error=1;self.failed=True;return
            try:
                if op=='md':self.path(parts[1]).mkdir()
                elif op=='rd':self.path(parts[1]).rmdir()
                elif op=='del':self.path(parts[1]).unlink()
                elif op=='copy':
                    assert parts[1].lower()=='/b'
                    shutil.copyfile(self.path(parts[2]),self.path(parts[3]))
                else:raise AssertionError(line)
            except OSError:self.error=1
        while pc<len(lines):
            line=lines[pc];pc+=1;steps+=1;assert steps<1500
            line=line.replace('%OS%','Windows_NT' if self.nt else '')
            line=line.replace('%~dp0',str(script.parent)+'/').replace('%1',arg)
            cmd(line)

def fixtures(p,mask):
    p.mkdir();pack=p/'NIMA_DRIFT_WAGON_V08_COMPLETE';build(pack);(pack/'NIMADATA').mkdir()
    for n in NATIVE:(pack/'NIMADATA'/n).write_bytes(('V08-'+n).encode())
    (p/'GAME.EXE').write_bytes(b'fixture, not a game executable')
    (p/'CAROTHER.RES').write_bytes(b'do not change')
    originals={}
    for i,n in enumerate(MANAGED):
        if mask&(1<<i):
            originals[n]=('ORIGINAL-'+n).encode();(p/n).write_bytes(originals[n])
    return originals

def restored(p,old):
    for n in MANAGED:
        if n in old:assert (p/n).read_bytes()==old[n],n
        else:assert not (p/n).exists(),n
    assert (p/'CAROTHER.RES').read_bytes()==b'do not change'

def main():
    cases=0
    with tempfile.TemporaryDirectory(prefix='nima_install_') as td:
        base=Path(td)
        # Every combination of existing native and compressed NIMA files.
        for nt in [False,True]:
            for mask in range(1<<len(MANAGED)):
                p=base/('Windows path with spaces' if nt else 'DOSGAME')
                old=fixtures(p,mask);pack=p/'NIMA_DRIFT_WAGON_V08_COMPLETE'
                vm=Batch(base if nt else pack,nt)
                vm.run(pack/'NIMAINST.BAT')
                for n in NATIVE:assert (p/n).read_bytes()==(pack/'NIMADATA'/n).read_bytes()
                for n in MANAGED[4:]:assert not (p/n).exists()
                vm.run(pack/'NIMAINST.BAT') # Do not replace the original snapshot.
                vm.run(pack/'NIMAUNIN.BAT');restored(p,old)
                vm.run(pack/'NIMAUNIN.BAT');restored(p,old)
                assert not (p/'NIMABAK').exists()
                shutil.rmtree(p);cases+=1
        for scenario in ['missing_payload','incomplete_backup','failed_backup','failed_install']:
            p=base/scenario;old=fixtures(p,(1<<len(MANAGED))-1);pack=p/'NIMA_DRIFT_WAGON_V08_COMPLETE'
            if scenario=='missing_payload':(pack/'NIMADATA/STNIMA.3SH').unlink()
            if scenario=='incomplete_backup':(p/'NIMABAK').mkdir()
            fail=None
            if scenario=='failed_backup':fail=lambda op,a:op=='copy' and a[3]=='..\\NIMABAK\\STDANIMA.VSH'
            if scenario=='failed_install':fail=lambda op,a:op=='copy' and a[2]=='NIMADATA\\STDBNIMA.VSH'
            vm=Batch(pack,fail=fail);vm.run(pack/'NIMAINST.BAT');restored(p,old)
            shutil.rmtree(p);cases+=1
    r={'status':'PASS','filesystem_scenarios':cases,'existing_file_combinations_per_mode':512,
       'installation_target':'Parent of pack folder; backup also in parent',
       'modes_simulated':['DOS batch subset','Windows branch with spaced script path'],
       'includes':['repeat install','repeat uninstall','native and compressed restoration','missing payload',
                   'incomplete backup refusal','backup write failure','automatic install rollback'],
       'real_cmd_or_DOSBox_execution':False}
    (Path(__file__).parent/'INSTALLER_TESTS.json').write_text(json.dumps(r,indent=2)+'\n')
    print(json.dumps(r))

if __name__=='__main__':main()
