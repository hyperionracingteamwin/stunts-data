"""Structural audit of final NIMA resources, independent of bitmap creation."""
from pathlib import Path
import struct, json, sys, hashlib
import numpy as np
from build_model import parse_shape, patterns, NPAINT

def resources(path):
    b=Path(path).read_bytes();total,n=struct.unpack_from('<IH',b)
    assert total==len(b)
    names=[b[6+4*i:10+4*i].decode() for i in range(n)]
    offsets=struct.unpack_from('<'+'I'*n,b,6+4*n);start=6+8*n
    assert list(offsets)==sorted(offsets) and len(set(names))==n
    return {name:b[start+offsets[i]:start+(offsets[i+1] if i+1<n else len(b)-start)] for i,name in enumerate(names)}

def main(folder):
    root=Path(folder);car=resources(root/'CARNIMA.RES');sim=car['simd']
    assert car['edes'].endswith(b']\0') and b'by Alain il Professore' in car['edes']
    assert struct.unpack_from('<5H',sim,0x10)==(50000,34100,25000,18440,12550)
    assert struct.unpack_from('<hhh',sim,0x128)==(18,17,73)
    assert struct.unpack_from('<hhh',sim,0x1fe)==(56,17,64)
    baseline=Path(__file__).parent/'CARNIMA_V02.RES'
    if baseline.exists():
        old=resources(baseline)['simd']
        assert sim[:0x1c]==old[:0x1c] and sim[0x3a:0xa2]==old[0x3a:0xa2]
    for start,count in [(0x12e,104),(0x204,128)]:
        points=np.frombuffer(sim[start:start+count*2],np.uint8).reshape(-1,2)
        assert (points[:,0]<75).all() and (points[:,1]<31).all()
    bitmaps={}
    for filename in ['STDANIMA.VSH','STDBNIMA.VSH']:
        blocks=resources(root/filename);info={}
        for name,block in blocks.items():
            w,h,ax,ay,x,y=struct.unpack_from('<6h',block)
            assert w>0 and h>0 and 16+w*h<=len(block)
            pixels=np.frombuffer(block[16:16+w*h],np.uint8)
            if name.startswith('inm') or name in ['dasm','gnab','dota']:
                assert set(pixels)<=set([0,255])
            info[name]={'size':[w,h],'xy':[x,y]}
        bitmaps[filename]=info
    shapes={}
    for name,block in resources(root/'STNIMA.3SH').items():
        verts,prims,npaint=parse_shape(block);assert len(verts)<=255 and npaint==NPAINT
        zero=0
        for p in prims:
            assert all(patterns[m]==0 for m in p['mats'])
            if 3<=p['type']<=10:
                pts=verts[p['idx']]
                area=sum((np.cross(pts[j]-pts[0],pts[j+1]-pts[0]) for j in range(1,len(pts)-1)),start=np.zeros(3))
                zero+=int(np.linalg.norm(area)<.1)
        assert zero==0,(name,zero)
        if name.startswith('car'):
            for i in range(4):
                assert prims[i]['type']==12 and prims[i]['idx']==list(range(8+6*i,14+6*i))
                assert all(patterns[m+j]==0 for m in prims[i]['mats'] for j in range(3))
        shapes[name]={'vertices':len(verts),'primitives':len(prims),'zero_area_faces':zero}
    result={'status':'PASS','shapes':shapes,'bitmaps':bitmaps,'engine_and_gears_preserved':True,
            'signature_preserved':True,'sha256':{n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in ['CARNIMA.RES','STDANIMA.VSH','STDBNIMA.VSH','STNIMA.3SH']}}
    (root/'STRUCTURAL_AUDIT.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':'PASS','zero_area_faces':0,'shapes':shapes}))

if __name__=='__main__': main(sys.argv[1] if len(sys.argv)>1 else Path(__file__).parent/'complete')
