from pathlib import Path
import struct, json, math, re
import numpy as np
from PIL import Image, ImageDraw, ImageFont

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'complete'; OUT.mkdir(exist_ok=True)
CONF=ROOT/'defaults.conf'
if not CONF.exists():CONF=ROOT.parent/'stressed/resources/conf/defaults.conf'
text=CONF.read_text()
palette=[tuple(bytes.fromhex(x)) for x in re.findall(r'#([0-9A-Fa-f]{6})',text.split('[materials]')[0])]
colors=list(map(int,re.findall(r'\d+',text.split('colors=')[1].split('patterns=')[0])))
patterns=list(map(int,re.findall(r'\d+',text.split('patterns=')[1].split('\n[')[0])))
PAL=np.array(palette,dtype=np.uint8)
PAINTS=[
 {'name':'Ivory / red 68','body':31,'top':15,'shadow':27,'stripe':4,'rim':40},
 {'name':'Tokyo red','body':54,'top':55,'shadow':53,'stripe':15,'rim':26},
 {'name':'Nismo blue','body':100,'top':100,'shadow':49,'stripe':15,'rim':40},
 {'name':'Black / orange','body':39,'top':19,'shadow':0,'stripe':99,'rim':26},
 {'name':'Gunmetal / purple','body':59,'top':78,'shadow':57,'stripe':73,'rim':40},
 {'name':'Green / black','body':69,'top':71,'shadow':68,'stripe':0,'rim':40},
 {'name':'White / red','body':79,'top':15,'shadow':77,'stripe':54,'rim':40},
 {'name':'Yellow / black','body':61,'top':63,'shadow':60,'stripe':0,'rim':26},
 {'name':'Pachinko Silver','body':79,'top':15,'shadow':77,'stripe':116,'rim':78,'wheel':76},
 {'name':'Golden Streets','body':83,'top':62,'shadow':80,'stripe':73,'rim':82,'wheel':80},
 {'name':'Cyberpunk Cyan Blue','body':65,'top':67,'shadow':48,'stripe':116,'rim':66,'wheel':64},
]
for p in PAINTS[:8]:p.update(wheel=38,rim=40)
NPAINT=len(PAINTS)

def res_pack(blocks,align=True):
 names=list(blocks);payload=bytearray();off=[]
 for k in names:
  off.append(len(payload));payload.extend(blocks[k]);payload.extend(b'\0'*(-len(payload)%16) if align else b'')
 return struct.pack('<IH',6+8*len(names)+len(payload),len(names))+''.join(names).encode()+struct.pack('<'+'I'*len(names),*off)+payload

class Model:
 def __init__(self):self.vertices=[];self.lookup={};self.prims=[]
 def vertex(self,p):
  q=tuple(round(v/3.048) for v in (p[0],p[1]-300,p[2]))
  if q not in self.lookup:self.lookup[q]=len(self.vertices);self.vertices.append(q)
  return self.lookup[q]
 def prim(self,pts,mat,kind=None,tag=''):
  idx=[self.vertex(p) for p in pts]
  mats=[p[mat] for p in PAINTS] if isinstance(mat,str) else [mat]*NPAINT
  assert all(patterns[value]==0 for value in mats),('non-solid material',mats)
  # Closed shell surfaces use two-sided native faces. No coplanar decals.
  self.prims.append({'type':kind or len(pts),'flags':1,'mats':mats,'idx':idx,'tag':tag})
 def quad(self,pts,mat,tag=''):self.prim(pts,mat,tag=tag)
 def box(self,x0,x1,y0,y1,z0,z1,mat):
  p=[(x0,y0,z0),(x1,y0,z0),(x1,y1,z0),(x0,y1,z0),(x0,y0,z1),(x1,y0,z1),(x1,y1,z1),(x0,y1,z1)]
  for a in [(0,3,2,1),(4,5,6,7),(0,4,7,3),(1,2,6,5),(3,7,6,2),(0,1,5,4)]:self.quad([p[i] for i in a],mat)
 def export(self,scale=1,omit_tags=(),bounds=True):
  prim=[p for p in self.prims if p['tag'] not in omit_tags]
  attached={side:[p for p in prim if p['tag']=='number_'+str(side)] for side in [-1,1]}
  base=[p for p in prim if not p['tag'].startswith('number_')]
  prim=[]
  for p in base:
   prim.append(p)
   for side in [-1,1]:
    if p['tag']=='panel_'+str(side):prim.extend(attached[side])
  # The original executable animates fixed vertex slots 8..31. Wheels must
  # precede the body in both the vertex list and primitive list, clockwise.
  prim=[p for p in prim if p['type']==12]+[p for p in prim if p['type']!=12]
  # Eight bounding-box vertices precede the shared geometry, like Stressed.
  used=list(dict.fromkeys(i for p in prim for i in p['idx']));v=np.array([self.vertices[i] for i in used],int)
  v=np.rint(v*scale).astype(int)
  lo=v.min(axis=0);hi=v.max(axis=0)
  bbox=[(x,y,z) for y in [lo[1],hi[1]] for z in [hi[2],lo[2]] for x in [lo[0],hi[0]]] if bounds else []
  allv=list(map(tuple,bbox));remap={};body_lookup={}
  wheel_ids={i for p in prim if p['type']==12 for i in p['idx']}
  for old,point in zip(used,v):
   q=tuple(point)
   if scale<1 and old not in wheel_ids and q in body_lookup:remap[old]=body_lookup[q]
   else:
    remap[old]=len(allv);allv.append(q)
    if old not in wheel_ids:body_lookup[q]=remap[old]
  removed_degenerate=0
  if scale<1:
   kept=[]
   for p in prim:
    if 3<=p['type']<=10:
     pts=np.array([allv[remap[i]] for i in p['idx']])
     area=sum((np.cross(pts[j]-pts[0],pts[j+1]-pts[0]) for j in range(1,len(pts)-1)),start=np.zeros(3))
     if np.linalg.norm(area)<.1:removed_degenerate+=1;continue
    kept.append(p)
   prim=kept
  assert len(allv)<=255,('vertex overflow',len(allv))
  assert len(prim)<=255,('primitive overflow',len(prim))
  raw=bytes([len(allv),len(prim),NPAINT,0])+b''.join(struct.pack('<hhh',*p) for p in allv)
  raw+=b'\xff'*(8*len(prim))
  for p in prim:raw+=bytes([p['type'],p['flags']]+p['mats']+[remap[i] for i in p['idx']])
  return raw+b'\0\0\0',{'vertices':len(allv),'primitives':len(prim),'paintjobs':NPAINT,'degenerate_faces_removed_after_native_rounding':removed_degenerate}

def build(detailed=True):
 m=Model();F=2372;R=-2372;B=850;L=220;W=820
 # Rear flare shoulder continues from the wheel arch to the tailgate.
 for side in [-1,1]:
  x=side*W
  arcs=[]
  for zc in [1312,-1312]:
   # Five points define the convex arch profile; the physical wheel remains circular.
   arc=[(zc+340,300),(zc+175,620),(zc-175,620),(zc-340,300)]
   arcs.append(arc)
   if detailed or zc<0:
    outer=1030 if zc<0 else 955
    upper=[(x,B,z) for z,y in arc]
    shoulder=[(side*(W if i in [0,3] else outer),690 if i in [0,3] else 760,z) for i,(z,y) in enumerate(arc)]
    if zc<0:shoulder[3]=(side*outer,760,arc[3][0])
    opening=[(side*(W if i in [0,3] else outer-25),y,z) for i,(z,y) in enumerate(arc)]
    for i in range(3):
     m.quad([upper[i],upper[i+1],shoulder[i+1],shoulder[i]],'body','flare_shoulder')
     m.quad([shoulder[i],shoulder[i+1],opening[i+1],opening[i]],'shadow','flare_lip')
   else:
    for (z0,y0),(z1,y1) in zip(arc,arc[1:]):m.quad([(x,y0,z0),(x,B,z0),(x,B,z1),(x,y1,z1)],'body')
  ends=[(F,1652),(972,-972),(-1652,R)]
  for z0,z1 in ends:
   y0=300 if z0!=F else L;y1=300 if z1!=R else L
   if z0==972:
    m.quad([(x,y0,z0),(x,410,z0),(x,410,z1),(x,y1,z1)],'shadow')
    m.quad([(x,410,z0),(x,570,z0),(x,570,z1),(x,410,z1)],'stripe')
    m.quad([(x,570,z0),(x,B,z0),(x,B,z1),(x,570,z1)],'body','panel_'+str(side))
   elif z0==-1652:
    m.quad([(x,300,z0),(side*1030,760,z0),(side*1030,760,R),(x,300,R)],'body','rear_quarter_lower')
    m.quad([(side*1030,760,z0),(x,B,z0),(x,B,R),(side*1030,760,R)],'body','rear_quarter_shoulder')
    m.prim([(x,300,R),(side*1030,760,R),(x,B,R)],'shadow',tag='rear_flare_end')
   else:m.quad([(x,y0,z0),(x,B,z0),(x,B,z1),(x,y1,z1)],'body')
  # Wheel sills below the hatch and nose.
  for z0,z1 in [(F,1652),(-1652,R)]:
   m.quad([(x,L,z0),(x,300,z0),(x,300,z1),(x,L,z1)],'shadow')
 # Lower floor, split at axle stations to limit average-depth sorting conflicts.
 for z0,z1 in [(F,1312),(1312,-1312),(-1312,R)]:
  m.quad([(-W,L,z0),(W,L,z0),(W,L,z1),(-W,L,z1)],0,'floor')
 # Flat-topped hood with a real opening, rather than a coplanar engine decal.
 def hood(x,z):return (x,850,z)
 if detailed:
  for xy in [[(-W,750),(W,750),(W,1100),(-W,1100)],
             [(-W,1100),(-400,1100),(-400,1850),(-W,1850)],
             [(400,1100),(W,1100),(W,1850),(400,1850)],
             [(-W,1850),(W,1850),(W,F),(-W,F)]]:
   m.quad([hood(x,z) for x,z in xy],'top')
  # A shared-edge black backing closes the bay so far-side paint cannot show
  # through it in the native average-depth sort. No overlap with hood panels.
  m.quad([(-400,850,1100),(400,850,1100),(400,850,1850),(-400,850,1850)],0,'engine_bay')
  # Bevelled graphite inline-six cover; no red engine material in any paint.
  section=[(-180,800),(180,800),(120,960),(-120,960)]
  front=[(x,y,1120) for x,y in section];back=[(x,y,1830) for x,y in section]
  m.prim(front,20,tag='engine');m.prim(back[::-1],20,tag='engine')
  for i in range(4):
   j=(i+1)%4;m.quad([front[i],front[j],back[j],back[i]],39 if i==2 else 20,'engine')
   if i==2:
    for z in [1120,1357,1593,1830]:
     m.prim([(-120,960,z),(120,960,z)],40,2,'engine_rib');m.prims[-1]['flags']=3
  m.quad([(-300,820,1120),(-120,960,1120),(-120,960,1830),(-300,820,1830)],40,'engine')
 else:m.quad([hood(-W,750),hood(W,750),hood(W,F),hood(-W,F)],'top')
 # Door glass shares frame edges in the same surface, without overlaid quads.
 for side in [-1,1]:
  def cab(u,v):return (side*(780-105*v),850+430*v,(750-2950*u)*(1-v)+(300-2200*u)*v)
  if detailed:
   us=[0,.35,.38,.67,.70,1]
   for j,(u0,u1) in enumerate(zip(us,us[1:])):
    if j in [0,2,4]:
     m.quad([cab(u0,0),cab(u1,0),cab(u1,1),cab(u0,1)],43,'glass')
    else:m.quad([cab(u0,0),cab(u1,0),cab(u1,1),cab(u0,1)],'body')
  else:
   for u0,u1 in [(0,.38),(.38,.70),(.70,1)]:m.quad([cab(u0,0),cab(u1,0),cab(u1,1),cab(u0,1)],43)
  # Belt shoulder links the wider lower body and the cabin base.
  m.quad([(side*W,B,750),(side*780,B,750),(side*780,B,-2200),(side*W,B,-2200)],'body')
 # Closed smoked sunroof, integrated in the first roof panel, no overlay.
 # Four surrounding panels share the four glass corners and roof boundary.
 outer=[(-675,1280,300),(675,1280,300),(675,1280,-470),(-675,1280,-470)]
 inner=[(-420,1280,130),(420,1280,130),(420,1280,-350),(-420,1280,-350)]
 for i in range(4):
  j=(i+1)%4;m.quad([outer[i],outer[j],inner[j],inner[i]],'top','roof_frame')
 m.quad(inner,20,'sunroof')
 for z0,z1 in [(-470,-1240),(-1240,-1900)]:
  m.quad([(-675,1280,z0),(675,1280,z0),(675,1280,z1),(-675,1280,z1)],'top','roof')
 # Windscreen/rear glass: side trims integrated into the panel grid.
 for is_front in [True,False]:
  z0,z1=(750,300) if is_front else (-2200,-1900)
  def glass(u,v):return ((2*u-1)*(780-105*v),850+430*v,z0*(1-v)+z1*v)
  m.quad([glass(0,0),glass(1,0),glass(1,1),glass(0,1)],43)
 # Rear deck and bumper.
 m.quad([(-W,B,-2200),(W,B,-2200),(W,B,R),(-W,B,R)],'body')
 for z,back in [(F,False),(R,True)]:
  if not back:
   # Four individual rectangular lamps directly under the hood edge, as on
   # the supplied service-manual front elevation. Shared in-plane borders.
   m.quad([(-W,L,z),(W,L,z),(W,400,z),(-W,400,z)],0,'front_airdam')
   m.quad([(-W,400,z),(W,400,z),(W,600,z),(-W,600,z)],19,'front_bumper')
   m.prim([(-W,600,z),(W,600,z)],40,2,'bumper_trim');m.prims[-1]['flags']=3
   xs=[-W,-740,-530,-460,-280,280,460,530,740,W]
   for j,(x0,x1) in enumerate(zip(xs,xs[1:])):
    ma=63 if j in [1,3,5,7] else (39 if j in [2,4,6] else 99)
    m.quad([(x0,600,z),(x1,600,z),(x1,800,z),(x0,800,z)],ma,'front_lamp' if j in [1,3,5,7] else 'front_grille')
    if j==4:
     for y in [665,735]:
      m.prim([(-280,y,z),(280,y,z)],27,2,'grille_slat');m.prims[-1]['flags']=3
   m.quad([(-W,800,z),(W,800,z),(W,B,z),(-W,B,z)],'body','front_brow')
   continue
  ys=[L,400,610,B]
  for k,(y0,y1) in enumerate(zip(ys,ys[1:])):
   xs=[-W,-650,-310,310,650,W] if k==1 else [-W,W]
   for j,(x0,x1) in enumerate(zip(xs,xs[1:])):
    ma=0 if k==0 else 'body'
    if k==1:
     # 45 is the native brake-light selector: renders as 46 or 47.
     ma=45 if j in [1,3] else (0 if j==2 else 'body')
    m.quad([(x0,y0,z),(x1,y0,z),(x1,y1,z),(x0,y1,z)],ma,'rear_lamp' if k==1 and j in [1,3] else 'rear_body')
 # Front splitter and subtle roof spoiler.
 m.quad([(-980,180,F+180),(980,180,F+180),(900,225,F-180),(-900,225,F-180)],39,'splitter')
 # Fender mirrors: closed black housings above the front wheels, not doors.
 # The inner bottom corners are shared by the tapered solid mounting stalk.
 for side in [-1,1]:
  # Housing center is exactly over the designed tire's leading edge:
  # front axle 1312 mm + tire radius 300 mm = 1612 mm.
  x0,x1=side*850,side*1060;z0,z1=1542,1682;y0,y1=1070,1190
  q=[(x0,y0,z0),(x1,y0,z0),(x1,y1,z0),(x0,y1,z0),
     (x0,y0,z1),(x1,y0,z1),(x1,y1,z1),(x0,y1,z1)]
  for ids in [(0,3,2,1),(4,5,6,7),(0,4,7,3),(1,2,6,5),(3,7,6,2),(0,1,5,4)]:
   m.quad([q[i] for i in ids],40 if ids==(0,3,2,1) else 20,'fender_mirror')
  # Mount on the existing arch-front shoulder, 40 mm ahead of the tire edge.
  stem=[(side*W,850,1652),(side*875,850,1652),q[0],q[4]]
  for ids in [(0,1,2),(0,3,1),(0,2,3),(1,3,2)]:
   m.prim([stem[i] for i in ids],20,tag='mirror_stalk')
 if detailed:
  m.quad([(-W,L,F),(W,L,F),(900,300,F+70),(-900,300,F+70)],39,'splitter')
  m.quad([(-900,300,F+70),(900,300,F+70),(980,180,F+180),(-980,180,F+180)],20,'splitter')
  for side in [-1,1]:m.quad([(side*900,300,F+70),(side*980,180,F+180),(side*900,225,F-180),(side*W,L,F)],39,'splitter')
  m.quad([(-720,1280,-1850),(720,1280,-1850),(735,1340,-2080),(-735,1340,-2080)],'body','spoiler')
  m.quad([(-735,1340,-2080),(735,1340,-2080),(735,1300,-2080),(-735,1300,-2080)],'shadow','spoiler')
  m.quad([(-720,1280,-1850),(-735,1300,-2080),(735,1300,-2080),(720,1280,-1850)],0,'spoiler')
  for side in [-1,1]:m.prim([(side*720,1280,-1850),(side*735,1340,-2080),(side*735,1300,-2080)],'shadow',tag='spoiler')
 # Native line numbers are readable in every exterior detail level.
 segs=[(0,1),(0,2),(1,3),(2,3),(2,4),(3,5),(4,5)]
 for side in [-1,1]:
  for digit,start in [('6',360),('8',-40)]:
   if digit=='6':
    # Upright handwritten six: upward-right hook and a CLOSED lower bowl.
    # Local u always reads left-to-right from OUTSIDE the corresponding side.
    glyph=[(1,0),(0,.5),(1,.5),(1,1),(0,1)]
    edges=[(0,1),(1,2),(2,3),(3,4),(4,1)]
   else:
    glyph=[(col,row/2) for row in range(3) for col in [0,1]];edges=segs
   pts=[(side*826,810-v*200,side*(start-u*240)) for u,v in glyph]
   for a,b in edges:
    m.prim([pts[a],pts[b]],0,2,'number_'+str(side));m.prims[-1]['flags']=3
 for p in m.prims:
  if p['tag'].startswith('number_'):p['mats']=[0,15,15,15,15,0,0,0]+[0]*(NPAINT-8)
 # Four animated native Stunts wheels (six axis points, type 12).
 for zc,side in [(1312,-1),(1312,1),(-1312,1),(-1312,-1)]:
   xi=side*(720 if zc<0 else 630);xo=side*(990 if zc<0 else 890);r=300;y=300
   # Same handedness as the stock car: z-axis radius flips across the car.
   m.prim([(xi,y,zc),(xi,y+r,zc),(xi,y,zc-side*r),
           (xo,y,zc),(xo,y+r,zc),(xo,y,zc-side*r)],'wheel',12,'wheel')
 return m

def parse_shape(data):
 nv,nprim,nc,_=data[:4];v=np.array([struct.unpack_from('<hhh',data,4+6*i) for i in range(nv)])
 pos=4+6*nv+8*nprim;p=[]
 for _ in range(nprim):
  typ,flags=data[pos:pos+2];pos+=2;mats=list(data[pos:pos+nc]);pos+=nc
  n=6 if typ==12 else 2 if typ==11 else typ;idx=list(data[pos:pos+n]);pos+=n
  assert max(idx)<nv and 1<=typ<=12
  p.append({'type':typ,'flags':flags,'mats':mats,'idx':idx})
 return v,p,nc

def render(data,paint=0,yaw=35,elev=17,size=(640,400),braking=False,extra=()):
 v,prim,nc=parse_shape(data);v=v.astype(float)
 for raw,offset,angles in extra:
  ev,ep,_=parse_shape(raw);ev=ev.astype(float)
  ax,ay,az=np.radians(angles)
  for a,axes in [(ax,(1,2)),(ay,(2,0)),(az,(0,1))]:
   i,j=axes;u=ev[:,i].copy();w=ev[:,j].copy()
   ev[:,i]=u*math.cos(a)-w*math.sin(a);ev[:,j]=u*math.sin(a)+w*math.cos(a)
  shift=len(v);v=np.concatenate([v,ev+np.asarray(offset)])
  prim.extend([{**p,'idx':[i+shift for i in p['idx']]} for p in ep])
 # Independent illustration from the exported native geometry; not a game capture.
 az,el=np.radians([yaw,elev]);right=np.array([math.cos(az),0,-math.sin(az)])
 look=np.array([math.sin(az)*math.cos(el),math.sin(el),math.cos(az)*math.cos(el)])
 up=np.cross(look,right);pv=np.stack([v@right,-v@up,v@look],axis=1)
 xmin,ymin=pv[:,:2].min(0);xmax,ymax=pv[:,:2].max(0)
 scale=min((size[0]-60)/(xmax-xmin),(size[1]-55)/(ymax-ymin))
 xy=(pv[:,:2]-[(xmin+xmax)/2,(ymin+ymax)/2])*scale+[size[0]/2,size[1]/2]
 im=Image.new('RGB',size,'#191e24');d=ImageDraw.Draw(im)
 # Ground shadow and painter sorting are only an export inspection aid.
 d.ellipse((size[0]*.18,size[1]*.72,size[0]*.87,size[1]*.88),fill='#101418')
 queue=[]
 for p in prim:
  ids=p['idx'];depth=pv[ids,2].mean()
  if p['flags']&2 and queue:queue[-1][1].append(p)
  else:queue.append((depth,[p]))
 ordered=[p for depth,group in sorted(queue,key=lambda q:q[0]) for p in group]
 for p in ordered:
  ids=p['idx'];ma=p['mats'][paint]
  if ma==45:ma=47 if braking else 46
  rgb=tuple(PAL[colors[ma]])
  pts=[tuple(xy[j]) for j in ids]
  if p['type']==12:
   # Approximate native wheel cylinder for inspection; final game uses type 12.
   for start in [0,3]:
    c=np.array(pts[start]);a=np.array(pts[start+1])-c;b=np.array(pts[start+2])-c
    ring=[tuple(c+a*math.cos(t)+b*math.sin(t)) for t in np.linspace(0,2*math.pi,24)]
    d.polygon(ring,fill=tuple(PAL[colors[ma+1]]),outline=tuple(PAL[colors[ma]]))
    rim=[tuple(c+.62*(a*math.cos(t)+b*math.sin(t))) for t in np.linspace(0,2*math.pi,20)]
    d.polygon(rim,fill=tuple(PAL[colors[ma+2]]),outline=tuple(PAL[colors[ma+2]]))
    for t in np.linspace(0,2*math.pi,6)[:-1]:d.line([tuple(c),tuple(c+.56*(a*math.cos(t)+b*math.sin(t)))],fill=tuple(PAL[colors[ma]]),width=4)
  elif p['type']==2:d.line(pts,fill=rgb,width=2)
  elif p['type']>=3:
   d.polygon(pts,fill=rgb,outline=tuple(max(0,int(c*.7)) for c in rgb))
 return im

def sakura(variant):
 # Debris uses the on-track car1 units, not the 20x showroom car0 units.
 # One small, folded and notched petal per stock particle keeps render cost low.
 m=Model()
 points=[(0,-2,0),(-2,1,0),(-1,2,0),(0,1,1),(1,2,0),(2,1,0)]
 az=math.radians(variant*41);tilt=math.radians(18+variant*19)
 for x,y,z in points:
  xx=x*math.cos(az)-y*math.sin(az);yy=x*math.sin(az)+y*math.cos(az)
  m.vertices.append((round(xx),round(yy*math.cos(tilt)-z*math.sin(tilt)),
                     round(yy*math.sin(tilt)+z*math.cos(tilt))))
 for k in range(4):
  mat=15 if k==1 else (117 if k==3 and variant==2 else 36)
  m.prims.append({'type':3,'flags':1,'mats':[mat]*NPAINT,
                  'idx':[0,k+1,k+2],'tag':'sakura_petal'})
 return m

if __name__=='__main__':
 detailed=build(True);simple=build(False)
 print('detail vertices + bbox',len(detailed.vertices)+8,'primitives',len(detailed.prims))
 blocks={};stats={}
 for name,model,scale in [('car0',detailed,1),('car1',detailed,.05),('car2',simple,.05)]:
  blocks[name],stats[name]=model.export(scale)
 for i in range(4):
  em=sakura(i)
  blocks['exp'+str(i)],stats['exp'+str(i)]=em.export(1,bounds=False)
 output=res_pack(blocks);(OUT/'STNIMA.3SH').write_bytes(output)
 (OUT/'MODEL_AUDIT.json').write_text(json.dumps({'shapes':stats,'paints':PAINTS,'bytes':len(output)},indent=2))
 (ROOT/'model_geometry.json').write_text(json.dumps({'vertices':detailed.vertices,'primitives':detailed.prims}))
 render(blocks['car0']).save(OUT/'CARROSSERIE_AVANT.png')
 render(blocks['car0'],yaw=145).save(OUT/'CARROSSERIE_ARRIERE.png')
 sheet=Image.new('RGB',(1280,400*math.ceil(NPAINT/4)),'#191e24')
 for i in range(NPAINT):
  im=render(blocks['car0'],i,size=(320,360));sheet.paste(im,((i%4)*320,(i//4)*400))
  ImageDraw.Draw(sheet).text(((i%4)*320+14,(i//4)*400+365),PAINTS[i]['name'],fill='white')
 sheet.save(OUT/'PEINTURES.png')
