# Astuces de construction Stunts — conservation et dashboards

Mise à jour : 27 octobre 2026. Retours d’expérience BIRD (dashboards V07/V08, peintures V09) et Nissan Maxima Drift Wagon NIMA V01–V06, pour Stunts 1.1 VGA.

by Alain il Professore

## Spécifications EDES à conserver

Lorsqu’une réforme des caractéristiques physiques d’une voiture modifie `CARXXXX.RES`, conserver la fiche de spécifications déjà affichée en jeu.

Procédure obligatoire :

1. sauvegarder le bloc EDES existant et sa chaîne de spécifications ;
2. modifier uniquement les champs SIMD nécessaires à la physique ;
3. réinjecter la chaîne EDES antérieure, avec ses séparateurs `]`, son octet nul final et le code `GSNA` attendu ;
4. mettre à jour la taille totale du conteneur ;
5. vérifier que les lignes restent lisibles dans la fiche du véhicule.

Une réforme physique ne doit donc jamais supprimer, raccourcir ou réinitialiser les spécifications visibles en jeu.

Complément vérifié : terminer aussi la **dernière ligne** par `]`, avant l’octet nul. Dans le code de fiche examiné, `]` déclenche l’affichage d’une ligne ; le nul seul ne valide pas la dernière. C’était une cause de disparition de la signature. Pour BIRD, conserver notamment `590 hp]`, `Nascar torque curve]` et `by Alain il Professore]`. Un libellé affiché ne transforme pas la courbe de simulation en mesure au banc : conserver les hypothèses et la provenance dans les sources.

## 1. Trois coûts mémoire à mesurer séparément

1. **Taille du VSH brut** : tous les rectangles de pixels, leurs en-têtes, la table des ressources et les alignements.
2. **Occupation après conversion RLE** : dépend aussi du contenu des images, des changements de couleur et des répétitions.
3. **Pic pendant le chargement** : le chemin à deux tampons charge les données brutes, réserve un second bloc aussi grand, convertit, puis libère le premier. Prévoir environ deux fois le brut à ce stade, plus les autres ressources et les frais du gestionnaire. Ce n’est pas simplement brut + taille RLE finale.

Le port restunts utilisé pour l’audit possède aussi une solution de repli avec chevauchement de tampons. Ne pas supposer que le Stunts DOS de l’utilisateur dispose de cette modification. La fragmentation et les autres ressources chargées comptent également.

**Aucun plafond universel de 64 Kio par VSH n’a été démontré dans ces essais.** Des champs et opérations restent sur 16 bits ; cela impose de contrôler chaque structure, pas d’inventer une limite globale. La zone de 95–100 ko atteinte par BIRD est un repère de ce projet, pas une garantie pour toutes les installations.

### Budget d’un rectangle VGA

Pour les bitmaps natifs 8 bits exportés ici, un pixel coûte **un octet**, y compris un pixel transparent ou de fond. Chaque bitmap ajoute un en-tête de 16 octets. Notre conteneur ajoute `6 + 8 × N` octets pour N ressources et notre exporteur aligne chaque bloc sur 16 octets, soit 0 à 15 octets de remplissage par bloc.

Estimation avant export : `6 + 8N + somme(16 + largeur × hauteur + remplissage)`.

| Ressource ou choix | Pixels bruts, hors en-têtes |
| --- | ---: |
| Image + masque 320 × 112 | 71 680 octets |
| Image + masque 72 × 108 | 15 552 octets |
| Trois images de volant de W × H | 3 × W × H octets |
| Une image d’instruments 72 × 34 | 2 448 octets |
| Une image d’instruments 64 × 26 | 1 664 octets |
| Roof 320 × 10 | 3 200 octets |

Un masque binaire 0/255 occupe ici autant d’octets que l’image : il n’est pas stocké sur un seul bit. Réduire une surface d’instruments de 72 × 34 à 64 × 26 économise 784 octets **par image concernée**. Compter séparément ses éventuelles copies et les tampons créés à l’exécution ; ne pas appliquer un multiplicateur sans inventaire.

Réduire le nombre de couleurs ou le bruit peut améliorer le RLE, mais ne réduit pas le produit largeur × hauteur du VSH brut. Compresser en ZIP ne change pas la RAM en jeu. Un PVS réduit le fichier sur disque ; il faut toujours tenir compte de la décompression, de ses éventuels tampons temporaires et de la conversion suivante. Aucun gain RAM par simple passage en PVS n’a été validé pour ce pack.

### Mesures conservées du projet BIRD

| Version / fichier | Brut sur disque | Après conversion RLE | Test du chargeur avec budget de 200 000 octets |
| --- | ---: | ---: | --- |
| V04 STDA | 174 926 | Non mesuré | Échec mémoire |
| V05 STDA | 95 542 | 59 542 | Réussi |
| V06 STDA | 95 286 | 60 366 | Réussi |
| V07 STDA | 97 198 | 60 749 | Réussi, 15 bitmaps |
| V08 STDA | 97 198 | 60 613 | Réussi, 15 bitmaps |
| V06/V07 STDB | 2 102 | 1 388 | Réussi, 18 bitmaps |

Ce banc d’essai utilise le chargeur C restunts sur l’hôte, avec budget contraint et comparaison des pixels décodés. Ce n’est pas une partie de Stunts DOS ni une mesure de toute la mémoire du jeu. Le brut diminue entre V05 et V06 alors que le RLE augmente : les deux mesures sont bien distinctes.

## 2. Gagner de la place sans déformer le cockpit

- Faire l’inventaire de chaque ressource : identifiant, dimensions, position, ancre et coût brut. Repérer les grands rectangles presque vides et les images répétées.
- Recadrer au rectangle utile avant de réduire l’échelle du dessin. Recalculer les positions et ancres après chaque recadrage et vérifier les coordonnées SIMD associées.
- Préserver les proportions du montant, de son rembourrage, des barres et du filet. Leur miniaturisation pour atteindre un budget produit un cockpit incohérent.
- Le rétro est **facultatif** : ne pas en ajouter absolument. Pour BIRD V07, la décision est de le supprimer, avec son pied. Son dessin ne justifie ni une mauvaise place ni un grand masque coûteux.
- Conserver le `roof` demandé comme ressource native. BIRD V07 utilise un bandeau 320 × 10 en (0,0), raccordé au montant. `dast` et `dasm` sont recadrés à 72 × 108 en (0,10), sans répéter cette bande dans leur rectangle.
- Un changement de fond doit être reporté dans toutes les copies qui le contiennent. Retirer un miroir de `dash` seul laisse des fragments s’il est aussi incrusté dans les trois images `whl1`, `whl2`, `whl3`.

Un recadrage du volant doit encore couvrir les zones à restaurer lors des changements de pose. Une petite image mal découpée peut laisser des traces : contrôler l’animation, pas seulement le poids final.

## 3. Masques natifs et ordre des couches

Le PNG transparent est une source de travail ; son canal alpha ne remplace pas les ressources natives image/masque. Utiliser la palette VGA attendue, des dimensions, positions et ancres identiques pour chaque paire.

Pour les paires AND/OR employées ici : masque 0 sur le dessin opaque, 255 là où le fond doit être conservé ; image à 0 dans ces zones transparentes. Éliminer les îlots et pixels isolés. Vérifier ensemble `dast/dasm`, les instruments masqués et `gnob/gnab` ; ne pas créer de masque supplémentaire dont le moteur ne se sert pas.

Les aiguilles doivent passer derrière les gants, les branches et le cerclage prévus. Dans l’implémentation examinée, `ins2` n’a pas de compagnon `inm2` exploité comme les autres paires : contrôler sa restauration et ses fonds explicitement.

## 4. Lisibilité, volant et instruments

Concevoir les grands cadrans dans le jour laissé par le volant. Un léger déplacement des cadrans vers la gauche et du volant vers le bas peut dégager la lecture sans rapetisser le volant. Pour BIRD, garder les deux mains demandées ; sur les autres projets, leur présence reste un choix. Contrôler les trois poses : une position centrale lisible ne garantit pas les virages.

Pour le tachymètre, partager le même centre et la même échelle angulaire entre graduations, chiffres et aiguille. Placer les chiffres à l’intérieur du cerclage sur un rayon cohérent. Vérifier aussi les extrémités de l’échelle, les chevauchements et les positions des aiguilles. Un pourcentage de surface visible aide le diagnostic mais ne suffit pas à juger la lisibilité réelle.

## 5. Levier : respecter l’effet demandé

Pour ce cockpit, le soufflet et le pommeau doivent être **absents au repos** et apparaître seulement pendant le changement de rapport. Ne pas réintroduire un pommeau fixe sous prétexte de réalisme.

- `dash` contient le fond nu, sans soufflet ni pommeau.
- `gbox`, dans STDA, fournit le fond du levier pendant l’animation.
- `gnob` et `gnab`, dans STDB, fournissent le pommeau et son masque, en vue sommitale.
- À la fin du délai de changement, le moteur restaure le fond depuis `dash` : cette disparition est ici intentionnelle.
- Agrandir légèrement le pommeau impose de recalculer son ancre pour conserver les centres des rapports. BIRD conserve 12 × 10 pixels, ancre (6,5).

Dans le SIMD étudié, les sept couples de coordonnées occupent les octets `0x1C` à `0x37`. Un huitième couple écraserait les données suivantes à `0x38`, notamment la traînée. Contrôler les offsets avant toute écriture.

## 6. Contrôle obligatoire avant livraison

1. Réouvrir les fichiers réellement exportés : taille du conteneur, table, offsets, dimensions, ancres, paires de masques et chaînes EDES.
2. Assembler toutes les couches en cadre natif 320 × 200, puis afficher avec correction 4:3, par exemple à 320 × 240 ou 960 × 720. Examiner la vue entière avec recul.
3. Vérifier roof, raccord au montant, taille du filet, ouverture sur la route, volant, gants, cadrans et objets facultatifs. Ne pas valider un dashboard à partir d’un seul détail agrandi.
4. Examiner les trois poses du volant, plusieurs positions d’aiguille, le levier au repos, pendant le changement et après restauration. Rechercher les fragments de l’ancien fond.
5. Relever taille brute, taille après conversion et budget du test de chargement ; archiver l’audit. Tester en jeu DOS pour confirmer la jouabilité et la mémoire dans l’installation cible.

Les aperçus BIRD livrés sont des **assemblages des ressources**, pas des captures d’une partie. Ne pas présenter le test du chargeur comme un essai complet du jeu.

## 7. Complément V08 : chiffres et fermeture 3D de l’habitacle

Les chiffres du compte-tours suivent maintenant la suite complète 0, 1, 2, 3, 4, 5, 6, 7, 8 dans le sens horaire, avec l’unité RPM ×1000. Chaque valeur suit l’angle de son aiguille, de 140° à 400° dans les coordonnées de l’image. Sur le compteur de vitesse, conserver des chiffres 3 × 5 lisibles et des valeurs compatibles avec la table native (0 à 260 mph ; chiffres principaux 0, 100 et 200). Une police trop réduite peut rendre une graduation mathématiquement correcte visuellement erronée. Reporter les nouveaux fonds dans DASH, WHL et INS, en préservant les pixels des mains et du volant.

La fermeture de l’habitacle est un problème distinct du `roof` bitmap du dashboard : il s’agit de géométrie 3SH. Dans le fichier joint pour V08, le toit n°94 était déjà double face avec culling ouvert. Le grand panneau intérieur n°145 pouvait néanmoins le recouvrir dans la file de rendu native, triée selon une profondeur moyenne par primitive. Cocher « double face » ou recalculer seulement le culling ne corrige pas ce conflit de tri.

Solution BIRD vérifiée : garder le toit et ses numéros, puis remplacer la fermeture unique par neuf panneaux jointifs. Les limites intérieures suivent l’emprise du toit (X = −220/+220, Z = −380/+80 dans car0), les bords extérieurs suivent le panneau ajouté par l’utilisateur. Le panneau central et le toit partagent ainsi leur centre horizontal ; les parties périphériques ne prêtent plus leur profondeur moyenne à la zone située sous le toit. Appliquer la même géométrie à car1 à l’échelle 1/20, avec arrondi natif cohérent. Ne pas réutiliser un sommet arrière décalé d’un seul côté.

La correction conserve 241 sommets et 153 primitives par modèle détaillé, sous les limites du format utilisé ici. Les neuf panneaux sont double face, sans superposition avec le toit et sans Z-bias artificiel. Le contrôle de la file de rendu C, sur 288 combinaisons d’angles et de modèles, ne relève plus de pixel du toit recouvert par cette fermeture. Cela ne garantit pas à lui seul tout l’affichage en jeu : conserver l’audit, les vues avant/après et la distinction avec un essai DOS complet.

## 8. Complément V09 : peintures, contraste des numéros et coût du 3SH

### Matériaux 3D et palette VGA : deux numérotations différentes

Dans Stressed, le numéro de matériau renvoie à une couleur de palette et éventuellement à un motif. **Un matériau n°25 n’est pas la couleur VGA n°25.** Lire les tables `colors` et `patterns` de la configuration avant de choisir un dégradé ou une transparence.

Exemple du bronze BIRD, avec la configuration examinée :

| Matériau Stressed | Indice VGA | Couleur | Rôle dans V09 |
| --- | ---: | --- | --- |
| 25 | 200 | `#9C6438` | Ombres et panneaux sombres |
| 26 | 198 | `#B48054` | Teinte principale |
| 27 | 196 | `#CCA080` | Surfaces claires et reflets |

L’ancienne combinaison 33/25/26 avait une faiblesse : **33 et 25 renvoient tous deux à l’indice VGA 200** dans cette configuration. Deux numéros différents ne donnaient donc pas deux tons différents. La combinaison 25/26/27 rétablit trois valeurs distinctes. L’autre famille 31/32/33 propose respectivement les indices VGA 194/197/200, du clair au sombre ; ne pas supposer que des identifiants croissants sont toujours de plus en plus clairs.

Distribuer ces tons selon le rôle des faces : bas de caisse et ombres plus sombres, flancs intermédiaires, capot et toit plus clairs. Harmoniser aussi les éléments de carrosserie ou d’arceau restés sur un matériau fixe : dans BIRD, plusieurs segments étaient encore cyan dans toutes les peintures. Contrôler le résultat sur le modèle complet, avec les couleurs natives, plutôt que sur les seuls numéros de la table.

### Changer le contraste des 43 par peinture

Les 43 BIRD sont des **primitives de ligne natives**, pas des textures. Leurs positions, indices de sommets, ordre, drapeaux et données de culling ne changent pas lorsqu’on modifie leur matériau.

- Peinture n°7 jaune : matériau 0, noir plein, pour les numéros.
- Peinture n°9 blanche : même matériau noir pour les numéros.
- Autres peintures : numéros blancs conservés.
- Identifier les groupes des numéros avant toute substitution. Ne pas recolorer globalement tous les éléments blancs : phares, métal et autres détails doivent conserver leurs matériaux.

Sur BIRD, le contrôle couvre 28 segments de numéros dans chacun de `car0` et `car1`, et 14 dans `car2`. Vérifier les deux flancs, le toit et le capot aux niveaux de détail qui les comportent. Pour la nouvelle carrosserie blanche, les matériaux 77/79/15 donnent des ombres gris clair, une teinte principale très claire et des surfaces blanches ; le matériau de transparence 118 n’est pas un blanc de carrosserie.

### Ajouter une neuvième peinture sans décaler les primitives

Le nombre de peintures figure dans l’en-tête de **chaque forme 3D**. Chaque primitive contient ensuite un octet de matériau par peinture. Passer de huit à neuf exige de reconstruire les enregistrements, pas seulement de changer le nombre dans l’en-tête.

1. Ajouter un neuvième matériau à toutes les primitives de `car0`, `car1`, `car2` et `exp0` à `exp3`, y compris aux roues, vitres, intérieurs et détails qui ne changent pas de couleur.
2. Passer le nombre de peintures de chaque forme à neuf. Éliminer les valeurs « 8 » codées en dur dans l’exporteur : longueur de la liste, taille de l’enregistrement et position des indices de sommets doivent utiliser le nombre déclaré.
3. Réécrire les blocs, les offsets du conteneur, les alignements et la taille totale du fichier.
4. Relire le fichier exporté en utilisant le nouveau nombre de peintures ; vérifier que chaque primitive possède exactement neuf matériaux et que tous les indices de sommets restent valides.
5. Comparer sommets, types, drapeaux, ordre et culling avec la version précédente. Une retouche de peinture ne doit pas annuler la correction du toit ni modifier l’habitacle.

Ordre BIRD V09 : cyan, rouge, noir, rose, vert, bronze, jaune, violet, blanc. Distinguer cet ordre humain des indices de tableau commençant à zéro : jaune = indice 6, blanc = indice 8. Le code de menu examiné consulte le nombre de peintures de la forme ; le fichier à neuf peintures est structurellement vérifié, mais son parcours complet dans le jeu DOS n’a pas été testé ici.

### Coût mémoire : une peinture supplémentaire ne duplique pas la voiture

La géométrie est partagée : ajouter une peinture ajoute **un octet de matériau par primitive**, avant les effets de l’alignement du conteneur. Cela ne crée pas une deuxième liste de sommets ni une copie des bitmaps du dashboard.

Mesure BIRD V08 → V09 : 341 primitives au total dans les sept formes, soit 341 octets de matériaux supplémentaires ; le fichier 3SH passe de **10 766 à 11 118 octets**, donc **+352 octets avec les alignements**. Les modèles détaillés gardent chacun 241 sommets et 153 primitives. C’est une mesure du fichier brut, pas une mesure du pic RAM de tout le jeu. Les fichiers STDA, STDB et CAR ne sont pas modifiés par cette livraison limitée au 3SH.

### Conserver les preuves et annoncer le périmètre livré

L’audit V09 vérifie la géométrie et les drapeaux à l’identique de V08, les neuf matériaux par primitive, les numéros noirs des deux peintures concernées et la conservation des autres peintures d’origine. Les vues de contrôle montrent le bronze, le jaune et le blanc en trois quarts, sur le toit et sur le capot.

V09 a été livrée comme **STBIRD.3SH seul**. Le ZIP final V08 déjà livré ne contient pas automatiquement cette retouche ultérieure : lorsqu’un pack complet est redemandé, y intégrer explicitement le dernier 3SH et actualiser ses audits, aperçus, sommes de contrôle et notes sur le nombre de peintures. Ne pas annoncer un ancien ZIP comme mis à jour sans l’avoir reconstruit.

## 9. Retour d'expérience NIMA — Maxima Drift Wagon V01 à V06

### Feux arrière : réserver la famille 45/46/47, avec le bon déclencheur

La **couleur de matériau 46 est réservée ici aux feux rouges arrière dans leur état normal**. Ne pas l'employer comme rouge ordinaire de carrosserie. Attention toutefois : affecter seulement 46 ne suffit pas à demander l'allumage au freinage.

| Matériau natif / Stressed | Fonction vérifiée |
| --- | --- |
| 45 (`0x2D`) | Sélecteur spécial à affecter aux polygones des feux arrière |
| 46 (`0x2E`) | Rouge des feux au repos, choisi par le moteur |
| 47 (`0x2F`) | Rouge plus lumineux au freinage, choisi par le moteur |

Dans le code examiné, seul **45** est remplacé par la valeur de `backlights_paint_override`. Le calcul de trame choisit 46 ou 47 selon le freinage de la voiture du joueur ou de l'adversaire. Ce sont bien les valeurs de matériau, distinctes des indices de palette VGA ; dans cette configuration 45 et 46 pointent tous deux sur le rouge VGA 4, mais seul 45 est le déclencheur. La distinction n'est pas un décalage de numérotation de l'interface Stressed, qui affiche les indices natifs.

NIMA V06 emploie 45 sur les deux feux arrière dans les huit peintures et les trois modèles. Le banc C vérifie 48 cas : trois modèles × huit peintures × deux états, avec exactement deux polygones émis en 46 au repos ou en 47 au freinage. Le même déclencheur est visible dans le désassemblage original (`seg006.asm`, comparaison à `2Dh`) ; il ne provient pas d'une fonction ajoutée seulement au port.

### Contraste de la lame avant

Contrôler la voiture sur le gris du bitume, pas uniquement sur le fond sombre de l'éditeur. Le noir et les gris sombres de la lame NIMA disparaissaient visuellement contre la piste. V06 utilise un aluminium clair : matériau 79, VGA 17, `#DCDCDC`, avec une tranche matériau 40, VGA 19, `#C0C0C0`. Le bouclier et les prises d'air restent sombres. Une retouche de teinte doit cibler les faces de la lame ; ne pas remplacer globalement le noir des pneus, vitres, ouvertures ou numéros.

### Une source photographique n'est pas encore un dashboard natif

Une belle image générée doit être découpée, quantifiée dans la palette native et intégrée aux ressources effectivement installées. Examiner **le conteneur VSH rouvert**, pas seulement l'image source. Les chiffres et graduations doivent être lisibles à 320 × 200 ; les aperçus corrigés en 4:3 montrent l'aspect des pixels en jeu.

NIMA V04 décalait la photo de 38 pixels vers le bas : le haut du dashboard restait visible, mais la console et la base des leviers étaient coupées. V05 supprime ce décalage, conserve la partie basse photographique à partir de y=97 et réduit/repositionne le volant. Ne pas annoncer une photo « intégrée » si son cadrage en élimine les éléments précisément demandés.

| STDA NIMA | Brut | Fin utile RLE, banc C |
| --- | ---: | ---: |
| V02, fond trop dessiné | 91 390 | 34 394 |
| V03, source photographique, cockpit recadré | 86 222 | 42 001 |
| V04, retrait du rétro et gbox photographique | 86 222 | 42 204 |
| V05 / V06, partie basse photographique visible | 97 358 | 47 338 |

Les VSH de cette table ont été acceptés par le chargeur hôte sous un budget isolé de 200 000 octets. Pour V05/V06, les deux tampons bruts représentent 194 716 octets ; cela ne mesure pas le pic de toute une partie. L'amélioration photographique peut diminuer le brut tout en augmentant le RLE : ne jamais confondre ces mesures.

### Volant seul, instruments et manomètre de turbo

Les mains sont un choix de conception, pas une exigence du format. Sur NIMA, elles sont supprimées. Placer la vitesse et le compte-tours dans l'ouverture supérieure du volant ; le cadran déporté à droite est ici un **manomètre de turbo**, pas un second compte-tours.

Le format employé ne fournit pas une troisième aiguille de pression ni une commande indépendante de frein à main hydraulique. Le manomètre et la poignée de drift restent donc visuels et statiques. Le régime et la vitesse sont les deux instruments natifs animés. Les chiffres du régime vont dans le sens horaire ; les simplifier à des repères lisibles vaut mieux que les faire se chevaucher.

Quand le volant tourne, restaurer les aiguilles derrière ses branches à l'aide des paires INS/INM. Comme `ins2` n'a pas de masque central équivalent exploité, NIMA place tous les segments d'aiguille hors des pixels opaques du volant central : aucun croisement sur le balayage complet. Pour les poses latérales, le masque restaure l'union de l'ancien et du nouveau premier plan, afin d'effacer aussi les fragments de la pose précédente. Cela doit être contrôlé pour les deux instruments et toutes les positions utiles, pas seulement pour un régime et une vitesse.

### Ne pas confondre DOT, GBOX et GNOB

- `dot` et `dota` sont le repère mobile du volant et son masque. Le rond de la Renault est un sprite 8 × 8 ; conserver son masque, son ancre et les tampons de restauration cohérents. Dans NIMA, `dot1` et `dot2` sont adaptés à 24 × 8. Le RES contient la trajectoire du repère : le recalibrer quand le volant change de taille ou de position.
- `gbox`, dans STDA, est le fond de changement de rapport. NIMA utilise une photographie de soufflet en cuir, convertie à 40 × 36 pixels ; un trapèze vectoriel ne remplace pas une texture photographique demandée.
- `gnob` et `gnab`, dans STDB, sont le pommeau mobile et son masque, pas le repère du volant. Ils peuvent être conservés à l'identique lorsqu'on ne remplace que la base.

Le fond photographique NIMA montre un levier au repos ; `gbox` et le pommeau mobile le remplacent pendant la phase de changement. C'est un choix différent du cockpit BIRD où le levier doit disparaître au repos. Ne pas généraliser l'un à toutes les voitures.

### Raccords 3D et vérification des deux flancs

Une aile élargie convaincante a un épaulement, une face inclinée et un raccord fermé. Pour prolonger le renflement jusqu'au coffre, continuer son profil jusqu'à la face arrière et fermer l'extrémité ; éviter un simple panneau décalé qui flotte ou se superpose au flanc. Garder les proportions de caisse validées par l'utilisateur.

Pour un rétro « à l'aplomb de l'avant de la roue », calculer la référence : centre d'essieu + rayon de pneu, en tenant compte du sens de l'axe longitudinal. NIMA : 1 312 + 300 = 1 612 mm au centre du boîtier ; le pied s'appuie sur l'aile légèrement plus en avant, à 1 652 mm. Vérifier l'alignement en profil, puis dans les trois modèles natifs après arrondi.

Les numéros de flanc sont des lignes natives. Leur grille locale doit se lire depuis **l'extérieur de chaque côté** ; contrôler les deux profils pour éviter une écriture miroir. Un 6 à boucle inférieure fermée et attaque oblique est plus explicite que des segments ambigus. Attacher les lignes à leur panneau avec le mécanisme natif de profondeur utilisé dans le projet, sans décaler un faux autocollant coplanaire.

Après le passage car0 → car1, l'arrondi peut fusionner des sommets et écraser une bande mince. Souder les sommets de carrosserie identiques, vérifier l'aire des surfaces et retirer les bandes devenues nulles. **Ne pas souder ou déplacer les 24 sommets d'animation des roues** : ils doivent rester aux emplacements 8–31 et les quatre primitives de roue doivent garder leur ordre. Les huit sommets initiaux appartiennent à la boîte englobante.

### Livraison et installateurs réversibles

Recomposer le pack avec les quatre dernières ressources effectivement validées. Les anciens ZIP ne se mettent pas à jour seuls. Livrer les sources graphiques nécessaires, les calibrations RES et un relevé des fichiers modifiés ; tester qu'une reconstruction redonne les mêmes octets.

Pour un installateur utilisable sous DOS et Windows, employer des noms de scripts propres au mod et en 8.3, des fins de ligne CRLF, du texte de script ASCII et des commandes DOS simples. Éviter `SETLOCAL`, les variables `%~...` sur le chemin exécuté sous DOS, PowerShell et les utilitaires externes obligatoires. Les extensions Windows éventuelles doivent être dans une branche explicitement séparée.

Sauvegarder les fichiers NIMA existants avant toute suppression, y compris les PVS/XVS de dashboards et le P3S qui pourraient prendre la priorité. Une réinstallation doit conserver la **première sauvegarde**, pas remplacer les originaux par les fichiers déjà installés. Le désinstallateur restaure les fichiers présents avant l'installation et retire les nouveaux noms qui n'existaient pas. Ne supprimer la sauvegarde qu'après restauration complète ; la conserver en cas d'erreur.

Tester les fichiers réellement livrés : installation neuve, version déjà présente, priorité des ressources comprimées, réinstallation, désinstallation répétée et échecs de copie. Distinguer une exécution sous le vrai shell Windows/DOSBox d'une simulation des opérations de fichiers. De même, un chargeur C, une file 3D et des aperçus de ressources ne remplacent pas une partie DOS ni un essai de glisse.


## Sources techniques et reproductibilité

- [Stressed](https://github.com/dstien/stressed) : palette et conventions des ressources, notamment `resources/conf/defaults.conf`.
- [restunts-bb11](https://github.com/CommonLoon102/restunts-bb11) : code examiné dans `src/restunts/c/shape2d_resources.c`, `dashboard.c` et `menu_car.c`.
- Projet BIRD : exporteurs `build_final_v04.py` à `build_final_v08.py`, correction géométrique `roof_v08.py`, retouche des peintures `paintjobs_v09.py`, bancs `test_bird_native_loader.c` et `bird_shape_queue.c`.

Audits à conserver : `AUDIT_V07.json` pour le roof bitmap et le retrait du rétro ; `AUDIT_COCKPIT_V08.json` et `AUDIT_TOIT_V08.json` pour les compteurs et le tri de l’habitacle ; `AUDIT_PEINTURES_V09.json` pour les neuf peintures et la conservation de la géométrie. Les audits du pack incluent les SHA-256 des fichiers. Garder ces preuves avec les sources ; les faits propres à une version ne sont pas des règles universelles du moteur.

Sources complémentaires NIMA : `shape3d.h` (BACKLIGHT_PAINT), `shape3d.c` (substitution du matériau 45), `frame.c` (sélection selon le freinage), désassemblage `restunts/src/restunts/asm/seg006.asm` ; générateurs et audits NIMA V01–V06 conservés dans le pack.


## NIMA V08 — Débris Sakura et repère sur le cerceau (27 octobre 2026)

- Les formes `exp0` à `exp3` utilisent l'échelle de la voiture en piste `car1`,
  pas celle du modèle de présentation `car0` (ici 20 fois plus grand). Les créer
  dans leur repère local centré : ne pas leur appliquer le décalage vertical
  utilisé pour les axes de roues de la carrosserie. Stressed omet leur boîte
  englobante à huit sommets ; conserver ce format natif.
- Une forme de petit pétale par particule permet une pluie légère, avec quatre
  triangles par débris pour limiter le coût du rendu natif. Prévoir des faces double face, une légère
  pliure et une échancrure triangulée ; vérifier les triangles après arrondi.
  Les vitesses, la gravité, le nombre de particules et la durée de vie restent
  ceux du jeu. Les explosions bitmap 2D communes ne sont pas ces formes 3D.
- La trajectoire du rond de volant est dans `simd` de `CARNIMA.RES`, octets
  `0xEA..0x127` : 31 couples X/Y. Le jeu reflète les X autour de la première
  entrée pour les directions négatives, soit 61 positions à contrôler.
- Mesurer le milieu entre les bords intérieur et extérieur du cerceau dans
  l'alpha du volant photographique ; ne pas prendre le rayon extérieur du bitmap.
  Tenir compte de la compression verticale VGA, des trois poses et de l'ancre
  du sprite. Le rond Renault 8×8 a un centroïde (3,5 ; 3,5) pour une ancre (4 ; 4) :
  un demi-pixel doit être intégré au calcul avant l'arrondi des coordonnées.
- Pour NIMA V08 : 61 positions dont tous les pixels opaques sont sur le cerceau ;
  erreur maximale mesurée 1,04 pixel à la résolution VGA. STDA et STDB inchangés,
  seuls 57 octets de la table dans CARNIMA changent ; moteur et rapports préservés.
- Audit : 4 224 orientations/peintures de pétales dans la file de rendu native,
  3 168 cas de véhicule et 66 cas de freinage. Ces contrôles C et les aperçus de
  ressources ne remplacent pas un essai dans le jeu DOS.

- Contrôle supplémentaire de charge : 88 scènes combinant le véhicule car1 et
  18 pétales, toutes les peintures et huit orientations. Maximum observé :
  233 polygones, sous la capacité native de 400. Cela ne mesure pas toute une
  piste : conserver de la marge pour le décor et l'adversaire.
