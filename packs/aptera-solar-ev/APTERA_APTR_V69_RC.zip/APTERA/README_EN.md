# Aptera Solar EV — Stunts 1.1

**Edition:** 1.0 release candidate / V69 exterior / V68 cockpit  
**Package date:** November 8, 2026  
**Created by:** Alain il Professore — Hyperion Racing Team  
**Documentation:** English, French, Russian

## About this car

Aptera Solar EV is an unofficial add-on car for **Stunts 1.1 (4D Sports Driving)**. The project recreates the streamlined, three-wheel Aptera silhouette, its digital cockpit, and an efficiency-focused *pulse-and-glide* driving concept.

This build includes **eight paintjobs**, three 3D levels of detail (`car0/car1/car2`), crash/explosion parts, a VGA dashboard, and a green-on-black digital speed display. The V69 exterior adjusts native drawing order to prevent wheel surfaces from showing through their fairings.

This is a **release candidate**: the binary resources have been audited, but final on-road and replay rendering in the original DOS game has not yet been fully verified.

## Included files

| File | Purpose |
|---|---|
| `FILES/CARAPTR.RES` | Handling, transmission, aerodynamics, instrument coordinates and in-game specifications. |
| `FILES/STAPTR.3SH` | V69 exterior 3D model, three detail levels, eight paintjobs, explosion assets. |
| `FILES/STDAAPTR.VSH` | VGA cockpit with Aptera wheel, touchscreen miniature and solid V68 anthracite roof strip. |
| `FILES/STDBAPTR.VSH` | Digital speed digits and the small `+` steering marker (`dot/dota`). |

The `APTERA` directory also contains Windows/DOS installer and uninstaller scripts, three-language READMEs and changelogs, `SHA256SUMS.txt`, and `AUDIT_PACK_FINAL.json`.

## Windows installation (recommended)

1. **Close Stunts and DOSBox.** Back up your customized game folder if needed.
2. Extract the archive into your Stunts root so that `STUNTS\APTERA\FILES\CARAPTR.RES` and `STUNTS\APTERA\INSTALL.CMD` exist.
3. Run **`INSTALL.CMD`** from the `APTERA` directory (double-click or Windows Command Prompt).
4. The four APTR files are copied into the parent `STUNTS` directory. Existing APTR files, if any, are saved in `APTERA\BACKUP`.
5. Start Stunts 1.1 and select the Aptera.

To uninstall, run **`UNINST.CMD`** before deleting `APTERA`. Previous files are restored; newly introduced APTR files are removed.

## DOS / DOSBox installation

Extract the ZIP using your host OS **before** starting DOSBox. Mount your Stunts directory, for example:

```text
MOUNT C C:\GAMES\STUNTS
C:
CD \APTERA
INSTALL
```

To uninstall:

```text
C:
CD \APTERA
UNINST
```

The `.BAT` scripts use standard DOS commands and 8.3-compatible filenames; run them while inside `APTERA`. The `.CMD` scripts are for Windows only.

## Backups and precautions

- **Do not remove `APTERA/BACKUP` before uninstalling.** It contains files needed for restoration.
- If an installation fails partway through, preserve the backup directory and check the files before retrying.
- Uninstall a previously installed version before reinstalling so original backups are not overwritten.
- Installers do not touch tracks, replays, or other cars.
- Competing compressed files (`CARAPTR.PVS`, `STDAAPTR.PVS`, `STDBAPTR.PVS`) are **not deleted**. Back them up and move them aside manually if Stunts keeps loading an older revision.

## Technical notes

- **Exterior:** three levels of detail, eight paintjobs. V69 changes native fairing drawing priority with flag `0x02`, preserving geometry, colors and wheel controls. Check front, side, three-quarter and rear views in game.
- **Cockpit:** touchscreen with an Aptera pixel-art miniature, green-on-black digits and a fine `+` tracking the lower U-shaped steering-wheel rim.
- **Roof:** a solid 320 × 8 anthracite strip, without fake VGA-index-255 alpha. Native `roof` does not use a dedicated transparency mask in this rendering path.
- **Tachometer:** its unused needle is visually neutralized via CAR rendering data, not removed from the DOS engine.
- **In-game specifications:** Cd 0.13, SCx 0.286 and an indicated top speed of 101 mph. These are *Stunts project settings*, not manufacturer-certified figures.

## Verification and limitations

All four game binaries are included **byte-for-byte as supplied in the current reference ZIP**. Their SHA-256 hashes and native resource headers were checked. V69 face order and eight-paintjob preservation were audited statically. **This exact release ZIP has not undergone a complete original-DOS gameplay test here.** Verify the fairings and cockpit during driving and replay before calling the release fully validated.

See `CHANGELOG_EN.md` and `AUDIT_PACK_FINAL.json` for details.

## Credits / status

Independent fan project by **Alain il Professore — Hyperion Racing Team**. Requires a separately installed copy of *Stunts 1.1*; no game executable is bundled. No official affiliation with Aptera Motors or the Stunts rights holders is claimed.
