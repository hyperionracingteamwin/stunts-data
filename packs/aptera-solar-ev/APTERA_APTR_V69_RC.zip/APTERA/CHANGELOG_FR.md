# CHANGELOG — Aptera Solar EV pour Stunts 1.1

**Publication :** 1.0 RC (candidat à la version finale), 8 novembre 2026  
**Projet :** Alain il Professore — Hyperion Racing Team

## Assemblage publiable V69 — 8 novembre 2026

- Utilisation **sans modification** des quatre binaires du dernier ZIP fourni : `CARAPTR.RES`, `STAPTR.3SH`, `STDAAPTR.VSH`, `STDBAPTR.VSH`.
- Intégration de la **correction V69 des roues traversant les carénages** : réorganisation des facettes associées aux roues et drapeau natif `0x02` (Z-bias), sur `car0`, `car1` et `car2` ; géométrie, masques de visibilité et **8 paintjobs** préservés.
- Documentation finale **FR / EN / RU** et journaux de modifications correspondants.
- Réutilisation des installateurs/désinstallateurs DOS et Windows, avec sauvegarde/restauration des quatre fichiers APTR.
- Ajout de contrôles d’intégrité et de provenance (`SHA256SUMS.txt`, `AUDIT_PACK_FINAL.json`).

## Évolution du cockpit

- **V68 — toit DOS :** remplacement du toit à fausse transparence par une bande anthracite **entièrement opaque de 320 × 8 pixels**. Aucun index 255 de pseudo-alpha. Les éléments descendants non supportés sont retirés.
- **V67 — pare-soleil et point de compte-tours :** repositionnement du point neutralisé sur un témoin blanc déjà présent ; version intermédiaire du pare-soleil, remplacée ensuite par le toit sûr V68.
- **V66 — aiguille RPM :** centre et extrémités de l’aiguille inutilisée réunis au même point ; neutralisation visuelle sans modification du moteur DOS.
- **V65 — écran tactile :** miniature Aptera reprofilée en VGA avec cabine sombre, corps fuselé et carénages ; correction localisée du fond d’`ins2`.
- **V64 / V62 / V61 — volant et DOT :** croix `+` fine en bas du volant, trajectoire inversée, conversion en coordonnées écran puis décalage de **3 pixels à gauche**. Masque `dota` conservé.
- **V53 à V60 — compteurs :** chiffres de vitesse verts sur fond noir, positionnements successifs, réduction des recouvrements `ins2`/volant et harmonisation de pixels entre `ins2`, `dast` et `dash`.
- **Versions antérieures :** cockpit Aptera digitalisé à partir de photographies, refonte du volant et adaptation de la palette VGA de Stunts.

## Évolution du véhicule extérieur et conduite

- **V69 — carénages :** correction candidate de l’ordre de dessin natif pour éviter la transparence apparente des roues ; facettes attachées après leurs roues avec priorité `0x02` ; modèles d’explosion préservés.
- **Modèle 3D :** silhouette aérodynamique Aptera, deux carénages avant et dérive arrière, trois niveaux de détail, **huit paintjobs**.
- **Simulation :** réglages orientés rendement et *pulse and glide*. Le fichier CAR livré contient la description : `AERO Cd 0.13`, `SCx 0.286`, `MAX SPEED - 101 MPH`.

## Notes et limites

- Dans le CAR du ZIP fourni, le bloc `simd` de **776 octets** est identique à celui du pack V67 antérieur ; le texte des spécifications a été mis à jour sans modifier la simulation.
- Les mesures Cd/SCx et la vitesse sont les réglages **du mod**, non des résultats officiellement validés par Aptera.
- **Audit binaire réussi ; aucun test DOSBox complet exécuté pour cet assemblage.** Valider la disparition des traversées de roues, les huit peintures, la bande de toit et les instruments en conduite et replay avant de proclamer la compatibilité finale.
