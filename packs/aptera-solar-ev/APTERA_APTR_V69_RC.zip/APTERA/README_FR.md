# Aptera Solar EV — Stunts 1.1

**Édition :** 1.0 RC / modèle extérieur V69 / cockpit V68  
**Date du paquet :** 8 novembre 2026  
**Création :** Alain il Professore — Hyperion Racing Team  
**Langues de la documentation :** français, anglais, russe

## Présentation

L’Aptera Solar EV est une voiture additionnelle non officielle pour **Stunts 1.1 (4D Sports Driving)**. Le projet cherche à reproduire la silhouette aérodynamique à trois roues de l’Aptera, son habitacle numérique et une conduite orientée efficacité énergétique et *pulse and glide*.

Cette édition regroupe **huit paintjobs**, les modèles 3D `car0/car1/car2`, les éléments de collision/explosion, un tableau de bord VGA et un compteur de vitesse numérique vert sur noir. La V69 apporte un nouveau tri de dessin des carénages pour réduire les roues visibles à travers la carrosserie.

Il s’agit d’une **version candidate à la publication** : la structure des ressources a été contrôlée, mais les derniers réglages de recouvrement doivent encore être éprouvés dans le jeu original sous DOSBox.

## Contenu

| Fichier | Usage |
|---|---|
| `FILES/CARAPTR.RES` | Simulation routière, transmission, aérodynamique, indications de tableau de bord et fiche véhicule. |
| `FILES/STAPTR.3SH` | Modèle extérieur V69, trois niveaux de détail, huit peintures, éléments d’explosion. |
| `FILES/STDAAPTR.VSH` | Habitacle VGA : volant Aptera, écran tactile, miniature et bande de toit anthracite opaque V68. |
| `FILES/STDBAPTR.VSH` | Chiffres numériques et petit indicateur de braquage `+` (`dot/dota`). |

Le dossier `APTERA` contient aussi quatre scripts d’installation/désinstallation, les README et changelogs en trois langues, ainsi que `SHA256SUMS.txt` et `AUDIT_PACK_FINAL.json`.

## Installation Windows (méthode recommandée)

1. **Quitter Stunts et DOSBox.** Effectuer au besoin une copie de sécurité du répertoire du jeu.
2. Extraire l’archive dans le dossier racine de Stunts pour obtenir `STUNTS\APTERA\FILES\CARAPTR.RES` et `STUNTS\APTERA\INSTALL.CMD`.
3. Exécuter **`INSTALL.CMD`** depuis le sous-dossier `APTERA` (double-clic ou invite de commandes Windows).
4. Les quatre fichiers de la voiture sont copiés vers le dossier parent `STUNTS`. Si une version existait, elle est sauvegardée dans `APTERA\BACKUP`.
5. Démarrer Stunts 1.1 et sélectionner l’Aptera dans le choix des voitures.

Pour annuler l’installation, exécuter **`UNINST.CMD`** avant de supprimer `APTERA`. Les fichiers qui existaient avant l’installation seront restaurés ; les fichiers APTR qui n’existaient pas seront retirés.

## Installation DOS / DOSBox

Extraire l’archive depuis Windows, Linux ou macOS **avant** de lancer DOSBox. Monter ensuite la racine de Stunts, par exemple :

```text
MOUNT C C:\JEUX\STUNTS
C:
CD \APTERA
INSTALL
```

Pour désinstaller :

```text
C:
CD \APTERA
UNINST
```

Les scripts `.BAT` utilisent uniquement des noms 8.3 et les commandes DOS courantes. Les scripts `.CMD` sont réservés à Windows. Lancer les `.BAT` depuis le dossier `APTERA`.

## Sauvegardes et précautions

- **Ne pas supprimer `APTERA/BACKUP` avant la désinstallation.** Il conserve les anciens fichiers à restaurer.
- En cas d’installation partielle ou d’erreur de copie, préserver `BACKUP` et vérifier les fichiers avant de relancer la procédure.
- Pour changer de version, désinstaller d’abord la version gérée par ces scripts afin d’éviter d’écraser les sauvegardes.
- Les scripts ne touchent ni aux circuits, ni aux replays, ni aux autres voitures.
- Les éventuels fichiers compressés concurrents (`CARAPTR.PVS`, `STDAAPTR.PVS` ou `STDBAPTR.PVS`) ne sont **pas** supprimés : les sauvegarder et les isoler manuellement si Stunts charge l’ancienne version.

## Points techniques

- **Modèle :** trois niveaux de détail et huit paintjobs. La V69 associe les facettes de carénages aux primitives de roues par le drapeau natif `0x02`, sans changement de géométrie ou de palette. Comportement à vérifier en vue avant, profil, trois-quarts et arrière.
- **Habitacle :** écran tactile avec petite Aptera en pixel art, chiffres verts sur fond noir et repère de braquage `+` sur la branche basse du volant.
- **Toit :** bande anthracite opaque de 320 × 8 pixels, sans faux alpha VGA 255. Le `roof` n’a pas de masque alpha natif dans ce mode de rendu.
- **Compte-tours :** aiguille analogique inutilisée neutralisée visuellement par les paramètres du CAR ; elle n’est pas supprimée du moteur DOS.
- **Spécifications dans le jeu :** Cd 0,13, SCx 0,286, vitesse indiquée 101 mph. Ce sont les valeurs du projet Stunts, **pas une certification constructeur**.

## Validation et limites

Les quatre binaires ont été conservés **octet pour octet depuis le ZIP de référence fourni**. Les empreintes SHA-256 et les en-têtes natifs ont été contrôlés. Le nouvel ordre des faces V69 et la conservation des huit paintjobs ont été audités statiquement. **Aucun test complet de la présente archive dans le DOS original n’a été exécuté ici.** Un contrôle en conduite et replay est requis avant une sortie définitivement homologuée.

Voir `CHANGELOG_FR.md` pour l’historique et `AUDIT_PACK_FINAL.json` pour le détail technique.

## Crédits / statut

Projet de fan indépendant : **Alain il Professore — Hyperion Racing Team**. Nécessite une copie de *Stunts 1.1* installée séparément. Ce paquet ne contient aucun exécutable du jeu. Aucune affiliation officielle avec Aptera Motors ni avec les ayants droit de Stunts n’est revendiquée.
