# CHANGELOG — Aptera Solar EV for Stunts 1.1

**Release:** 1.0 RC (release candidate), November 8, 2026  
**Project:** Alain il Professore — Hyperion Racing Team

## Publishable V69 assembly — November 8, 2026

- Preserved the **four game binaries exactly as supplied** in the latest ZIP: `CARAPTR.RES`, `STAPTR.3SH`, `STDAAPTR.VSH`, `STDBAPTR.VSH`.
- Included **V69 wheel/fairing occlusion fix**: fairing faces are grouped with their native wheel primitives using the `0x02` Z-bias flag in `car0`, `car1` and `car2`; geometry, visibility masks and **all eight paintjobs** are preserved.
- Final **English / French / Russian** READMEs and changelogs.
- Kept DOS and Windows installers/uninstallers, which back up and restore existing APTR files.
- Added integrity/provenance reports (`SHA256SUMS.txt`, `AUDIT_PACK_FINAL.json`).

## Cockpit development

- **V68 — DOS-safe roof:** Replaced pseudo-transparent roof pixels with a fully opaque **320 × 8 anthracite strip**. No fake index-255 alpha; unsupported hanging roof details removed.
- **V67 — sun visors and RPM pixel:** Moved the neutralized draw point onto an existing white indicator; intermediate visor design subsequently replaced by the safer V68 roof.
- **V66 — RPM needle:** Collapsed the unused tachometer needle’s origin and endpoints to a single point, neutralizing its visible segment without modifying the DOS engine.
- **V65 — touchscreen:** Redrew the Aptera miniature in native VGA colors with a dark cabin, streamlined body and fairings; locally corrected `ins2` background pixels.
- **V64 / V62 / V61 — steering marker:** Fine `+` on the wheel’s lower rim, reversed path, corrected screen coordinates and final **3-pixel left shift**. `dota` mask kept consistent.
- **V53–V60 — speed display:** Green-on-black digits, positional calibration, reduced `ins2`/wheel overlap and pixel alignment between `ins2`, `dast` and `dash`.
- **Earlier versions:** Photo-guided Aptera digital dashboard, redesigned steering wheel and native Stunts VGA palette conversion.

## Exterior model and driving

- **V69 — wheel fairings:** Candidate native draw-order fix to prevent wheels from showing through fairings; attached primitives placed after wheel primitives with flag `0x02`; crash shapes preserved.
- **3D body:** Streamlined Aptera form, two front wheel fairings and rear fin, three levels of detail, **eight paintjobs**.
- **Driving:** Efficiency and *pulse-and-glide*-oriented settings. The included CAR description states `AERO Cd 0.13`, `SCx 0.286`, and `MAX SPEED - 101 MPH`.

## Verification and limitations

- The supplied CAR keeps the same **776-byte `simd` simulation block** as the earlier V67 bundle; its specification text has changed without altering physics.
- Cd/SCx and speed figures are **mod settings**, not Aptera-certified measurements.
- **Binary audit passed; no complete DOSBox gameplay test was run for this assembly.** Test wheel occlusion, all paintjobs, roof and gauges in normal driving and replay before considering the release fully validated.
