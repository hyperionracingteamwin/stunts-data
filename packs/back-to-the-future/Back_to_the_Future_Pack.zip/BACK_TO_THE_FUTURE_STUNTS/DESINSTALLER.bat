@echo off
TITLE HYPERION - BACK TO THE FUTURE UNINSTALLER
cd /d "%~dp0"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0MOD.ps1" -Mode Uninstall
if errorlevel 1 goto failed
echo.
echo Operation completed. Press any key to close.
pause >nul
exit /b 0
:failed
echo.
echo Uninstallation did not complete. See the message above.
pause
exit /b 1
