BACK TO THE FUTURE - COMPLETE STUNTS MOD PACK v1.0.2
Hyperion Racing Team | Alain il Professore

ONE PACK: DELOREAN + HILL VALLEY + INTRO + MUSIC

INSTALL (DOUBLE-CLICK ON WINDOWS)
  1. Close Stunts and DOSBox.
  2. Unzip the archive, preserving the BACK_TO_THE_FUTURE_STUNTS directory,
     inside your Stunts 1.1 game folder (example C:\STUNTS\BACK_TO_THE_FUTURE_STUNTS).
  3. Double-click INSTALLER.bat IN WINDOWS EXPLORER, never inside DOSBox.
  4. If the pack is outside the game folder, choose the Stunts folder in the
     graphical folder picker when prompted.
  5. In Stunts, choose the DeLorean BACK and load HILLVAL track.

UNINSTALL (DOUBLE-CLICK ON WINDOWS)
  1. Close Stunts and DOSBox.
  2. Double-click DESINSTALLER.bat from the same extracted pack directory.
  3. Every replaced game file is restored byte-for-byte to its previous
     content; newly added files are removed. Pre-uninstall edits are saved.

IMPORTANT
  - The installer uses Windows PowerShell 5.1+ (already on Windows 10/11).
  - It does not run from a DOSBox command prompt.
  - Original files and a state manifest are backed up under BTTF_BACKUP.
  - BTTF_ARCHIVES keeps dated restoration snapshots after uninstall.
  - Existing GAME1.P3S/GAME2.P3S are preserved in backup, then temporarily
    removed while this scenery mod is installed; uninstall restores them.
  - If the previous Hill Valley V1 installer is still active, uninstall it
    first; this new installer refuses to overwrite its active backup.
  - The alternate HILLV1.TRK is in extras and is not installed automatically.
  - This package does NOT contain a copy of Stunts itself.
  - Keep the extracted package to use DESINSTALLER.bat later.

FIX v1.0.1
  - Fixes the PowerShell missing "name" property error during backup.
  - Retrying after the v1.0 failure automatically archives the empty backup
    scaffold. Backups containing actual files without state.json are preserved
    and require inspection.

FIX v1.0.2 - INTRO TITLE PAGES
  - Back up and disable SDTITL.PVS so SDTITL.VSH can supply the title pages.
    Uninstall restores the original file or its original absence.
  - Already installed? Extract this version over the pack and run INSTALLER.bat
    again. The existing original backups are preserved; only the title-file
    conflict is corrected.
