BACK TO THE FUTURE - COMPLETE STUNTS PACK v1.0.3
Hyperion Racing Team | Alain il Professore

CORRECTED V7 ASSETS
- Starting truck: animated vertices now belong to the doors, not the wheels.
- Lowered finish gantry and cable at Y=57, with courthouse connection preserved.
- Native, centered, two-line starting quote:
  WHERE WE'RE GOING,
  WE DON'T NEED ROADS.

INSTALL / UPGRADE
Close Stunts and DOSBox. Extract BACK_TO_THE_FUTURE_STUNTS inside your own
Stunts 1.1 game directory. Double-click INSTALLER.bat in Windows Explorer.
Select the game folder if prompted. In Stunts select DeLorean BACK and HILLVAL.
For Hyperion 1.0.1/1.0.2, extract over the existing pack and run INSTALLER.bat
again, without uninstalling. Earliest original backups are preserved. Active
pre-upgrade files are journaled before replacement. Repeating an intact
installation only verifies it; changed files can be reinstalled safely.

UNINSTALL
Close Stunts and DOSBox, then double-click DESINSTALLER.bat from this pack.
Every tracked original file or missing-file state is restored. Pre-uninstall
edits are saved. Keep BTTF_BACKUP while installed; BTTF_ARCHIVES retains history.

18 PAYLOAD FILES / 9 DISABLED ALTERNATIVES
The 18 payload files exactly match the supplied V7 archive. Compared to 1.0.2,
GAME1.3SH and GAME2.3SH are corrected; GAME.RES is added; the other 15 files
are unchanged. These alternatives are backed up before being disabled:
CARBACK.PRE, GAME.PRE, GAME1.P3S, GAME2.P3S, SDTITL.PVS, STBACK.P3S,
STDABACK.PVS, STDBBACK.PVS, TITLE.3SH.
In particular, GAME.PRE must be disabled to load the new GAME.RES quote and
SDTITL.PVS must be disabled to load SDTITL.VSH. Uninstall restores all originals.
The optional HILLV1.TRK remains under extras and is not installed automatically.

REQUIREMENTS / VERIFICATION
Your own Stunts 1.1 and Windows PowerShell 5.1+ (included with Windows 10/11).
This pack contains neither Stunts nor DOSBox; it does not run inside DOSBox.
Other installers using HV_BACKUP must be uninstalled with their own script first.
Asset structure checks and installation/upgrade/restore/rollback scenarios
were run with PowerShell 7.4.6 on Linux. Windows BAT launch and a new live
DOSBox run were not performed. The V7 screenshot/reports are supplied source
evidence, not a new run. The HTML preview uses the corrected finish geometry.
See controle/ for integration and installer verification reports.
