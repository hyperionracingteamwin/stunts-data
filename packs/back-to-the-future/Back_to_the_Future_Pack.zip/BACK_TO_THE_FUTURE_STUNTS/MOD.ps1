param(
  [ValidateSet('Install','Uninstall')][string]$Mode='Install',
  [string]$GameDirectory=''
)
$ErrorActionPreference='Stop'
Set-StrictMode -Version 2
$PackDirectory=Split-Path -Parent $MyInvocation.MyCommand.Path
$PayloadDirectory=Join-Path $PackDirectory 'payload'
$PathMemory=Join-Path $PackDirectory 'GAME_FOLDER.txt'

function Hash-File([string]$Path) {
    return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
}
function Game-Exists([string]$Dir) {
    if ([string]::IsNullOrWhiteSpace($Dir)) { return $false }
    if (!(Test-Path -LiteralPath $Dir -PathType Container)) { return $false }
    $First = (Test-Path -LiteralPath (Join-Path $Dir 'GAME1.P3S') -PathType Leaf) -or
             (Test-Path -LiteralPath (Join-Path $Dir 'GAME1.3SH') -PathType Leaf)
    $Second = (Test-Path -LiteralPath (Join-Path $Dir 'GAME2.P3S') -PathType Leaf) -or
              (Test-Path -LiteralPath (Join-Path $Dir 'GAME2.3SH') -PathType Leaf)
    return ($First -and $Second)
}
function Game-Or-Recovery-Exists([string]$Dir) {
    if (Game-Exists $Dir) { return $true }
    if ([string]::IsNullOrWhiteSpace($Dir)) { return $false }
    return (Test-Path -LiteralPath (Join-Path $Dir 'BTTF_BACKUP\state.json') -PathType Leaf)
}
function Find-Game([string]$Requested) {
    if ($Requested) {
        if (!(Game-Or-Recovery-Exists $Requested)) { throw ('Not a Stunts game folder or a BTTF recovery folder: '+$Requested) }
        return (Resolve-Path -LiteralPath $Requested).Path
    }
    $Candidates=@($PackDirectory,(Split-Path -Parent $PackDirectory))
    if (Test-Path -LiteralPath $PathMemory -PathType Leaf) {
        $Candidates+=((Get-Content -LiteralPath $PathMemory -Raw).Trim())
    }
    foreach($Candidate in $Candidates) {
        if (Game-Or-Recovery-Exists $Candidate) { return (Resolve-Path -LiteralPath $Candidate).Path }
    }
    Write-Host 'Please select the Stunts 1.1 game folder in the window.' -ForegroundColor Yellow
    try {
        Add-Type -AssemblyName System.Windows.Forms
        $Window=New-Object System.Windows.Forms.FolderBrowserDialog
        $Window.Description='Select your STUNTS game folder (GAME1 / GAME2 files)'
        $Window.ShowNewFolderButton=$false
        if ($Window.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) {
            throw 'Folder selection cancelled. No game files modified.'
        }
        $Candidate=$Window.SelectedPath
    } catch {
        throw ('Cannot select a folder: '+$_.Exception.Message+' Place this pack inside the Stunts game folder or use -GameDirectory.')
    }
    if (!(Game-Or-Recovery-Exists $Candidate)) { throw ('Not a Stunts game folder or a BTTF recovery folder: '+$Candidate) }
    try { Set-Content -LiteralPath $PathMemory -Value $Candidate -Encoding UTF8 -ErrorAction Stop }
    catch { Write-Host 'Notice: game folder preference could not be saved (not fatal).' }
    return (Resolve-Path -LiteralPath $Candidate).Path
}
function Assert-Checksum([string]$Path,[string]$Expected,[string]$Label) {
    if (!(Test-Path -LiteralPath $Path -PathType Leaf)) { throw ('Missing file: '+$Label) }
    if ((Hash-File $Path) -ne $Expected.ToLowerInvariant()) { throw ('Checksum mismatch: '+$Label) }
}
function Copy-Verified([string]$Source,[string]$Destination) {
    $OriginalHash=Hash-File $Source
    $Temp= $Destination + '.BTTF.' + [guid]::NewGuid().ToString('N') + '.tmp'
    try {
        Copy-Item -LiteralPath $Source -Destination $Temp -ErrorAction Stop
        Assert-Checksum $Temp $OriginalHash $Temp
        Copy-Item -LiteralPath $Temp -Destination $Destination -Force -ErrorAction Stop
        Assert-Checksum $Destination $OriginalHash $Destination
    } finally {
        if (Test-Path -LiteralPath $Temp) { Remove-Item -LiteralPath $Temp -Force -ErrorAction SilentlyContinue }
    }
}
function Save-State([object]$State,[string]$Path) {
    $State | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $Path -Encoding UTF8
}
function Verify-Originals([object]$State,[string]$OriginalDirectory) {
    foreach($Entry in @($State.originals)) {
        if ($Entry.existed) {
            $Saved=Join-Path $OriginalDirectory $Entry.name
            Assert-Checksum $Saved $Entry.sha256 ('backup '+$Entry.name)
        }
    }
}
function Restore-Set([object[]]$Entries,[string]$SavedDirectory,[string]$TargetDirectory) {
    foreach($Entry in $Entries) {
        $Target=Join-Path $TargetDirectory $Entry.name
        if ($Entry.existed) {
            $Saved=Join-Path $SavedDirectory $Entry.name
            Copy-Verified $Saved $Target
            Assert-Checksum $Target $Entry.sha256 ('restoration '+$Entry.name)
        } elseif (Test-Path -LiteralPath $Target) {
            Remove-Item -LiteralPath $Target -Force -ErrorAction Stop
        }
    }
}
function Make-CurrentSnapshot([object[]]$Entries,[string]$Game,[string]$Dir) {
    New-Item -ItemType Directory -Path $Dir -Force | Out-Null
    $List=@()
    foreach ($Item in $Entries) {
        # Install supplies filenames; uninstall supplies saved state records.
        if ($Item -is [string]) { $Name=$Item } else { $Name=$Item.name }
        $Target=Join-Path $Game $Name
        $Exists=Test-Path -LiteralPath $Target -PathType Leaf
        $Snapshot=[ordered]@{name=$Name;existed=$Exists;sha256=$null}
        if($Exists) {
            $Copy=Join-Path $Dir $Name
            Copy-Item -LiteralPath $Target -Destination $Copy -ErrorAction Stop
            $Snapshot.sha256=Hash-File $Target
            Assert-Checksum $Copy $Snapshot.sha256 ('snapshot '+$Name)
        }
        $List+=([pscustomobject]$Snapshot)
    }
    return ,$List
}
function Archive-Backup([string]$Backup,[string]$Game) {
    $History=Join-Path $Game 'BTTF_ARCHIVES'
    New-Item -ItemType Directory -Path $History -Force | Out-Null
    $Target=Join-Path $History ('uninstalled-'+(Get-Date -Format 'yyyyMMdd-HHmmss-fff'))
    Move-Item -LiteralPath $Backup -Destination $Target -ErrorAction Stop
}
try {
    Write-Host 'HYPERION RACING TEAM  |  BACK TO THE FUTURE COMPLETE PACK' -ForegroundColor Cyan
    Write-Host ('Operation: '+$Mode)
    $Game=Find-Game $GameDirectory
    Write-Host ('Game folder: '+$Game)
    $Backup=Join-Path $Game 'BTTF_BACKUP'
    $OriginalDirectory=Join-Path $Backup 'originals'
    $StateFile=Join-Path $Backup 'state.json'
    $Manifest=Get-Content -LiteralPath (Join-Path $PackDirectory 'manifest.json') -Raw | ConvertFrom-Json
    $Files=@($Manifest.files)
    if ($Files.Count -ne 17) { throw 'Unexpected manifest size. Aborted.' }
    $ConcurrentFiles=@('GAME1.P3S','GAME2.P3S','SDTITL.PVS')
    $Names=@($ConcurrentFiles)
    foreach($File in $Files) {
        if ($File.name -cnotmatch '^[A-Z0-9_]{1,8}\.[A-Z0-9]{1,3}$') { throw ('Unexpected payload filename: '+$File.name) }
        if($Names -contains $File.name) { throw ('Duplicate file in manifest: '+$File.name) }
        $Names+= $File.name
    }
    if ($Mode -eq 'Install') {
        if(Test-Path -LiteralPath $Backup) {
            if(!(Test-Path -LiteralPath $StateFile)) {
                # v1.0 could fail before saving state, leaving only an empty originals folder.
                # Archive that empty scaffold; refuse any backup containing actual files.
                $BackupItems=@(Get-ChildItem -LiteralPath $Backup -Force)
                $EmptyScaffold=($BackupItems.Count -eq 0)
                if ($BackupItems.Count -eq 1 -and $BackupItems[0].Name -eq 'originals' -and $BackupItems[0].PSIsContainer) {
                    $EmptyScaffold=(@(Get-ChildItem -LiteralPath $OriginalDirectory -Force).Count -eq 0)
                }
                if (!$EmptyScaffold) { throw 'BTTF_BACKUP contains files without a state file. Preserve it and inspect it before retrying.' }
                Archive-Backup $Backup $Game
                Write-Host 'Empty backup from an interrupted setup archived. Continuing installation.' -ForegroundColor Yellow
            } else {
                $Old=Get-Content -LiteralPath $StateFile -Raw | ConvertFrom-Json
                if($Old.status -eq 'installed') {
                    # Upgrade older installed packs without replacing their original backups.
                    if($Old.pack -ne 'Hyperion BTTF v1.0' -or $Old.game -ne $Game) {
                        throw 'Backup belongs to a different pack or game folder. Aborted.'
                    }
                    Verify-Originals $Old $OriginalDirectory
                    $TitleEntries=@($Old.originals | Where-Object { $_.name -eq 'SDTITL.PVS' })
                    if($TitleEntries.Count -eq 0) {
                        $TitleBackup=Join-Path $OriginalDirectory 'SDTITL.PVS'
                        if(Test-Path -LiteralPath $TitleBackup) { throw 'An unregistered SDTITL.PVS backup already exists. Preserve it before retrying.' }
                        $TitleSnapshot=Make-CurrentSnapshot @('SDTITL.PVS') $Game $OriginalDirectory
                        $Old.originals=@($Old.originals)+@($TitleSnapshot)
                        Copy-Verified $StateFile (Join-Path $Backup 'state-before-title-pvs.json')
                        Save-State $Old $StateFile
                    }
                    $Title=Join-Path $Game 'SDTITL.PVS'
                    if(Test-Path -LiteralPath $Title -PathType Leaf) {
                        # Preserve any file reintroduced since a previous install or upgrade.
                        $TitleEntry=@($Old.originals | Where-Object { $_.name -eq 'SDTITL.PVS' })[0]
                        if(!$TitleEntry.existed -or (Hash-File $Title) -ne $TitleEntry.sha256) {
                            $TitleHistory=Join-Path $Backup ('title-pvs-'+[guid]::NewGuid().ToString('N'))
                            $TitleCurrent=Make-CurrentSnapshot @('SDTITL.PVS') $Game $TitleHistory
                            Save-State ([ordered]@{format=1;current=$TitleCurrent}) (Join-Path $TitleHistory 'state.json')
                        }
                        Remove-Item -LiteralPath $Title -Force -ErrorAction Stop
                    }
                    Write-Host 'INSTALLED: SDTITL.PVS is backed up and disabled; SDTITL.VSH can provide the intro title pages.' -ForegroundColor Green
                    Write-Host 'Existing original backups preserved. Use DESINSTALLER.bat to undo the pack.'
                    exit 0
                }
                if($Old.status -eq 'uninstalled' -or $Old.status -eq 'rolled-back') {
                    Archive-Backup $Backup $Game
                } else { throw 'An incomplete installation exists. Run DESINSTALLER.bat to restore it before retrying.' }
            }
        }
        $OldHV=Join-Path $Game 'HV_BACKUP'
        if (Test-Path -LiteralPath $OldHV) {
            $OldHVState=Join-Path $OldHV 'state.json'
            if (!(Test-Path -LiteralPath $OldHVState)) { throw 'An existing Hill Valley installation/backup was found. Uninstall that old pack before installing this combined pack.' }
            $State=Get-Content -LiteralPath $OldHVState -Raw | ConvertFrom-Json
            if($State.status -ne 'uninstalled' -and $State.status -ne 'rolled-back') {
                throw 'Old Hill Valley is installed. Uninstall the old Hill Valley mod before installing the combined pack.'
            }
        }
        # Validate every distributed file before touching any Stunts game file.
        foreach($File in $Files) {
            $Source=Join-Path $PayloadDirectory $File.name
            Assert-Checksum $Source $File.sha256 ('pack '+$File.name)
            if ((Get-Item -LiteralPath $Source).Length -ne [long]$File.size) {throw ('Incorrect file size: '+$File.name)}
        }
        New-Item -ItemType Directory -Path $OriginalDirectory -Force | Out-Null
        $Saved=Make-CurrentSnapshot $Names $Game $OriginalDirectory
        $Snapshot=[ordered]@{format=1; pack='Hyperion BTTF v1.0'; status='prepared'; created=(Get-Date).ToString('o'); game=$Game; originals=$Saved; payload=$Files}
        Save-State $Snapshot $StateFile
        try {
            # Disable packed geometry and title resources only after verified backups.
            foreach($Name in $ConcurrentFiles) {
                $Target=Join-Path $Game $Name
                if(Test-Path -LiteralPath $Target) { Remove-Item -LiteralPath $Target -Force }
            }
            foreach($File in $Files) {
                $Source=Join-Path $PayloadDirectory $File.name
                $Target=Join-Path $Game $File.name
                Copy-Verified $Source $Target
            }
            $Snapshot.status='installed'
            Save-State $Snapshot $StateFile
        } catch {
            $Why=$_.Exception.Message
            try {
                Verify-Originals $Snapshot $OriginalDirectory
                Restore-Set $Saved $OriginalDirectory $Game
                $Snapshot.status='rolled-back'
                Save-State $Snapshot $StateFile
            } catch {
                throw ('INSTALL FAILED: '+$Why+'. AUTOMATIC ROLLBACK ALSO FAILED: '+$_.Exception.Message+'. Preserve BTTF_BACKUP.')
            }
            throw ('Install failed; original game files restored. Reason: '+$Why)
        }
        Write-Host 'INSTALLED: DeLorean BACK, Hill Valley, intro, music and scenery.' -ForegroundColor Green
        Write-Host 'In the game: choose the DeLorean and load HILLVAL track.'
        Write-Host 'To undo: close the game and double-click DESINSTALLER.bat.'
        Write-Host ('Verified originals saved in '+$Backup)
    } else {
        if (!(Test-Path -LiteralPath $StateFile)) {
            Write-Host 'No combined BTTF pack installation found in this game directory. Nothing changed.' -ForegroundColor Yellow
            exit 0
        }
        $Snapshot=Get-Content -LiteralPath $StateFile -Raw | ConvertFrom-Json
        if($Snapshot.pack -ne 'Hyperion BTTF v1.0') { throw 'Backup belongs to a different pack. Aborted.' }
        if($Snapshot.status -ne 'installed' -and $Snapshot.status -ne 'prepared') { throw ('Backup status is '+$Snapshot.status+'. Aborted to protect original files.') }
        if($Snapshot.game -ne $Game) {throw ('Backup was created for a different folder: '+$Snapshot.game) }
        Verify-Originals $Snapshot $OriginalDirectory
        $BeforeUninstall=Join-Path $Backup 'before-uninstall'
        if(Test-Path -LiteralPath $BeforeUninstall) { throw 'An earlier uninstall snapshot exists. Inspect the backup before retrying.' }
        $Current=Make-CurrentSnapshot @($Snapshot.originals) $Game $BeforeUninstall
        Save-State ([ordered]@{format=1;current=$Current}) (Join-Path $BeforeUninstall 'state.json')
        try {
            Restore-Set @($Snapshot.originals) $OriginalDirectory $Game
        } catch {
            $Why=$_.Exception.Message
            try {
                Restore-Set $Current $BeforeUninstall $Game
            } catch {
                throw ('Uninstall interrupted: '+$Why+'. Could not restore the pre-uninstall snapshot: '+$_.Exception.Message+'. Preserve BTTF_BACKUP.')
            }
            throw ('Uninstall interrupted; active files restored from snapshot: '+$Why)
        }
        $Snapshot.status='uninstalled'
        Save-State $Snapshot $StateFile
        try { Archive-Backup $Backup $Game }
        catch { Write-Host 'Originals restored, but backup could not be moved into BTTF_ARCHIVES. Keep BTTF_BACKUP.' -ForegroundColor Yellow }
        Write-Host ('UNINSTALLED: All '+@($Snapshot.originals).Count+' game file states restored exactly.') -ForegroundColor Green
        Write-Host 'Before-uninstall snapshots were retained to protect any edits.'
    }
    exit 0
} catch {
    Write-Host ('ERROR: '+$_.Exception.Message) -ForegroundColor Red
    Write-Host 'Check that Stunts and DOSBox are closed. No administrator access is normally needed.'
    exit 1
}
