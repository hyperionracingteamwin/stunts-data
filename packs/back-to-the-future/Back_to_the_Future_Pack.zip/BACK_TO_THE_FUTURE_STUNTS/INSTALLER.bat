@echo off
TITLE HYPERION - BACK TO THE FUTURE INSTALLER
cd /d "%~dp0"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0MOD.ps1" -Mode Install
if errorlevel 1 goto failed
echo.
echo Operation completed. Press any key to close.
pause >nul
exit /b 0
:failed
echo.
echo Installation did not complete. See the message above.
pause
exit /b 1
