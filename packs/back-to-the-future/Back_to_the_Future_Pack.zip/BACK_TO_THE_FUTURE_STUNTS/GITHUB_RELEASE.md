# Back to the Future — Complete Pack for Stunts 1.1

**DeLorean BACK · Hill Valley · Custom intro · Music · Scenery**

Travel to Hill Valley in the custom DeLorean BACK. This complete, reversible
mod pack contains a specially themed circuit, revised scenery meshes,
a Back to the Future intro, four music cues, sound/instrument resources,
and the car's 3D model and custom dashboard.

**Author:** Alain il Professore · Hyperion Racing Team

**Install:** Extract inside your Stunts game directory, then double-click
`INSTALLER.bat` in Windows Explorer. To undo the whole mod, double-click
`DESINSTALLER.bat`. Existing files are backed up and restored on uninstall.

**Requirements:** Your own Stunts 1.1 installation; Windows 10/11 with PowerShell.
The game itself is not distributed here. Scripts do not run within DOSBox.

**Track:** `HILLVAL.TRK` from BTTF.zip. An earlier variant is retained under
`extras/HILLV1.TRK` for optional comparison.
