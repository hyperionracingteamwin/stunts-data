# Back to the Future — Complete Pack v1.0.2 for Stunts 1.1

**DeLorean BACK · Hill Valley · Custom intro · Music · Scenery**

Travel to Hill Valley in the custom DeLorean BACK. This complete, reversible
mod pack contains a specially themed circuit, revised scenery meshes,
a Back to the Future intro, four music cues, sound/instrument resources,
and the car's 3D model and custom dashboard.

**Author:** Alain il Professore · Hyperion Racing Team

**Install:** Extract inside your Stunts game directory, then double-click
`INSTALLER.bat` in Windows Explorer. To undo the whole mod, double-click
`DESINSTALLER.bat`. Existing files are backed up and restored on uninstall.

**Requirements:** Your own Stunts 1.1 installation; Windows 10/11 with PowerShell.
The game itself is not distributed here. Scripts do not run within DOSBox.

**Track:** `HILLVAL.TRK` from BTTF.zip. An earlier variant is retained under
`extras/HILLV1.TRK` for optional comparison.

## v1.0.1 installer fix

Fixes a missing `name` property error during the initial backup. Retrying after
the failed v1.0 install safely archives an empty backup scaffold. Non-empty
backups without a state file remain protected. Game assets are unchanged.

## v1.0.2 title resource fix

Backs up and disables `SDTITL.PVS` so `SDTITL.VSH` can load the intro title pages.
Uninstall restores the original PVS file, or its absence. Rerunning the new
installer upgrades existing installations without replacing their original
backups. All 17 distributed game assets are unchanged.
