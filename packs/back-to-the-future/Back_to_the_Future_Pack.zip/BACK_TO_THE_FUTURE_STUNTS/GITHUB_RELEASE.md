# Back to the Future Complete Pack v1.0.3 for Stunts 1.1

Integrates the supplied V7 resources: working truck-door animation geometry,
lowered finish gantry and cable, and the centered two-line departure quote:

> WHERE WE'RE GOING,
> WE DON'T NEED ROADS.

All 18 payload files match V7. GAME.RES is now included and GAME.PRE is backed
up and disabled, alongside the other eight competing resource variants.

Existing Hyperion 1.0.1/1.0.2 installations can be upgraded by extracting over
the pack and running INSTALLER.bat again. Earliest originals are retained,
pre-upgrade files are journaled, and uninstall restores all 27 tracked states.

The car, dashboard, track, intro artwork and music are unchanged. The HTML
preview now includes the lowered finish geometry.

Validation: binary resource/geometry checks and PowerShell 7.4.6 Linux tests
for fresh installs, upgrades, reinstall, full restoration, corrupt input and
simulated failures. The supplied V7 screenshot/reports are reference evidence;
this integration was not rerun in DOSBox or through Windows BAT double-click.
