# PURE021 — by Alain il Professore

[Français](README_FR.md) · [English](README_EN.md) · [Русский](README_RUS.md)

Windows: INSTALL_WIN.CMD / UNINSTALL_WIN.CMD. DOS: INSTALL.BAT / REMOVE.BAT.

Lire le README de votre langue avant installation / Read your README first / Сначала прочитайте README.
