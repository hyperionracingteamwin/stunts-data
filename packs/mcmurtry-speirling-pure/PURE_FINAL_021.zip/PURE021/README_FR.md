# McMurtry Spéirling PURE — pack final 021
by Alain il Professore — 13 novembre 2026

## Contenu et dernières avancées
Pack complet021 : CARPURE.RES, STDAPURE.VSH, STDBPURE.VSH et STPURE.3SH.
Le3SH est la copie exacte de020 ; le RES et le cockpit sont ceux de016, inchangés.
Inclus : quatre feux arrière sur chaque LOD, feux CAR0 agrandis pour le showroom,
nuances de gouttières sur les12livrées de CAR0/CAR1, et correction des masques
du plancher du showroom. CAR2 conserve son ombrage017. Retouches utilisateur
et débris conservés. Crédit «by Alain il Professore», vitesse seule, dot mobile.
L'EDES est recadré ; «Speirling» reste ASCII car FONTN ne contient pas le «é».
Documentation FR/EN/RUS, installateurs et désinstallateurs avec sauvegardes.
Cette livraison assemble les fichiers ; aucune retouche native supplémentaire.
Les audits017–020 sont dans HISTORIQUE. Rendu DOS et vues rasantes restent à
valider ; aucune garantie de disparition de tous les artefacts n'est ajoutée.
Pour une mise à jour, garder les anciens packs et leurs sauvegardes. Installer021
sauvegarde l'état actuel du jeu ; le désinstaller rétablit cet état précédent.

## Installation Windows
Fermer Stunts/DOSBox. Extraire intégralement PURE021 dans un sous-dossier du jeu,
par exemple C:\GAMES\STUNTS\PURE021, puis lancer INSTALL_WIN.CMD.
Autre emplacement : INSTALL_WIN.CMD "C:\GAMES\STUNTS".
Le dossier cible doit contenir LOAD.EXE et MISC.PRE ou MISC.RES. Sans droits admin
spécifiques, le dossier doit être accessible en écriture. Le script vérifie les
empreintes, sauvegarde les anciens fichiers et isole leurs variantes compressées.
Ne pas déplacer le dossier PURE021 après installation : il contient la sauvegarde.

## Désinstallation Windows
Lancer UNINSTALL_WIN.CMD depuis le même pack. Le chemin du jeu enregistré est
utilisé. Les anciens fichiers sont restaurés, les fichiers auparavant absents
redeviennent absents. Les sauvegardes sont conservées dans PURE_BACKUPS.
Une modification ultérieure des fichiers installés bloque la restauration :
la sauvegarder ailleurs puis remettre le fichier livré avant de réessayer.

## DOS/DOSBox
Extraire PURE021 directement dans le dossier STUNTS. Dans DOS : CD PURE021,
puis INSTALL.BAT. Pour restaurer : CD PURE021 puis REMOVE.BAT.
Utiliser un seul mode d'installation. PUREBAK conserve les originaux DOS ; ne pas
l'effacer. Sauvegarder toute retouche manuelle avant REMOVE.BAT, qui rétablit les
originaux. Après restauration, archiver/renommer PUREBAK avant de réinstaller.
Les scripts DOS ont été contrôlés statiquement ; leur exécution DOS n'est pas testée.

## Profil et contrôles
Profil Wikipédia choisi par l'auteur :900kg affichés,745kW de référence,190mph,
0–60mph en1,55s mesurés dans le moteur porté à20Hz, sans rollout. L'inertie native
13 n'est pas une valeur en kg. Ce profil est distinct des1350kg annoncés pour la
PURE2026 de série. La courbe de couple et l'appui fan sont des approximations.
L'adhérence524 et tous les autres paramètres014 sont conservés.
Les tests portés ne constituent pas une validation DOS ou une certification réelle.
Des limites de tri de polygones aux vues rasantes restent connues dans le3SH.
Les scripts Windows sont essayés dans des copies isolées ; aucun jeu installé
n'a été modifié pour fabriquer ce pack. PAYLOAD_SHA256.json identifie les quatre
natifs ; SHA256SUMS.json couvre le pack. Voir VALIDATION_INSTALLATION.json.

Sources : https://en.wikipedia.org/wiki/McMurtry_Sp%C3%A9irling ;
https://mcmurtry.com/speirling-pure/ ; https://www.ehelix.com/communication/helix-delivers-ev-technology-for-mcmurtry-automotive/
