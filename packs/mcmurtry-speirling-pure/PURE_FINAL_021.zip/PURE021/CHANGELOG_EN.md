# Changelog — EN
##021 — updated complete pack
Unmodified assembly:3SH020, RES/cockpit016. Documentation, scripts and checksums refreshed; Windows installer tests for this package.
##020
Larger CAR0 rear markers: radius12→20, rear plane−622→−626; only8exclusive light vertices change.
##019
Gutter shades applied to the other11CAR0/CAR1 liveries;352material bytes only. CAR2 unchanged.
##018
Four CAR0 floor C2 masks corrected for showroom rendering;16bytes only.
##017
Preserved the user's edited/reindexed3SH; four rear lights added toCAR1/CAR2 and green gutter shading mirrored across all3LODs.
##016 — showroom and lower-body correction
EDES reflowed using native font measurements; e-acute is unavailable in stock FONTN. Four CAR0 facing flags corrected, no added geometry. Other native resources preserved.
##015 — final release,2026-11-13
Approved EDES text: “by Alain il Professore”, fans drawing air beneath the car;
technical notes removed from the in-game description. No other native block
changed. Added FR/EN/RUS READMEs/changelogs, Windows/DOS setup and removal,
backup/restore, SHA256 manifests and installer checks.
##014
Selected Wikipedia profile: displayed900kg; native inertia15→13, measured0–60mph
in1.55s and limiter near190mph.745kW reference envelope and grip preserved.
##013
Grip211→524 to approximate continuous fan downforce; comparative replay checks.
##012
Steering-linked moving dot; sprites and other parameters preserved.
##011
Swapped left/right wheel sprites, center unchanged.
##009–010
STDA memory reduced from167119 to115471bytes with compact, feathered animation,
following the user's DOS out-of-memory report.
##008
Photo-based cockpit, white gloves, fixed central speed-only LCD; estimated EV
torque envelope from McMurtry/Helix data, one native forward ratio.
##Earlier baseline
Geometry, wheels, centered frame and native resources corrected; three LODs,
twelve liveries and debris retained. Known grazing-view painter issues remain.
