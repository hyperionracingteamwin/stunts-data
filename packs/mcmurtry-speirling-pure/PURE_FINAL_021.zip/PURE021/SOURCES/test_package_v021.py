"""Exercise Windows installer and removal only in explicit isolated fixtures."""
from pathlib import Path
import subprocess,shutil,json,sys
W=Path(__file__).resolve().parent;O=W/'dashboard_v021';T=O/'CHECKS/installer_tests'
sys.path[:0]=[str(W/'tool_snapshot/scripts'),str(W.parent/'work_blueprint_factory/devdeps')]
import blueprint_factory as bf
NATIVE=['CARPURE.RES','STDAPURE.VSH','STDBPURE.VSH','STPURE.3SH']
PACKED=['CARPURE.PRE','STDAPURE.PVS','STDBPURE.PVS','STPURE.P3S']
def fixture(name,originals):
    game=T/name/'STUNTS with spaces';package=game/'PURE021 pack';assert not game.exists()
    package.mkdir(parents=True)
    for file in NATIVE+['SETUP_WIN.ps1','PAYLOAD_SHA256.json']:shutil.copyfile(O/file,package/file)
    (game/'LOAD.EXE').write_bytes(b'GAME DETECTION FIXTURE');(game/'MISC.PRE').write_bytes(b'DATA FIXTURE');(game/'UNRELATED.TXT').write_bytes(b'KEEP EXACTLY')
    for file,data in originals.items():(game/file).write_bytes(data)
    return game,package
def run(package,mode,game):
    r=subprocess.run(['powershell.exe','-NoProfile','-ExecutionPolicy','Bypass','-File',str((package/'SETUP_WIN.ps1').resolve()),'-Mode',mode,'-GamePath',str(game.resolve())],capture_output=True,text=True,timeout=30)
    return r
def snap(game):return {p.name:p.read_bytes() for p in game.iterdir() if p.is_file()}
def expect(r,success):assert (r.returncode==0)==success,(r.returncode,r.stdout,r.stderr)
def main():
    assert not T.exists(),'Preserve previous checks'
    checks={};original={'CARPURE.RES':b'OLD CAR','STDAPURE.VSH':b'OLD DASH','CARPURE.PRE':b'OLD PACKED CAR','STDAPURE.PVS':b'OLD PACKED A','STPURE.P3S':b'OLD PACKED SHAPE'}
    game,package=fixture('existing',original);initial=snap(game)
    expect(run(package,'Install',game),True)
    for name in NATIVE:assert (game/name).read_bytes()==(O/name).read_bytes()
    assert not any((game/name).exists() for name in PACKED)
    installed=snap(game);expect(run(package,'Install',game),False);assert snap(game)==installed
    checks['install_hashes_competing_files_and_repeat_guard']='PASS'
    (game/'CARPURE.RES').write_bytes(b'LATER USER EDIT');edited=snap(game)
    expect(run(package,'Remove',game),False);assert snap(game)==edited
    (game/'CARPURE.RES').write_bytes((O/'CARPURE.RES').read_bytes());checks['later_edit_preflight_protection']='PASS'
    active=json.loads((package/'PUREACT.JSN').read_text(encoding='utf-8-sig'));backup=package/active['backup']
    oldbackup=(backup/'CARPURE.RES').read_bytes();(backup/'CARPURE.RES').write_bytes(b'CORRUPTED BACKUP');unchanged=snap(game)
    expect(run(package,'Remove',game),False);assert snap(game)==unchanged
    (backup/'CARPURE.RES').write_bytes(oldbackup);checks['backup_integrity_preflight_protection']='PASS'
    expect(run(package,'Remove',game),True);assert snap(game)==initial and not (package/'PUREACT.JSN').exists();assert (backup/'RESTORED.json').exists()
    checks['restore_original_bytes_and_absent_files_keep_backups']='PASS'
    game,package=fixture('fresh',{});initial=snap(game);expect(run(package,'Install',game),True);expect(run(package,'Remove',game),True);assert snap(game)==initial
    checks['fresh_install_uninstall_no_old_car']='PASS'
    game,package=fixture('tampered payload',original);initial=snap(game);(package/'STDBPURE.VSH').write_bytes(b'INVALID PAYLOAD')
    expect(run(package,'Install',game),False);assert snap(game)==initial and not (package/'PUREACT.JSN').exists()
    checks['corrupt_payload_rejected_before_game_changes']='PASS'
    game,package=fixture('invalid target',original);(game/'LOAD.EXE').unlink();initial=snap(game);expect(run(package,'Install',game),False);assert snap(game)==initial
    checks['invalid_game_folder_rejected']='PASS'
    game,package=fixture('rollback',original);initial=snap(game)
    # Test-only injected exception after the real copying loop; exercise rollback
    # after competing packed files have been removed and new native files copied.
    source=(package/'SETUP_WIN.ps1').read_text(encoding='utf-8-sig')
    needle="  foreach ($entry in $entries | Where-Object {$null -ne $_.installed_hash}) {"
    assert needle in source;source=source.replace(needle,"  throw 'TEST_ONLY_INJECTED_FAILURE_AFTER_COPY'\n"+needle,1)
    (package/'SETUP_WIN.ps1').write_bytes(b'\xef\xbb\xbf'+source.encode('utf-8'))
    expect(run(package,'Install',game),False);assert snap(game)==initial and not (package/'PUREACT.JSN').exists()
    assert list((package/'PURE_BACKUPS').glob('*/ROLLED_BACK.json'));checks['failure_after_copy_rolls_back_all_originals']='PASS'
    game,package=fixture('dos active',original);(package/'PUREBAK').mkdir();(package/'PUREBAK/READY.OK').write_bytes(b'ACTIVE DOS');initial=snap(game)
    expect(run(package,'Install',game),False);assert snap(game)==initial;checks['active_DOS_install_blocks_Windows_install']='PASS'
    for file in ['INSTALL.BAT','REMOVE.BAT']:
        text=(O/file).read_text(encoding='ascii');lines=[line.strip() for line in text.splitlines() if not line.lower().startswith('rem ')]
        active='\n'.join(lines).lower();assert all(bad not in active for bad in ['setlocal','exit /b','%~dp0','if /i','&&','||','powershell'])
        labels={line[1:].lower() for line in lines if line.startswith(':')}
        for line in lines:
            low=line.lower()
            if 'goto ' in low:assert low.split('goto ')[-1].strip() in labels,(file,line)
        for name in NATIVE:assert name in text
    assert 'PUREACT.JSN' in (O/'INSTALL.BAT').read_text(encoding='ascii')
    checks['DOS_syntax_labels_8dot3_payload_and_cross_mode_guard']='PASS_STATIC_ONLY'
    checks['DOS_runtime']='NOT_TESTED'
    checks['scope']='Actual PowerShell installation/removal in isolated fixture folders with spaces; failure injection modifies fixture script only. No installed game touched.'
    bf.save(O/'VALIDATION_INSTALLATION.json',checks);shutil.copyfile(__file__,O/'SOURCES/test_package_v021.py')
    print(json.dumps(checks),flush=True)
if __name__=='__main__':main()
