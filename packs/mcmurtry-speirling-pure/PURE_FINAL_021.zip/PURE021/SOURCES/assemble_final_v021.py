"""Assemble current native files unchanged; refresh packaging and provenance."""
from pathlib import Path
import sys,shutil,zipfile,json
W=Path(__file__).resolve().parent;BASE=W/'dashboard_v016';MESH=W/'retouche_3sh_v020';O=W/'dashboard_v021'
sys.path[:0]=[str(W/'tool_snapshot/scripts'),str(W.parent/'work_blueprint_factory/devdeps')]
import blueprint_factory as bf
from vendor.shape_io import unpack,shape
NATIVE=['CARPURE.RES','STDAPURE.VSH','STDBPURE.VSH','STPURE.3SH']
def build():
    assert not O.exists();O.mkdir();(O/'HISTORIQUE').mkdir();(O/'PREVIEWS').mkdir();(O/'SOURCES').mkdir()
    provenance={}
    for name in NATIVE:
        source=(MESH if name=='STPURE.3SH' else BASE)/name;shutil.copyfile(source,O/name)
        assert source.read_bytes()==(O/name).read_bytes();provenance[name]={'source_version':'020' if name=='STPURE.3SH' else '016','sha256':bf.sha((O/name).read_bytes()),'byte_identical_to_source':True}
    for name in ['SETUP_WIN.ps1','INSTALL_WIN.CMD','UNINSTALL_WIN.CMD','INSTALL.BAT','REMOVE.BAT']:(O/name).write_bytes((BASE/name).read_bytes().replace(b'016',b'021'))
    for name in ['EDES.txt','EDES_AVANT_APRES.md','AUDIT_EDES.json','SPECIFICATIONS_CIBLES.json','COMPARAISON_SPECIFICATIONS.json']:shutil.copyfile(BASE/name,O/name)
    for version in range(17,21):shutil.copyfile(W/f'retouche_3sh_v{version:03d}/AUDIT_MODIFICATION.json',O/'HISTORIQUE'/f'AUDIT_{version:03d}.json')
    images=[(BASE/'PREVIEWS/EDES_AVANT_APRES.png','EDES.png'),(W/'retouche_3sh_v017/PREVIEWS/FEUX_REPOS_FREIN.png','FEUX_CAR1_CAR2.png'),(W/'retouche_3sh_v019/PREVIEWS/NUANCES_AVANT_APRES.png','NUANCES.png'),(MESH/'PREVIEWS/FEUX_CAR0_AVANT_APRES.png','FEUX_CAR0.png')]
    for src,name in images:shutil.copyfile(src,O/'PREVIEWS'/name)
    sections={
      'FR':('## Contenu','## Installation Windows','''## Contenu et dernières avancées
Pack complet021 : CARPURE.RES, STDAPURE.VSH, STDBPURE.VSH et STPURE.3SH.
Le3SH est la copie exacte de020 ; le RES et le cockpit sont ceux de016, inchangés.
Inclus : quatre feux arrière sur chaque LOD, feux CAR0 agrandis pour le showroom,
nuances de gouttières sur les12livrées de CAR0/CAR1, et correction des masques
du plancher du showroom. CAR2 conserve son ombrage017. Retouches utilisateur
et débris conservés. Crédit «by Alain il Professore», vitesse seule, dot mobile.
L'EDES est recadré ; «Speirling» reste ASCII car FONTN ne contient pas le «é».
Documentation FR/EN/RUS, installateurs et désinstallateurs avec sauvegardes.
Cette livraison assemble les fichiers ; aucune retouche native supplémentaire.
Les audits017–020 sont dans HISTORIQUE. Rendu DOS et vues rasantes restent à
valider ; aucune garantie de disparition de tous les artefacts n'est ajoutée.
Pour une mise à jour, garder les anciens packs et leurs sauvegardes. Installer021
sauvegarde l'état actuel du jeu ; le désinstaller rétablit cet état précédent.

'''),
      'EN':('## Contents','## Windows installation','''## Contents and latest changes
Complete021 pack: CARPURE.RES, STDAPURE.VSH, STDBPURE.VSH and STPURE.3SH.
The3SH is byte-identical to020; RES and cockpit are unchanged016 files.
Four rear lights on each LOD, enlarged CAR0 showroom lights, gutter shades across
all12CAR0/CAR1 liveries, showroom floor-mask correction. CAR2 retains017 shading.
User edits and debris preserved. Author credit, speed-only LCD and moving dot.
Reflowed EDES uses ASCII “Speirling”: stock FONTN has no e-acute glyph.
FR/EN/RUS documentation and backup-aware Windows/DOS setup/removal included.
This release only assembles current files; no additional native edits.
See HISTORIQUE for017–020 audits. DOS and grazing views are not newly certified.
Keep old packages and backups. Installing021 backs up the current game state;
removing021 restores that previous state.

'''),
      'RUS':('## Состав','## Установка','''## Состав и последние изменения
Полный комплект021: CARPURE.RES, STDAPURE.VSH, STDBPURE.VSH, STPURE.3SH.
3SH точно совпадает с020; RES и кабина сохранены из016 без изменений.
По четыре задних фонаря на каждом LOD, увеличенные фонари CAR0, оттенки канавок
во всех12раскрасках CAR0/CAR1, исправленные маски днища для showroom.
CAR2 сохраняет окраску017. Ручные правки и обломки сохранены. Автор указан;
экран показывает только скорость, маркер перемещается с рулём.
EDES вписан в рамку; в игре «Speirling», так как в FONTN отсутствует символ «é».
Документация FR/EN/RUS, установка и удаление Windows/DOS с резервными копиями.
Выполнена только сборка последних файлов, без дополнительных правок игры.
Аудиты017–020 находятся в HISTORIQUE. Новая проверка DOS не заявляется.
Сохраните старые комплекты и резервные копии. Установка021 сохраняет текущее
состояние игры; удаление021 восстанавливает это предыдущее состояние.

''')}
    entries={
      'FR':'''##021 — pack complet actualisé
Assemblage sans modification :3SH020, RES/cockpit016 ; documentation, scripts et empreintes actualisés. Tests Windows du nouveau pack.
##020
Quatre feux CAR0 plus lisibles : rayon12→20, plan arrière−622→−626 ; seuls leurs8points exclusifs changent.
##019
Nuances des gouttières étendues aux11autres livrées de CAR0/CAR1 ;352octets uniquement, CAR2 inchangé.
##018
Masques C2 des4faces de plancher CAR0 corrigés pour le showroom ;16octets uniquement.
##017
Base3SH utilisateur conservée avec ses réindexations ;4feux ajoutés àCAR1/CAR2, nuance vert d'eau reproduite des deux côtés surles3LOD.
''',
      'EN':'''##021 — updated complete pack
Unmodified assembly:3SH020, RES/cockpit016. Documentation, scripts and checksums refreshed; Windows installer tests for this package.
##020
Larger CAR0 rear markers: radius12→20, rear plane−622→−626; only8exclusive light vertices change.
##019
Gutter shades applied to the other11CAR0/CAR1 liveries;352material bytes only. CAR2 unchanged.
##018
Four CAR0 floor C2 masks corrected for showroom rendering;16bytes only.
##017
Preserved the user's edited/reindexed3SH; four rear lights added toCAR1/CAR2 and green gutter shading mirrored across all3LODs.
''',
      'RUS':'''##021 — обновлённый полный комплект
Сборка без изменения файлов игры:3SH020, RES/кабина016. Обновлены документы, скрипты и хеши; проверена установка Windows.
##020
Фонари CAR0 увеличены: радиус12→20, задняя плоскость−622→−626; изменены только8точек фонарей.
##019
Оттенки канавок добавлены в остальные11раскрасок CAR0/CAR1; только352байта материалов. CAR2 не изменён.
##018
Исправлены маски C2 четырёх граней днища CAR0 для showroom; только16байт.
##017
Сохранён пользовательский3SH с ручными правками и переиндексацией; добавлены4задних фонаря CAR1/CAR2 и симметричное зелёное затенение на3LOD.
'''}
    for lang,(begin,end,section) in sections.items():
        text=(BASE/f'README_{lang}.md').read_text(encoding='utf-8').replace('016','021');i=text.index(begin);j=text.index(end,i);text=text[:i]+section+text[j:];(O/f'README_{lang}.md').write_text(text,encoding='utf-8')
        title,history=(BASE/f'CHANGELOG_{lang}.md').read_text(encoding='utf-8').split('\n',1);(O/f'CHANGELOG_{lang}.md').write_text(title+'\n'+entries[lang]+history,encoding='utf-8')
    (O/'README.md').write_text((BASE/'README.md').read_text(encoding='utf-8').replace('016','021'),encoding='utf-8')
    models={k:shape(unpack((O/'STPURE.3SH').read_bytes())[k]) for k in ['car0','car1','car2']}
    counts={k:{'vertices':len(s['v']),'primitives':len(s['p']),'paintjobs':s['nj'],'rear_lights':sum(p['t']==11 and p['m']==[45]*12 for p in s['p'])} for k,s in models.items()}
    assert all(c['rear_lights']==4 and c['vertices']<=255 and c['primitives']<=255 for c in counts.values())
    bf.save(O/'PAYLOAD_SHA256.json',{n:bf.sha((O/n).read_bytes()) for n in NATIVE})
    bf.save(O/'AUDIT_ASSEMBLAGE.json',{'status':'PASS','no_native_changes':True,'native_provenance':provenance,'counts':counts,'DOS_tested':False,'scope':'Binary assembly and package checks only; previous finite rendering/physics audits retained, not rerun or upgraded to DOS validation.'})
    shutil.copyfile(__file__,O/'SOURCES/assemble_final_v021.py')
    test=(W/'test_package_v016.py').read_text(encoding='utf-8').replace('016','021');(W/'test_package_v021.py').write_text(test,encoding='utf-8')
    print(json.dumps({'status':'ASSEMBLED','counts':counts}),flush=True)
def finalize():
    assert (O/'VALIDATION_INSTALLATION.json').exists()
    for n in NATIVE:assert (O/n).read_bytes()==((MESH if n=='STPURE.3SH' else BASE)/n).read_bytes()
    summary='''# Reprise PURE — pack complet021

Courant :dashboard_v021, archive PURE_FINAL_021.zip / dossier PURE021.
Assemblage strict :STPURE.3SH identique à020 ; CARPURE.RES / STDAPURE.VSH / STDBPURE.VSH identiques à016. Aucune nouvelle retouche native.
Toutes avancées017–020 intégrées :feux sur3LOD, masques plancher showroom, nuances12livrées CAR0/CAR1, feuxCAR0 agrandis. Profil Wikipédia900kg/745kW/190mph/1,55s, EDES recadré et dot conservés.
README/changelog FR/EN/RUS, installateurs Windows/DOS, sauvegarde/restauration. Windows testé dans copies isolées ; DOS non testé. Audits HISTORIQUE + AUDIT_ASSEMBLAGE.json.
Scripts assemble_final_v021.py et test_package_v021.py. Versions et originaux précédents conservés.
'''
    (O/'REPRISE_COURTE.md').write_text(summary,encoding='utf-8')
    files=[p for p in O.rglob('*') if p.is_file() and 'CHECKS' not in p.parts]
    bf.save(O/'SHA256SUMS.json',{p.relative_to(O).as_posix():bf.sha(p.read_bytes()) for p in files})
    archive=W/'PURE_FINAL_021.zip';assert not archive.exists()
    with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
        for p in sorted(files+[O/'SHA256SUMS.json']):z.write(p,Path('PURE021')/p.relative_to(O))
    with zipfile.ZipFile(archive) as z:assert z.testzip() is None and all(bf.sha(z.read('PURE021/'+k))==h for k,h in bf.read(O/'SHA256SUMS.json').items())
    current=W/'REPRISE_COURANTE.md';backup=W/'REPRISE_COURANTE_avant_set_021.md';assert not backup.exists();shutil.copyfile(current,backup);current.write_text(summary,encoding='utf-8')
    print(json.dumps({'status':'DELIVERED','archive':str(archive),'files':len(files)+1,'bytes':archive.stat().st_size}),flush=True)
if __name__=='__main__':
    if '--finalize' in sys.argv:finalize()
    else:build()
