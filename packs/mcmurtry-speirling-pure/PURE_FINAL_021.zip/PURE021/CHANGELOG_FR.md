# Changelog — FR
##021 — pack complet actualisé
Assemblage sans modification :3SH020, RES/cockpit016 ; documentation, scripts et empreintes actualisés. Tests Windows du nouveau pack.
##020
Quatre feux CAR0 plus lisibles : rayon12→20, plan arrière−622→−626 ; seuls leurs8points exclusifs changent.
##019
Nuances des gouttières étendues aux11autres livrées de CAR0/CAR1 ;352octets uniquement, CAR2 inchangé.
##018
Masques C2 des4faces de plancher CAR0 corrigés pour le showroom ;16octets uniquement.
##017
Base3SH utilisateur conservée avec ses réindexations ;4feux ajoutés àCAR1/CAR2, nuance vert d'eau reproduite des deux côtés surles3LOD.
##016 — correction du showroom et du soubassement
EDES mesuré avec la police du jeu et raccourci ; accent é indisponible dans FONTN. Quatre drapeaux de faces CAR0 corrigés, sans nouvelle géométrie. Autres ressources natives conservées.
##015 — livraison finale,2026-11-13
EDES validé intégré : «by Alain il Professore», description des fans aspirant
l'air sous la voiture ; mentions techniques retirées du texte en jeu. Aucun autre
bloc natif modifié. Ajout des README/changelogs FR/EN/RUS, scripts Windows et DOS,
sauvegarde/restauration, manifestes SHA256 et contrôles d'installation.
##014
Profil Wikipédia choisi :900kg dans la fiche ; inertie native15→13,0–60mph1,55s
mesurés, limiteur proche190mph. Courbe de référence745kW et adhérence conservées.
##013
Adhérence211→524 pour approximer l'appui fan permanent ; essais comparatifs.
##012
Dot mobile suivant le braquage ; images et autres réglages conservés.
##011
Permutation des images de braquage gauche/droite, centre inchangé.
##009–010
Réduction mémoire STDA de167119 à115471octets ; animation compacte à raccords
progressifs. Réponse à une erreur de mémoire DOS signalée par l'utilisateur.
##008
Cockpit reconstruit depuis la photo, gants blancs, écran central fixe, vitesse
seule ; courbe EV estimée sur les données McMurtry/Helix, transmission native unique.
##Base antérieure
Géométrie, roues, recentrage et ressources natives corrigés ; trois LOD, douze
livrées et débris. Limites de tri aux angles rasants documentées, non effacées par015.
