# McMurtry Spéirling PURE — final pack 021
by Alain il Professore — 13 November 2026

## Contents and latest changes
Complete021 pack: CARPURE.RES, STDAPURE.VSH, STDBPURE.VSH and STPURE.3SH.
The3SH is byte-identical to020; RES and cockpit are unchanged016 files.
Four rear lights on each LOD, enlarged CAR0 showroom lights, gutter shades across
all12CAR0/CAR1 liveries, showroom floor-mask correction. CAR2 retains017 shading.
User edits and debris preserved. Author credit, speed-only LCD and moving dot.
Reflowed EDES uses ASCII “Speirling”: stock FONTN has no e-acute glyph.
FR/EN/RUS documentation and backup-aware Windows/DOS setup/removal included.
This release only assembles current files; no additional native edits.
See HISTORIQUE for017–020 audits. DOS and grazing views are not newly certified.
Keep old packages and backups. Installing021 backs up the current game state;
removing021 restores that previous state.

## Windows installation / removal
Close Stunts/DOSBox. Extract the entire PURE021 folder inside the game directory,
e.g. C:\GAMES\STUNTS\PURE021, and run INSTALL_WIN.CMD.
Alternatively run INSTALL_WIN.CMD "C:\GAMES\STUNTS" from a separate location.
The game folder must contain LOAD.EXE and MISC.PRE or MISC.RES and be writable.
Payload hashes are checked, old files are backed up, competing packed files are
set aside. Keep PURE021 in place: it contains the backup and installation record.
Run UNINSTALL_WIN.CMD from the same pack to restore the recorded game directory.
Original files and original absences are restored; PURE_BACKUPS is retained.
Later edits block Windows removal. Save your edit elsewhere, restore the supplied
file, then retry. No game-wide configuration or unrelated car is changed.

## DOS / DOSBox
Put PURE021 directly inside STUNTS. Enter CD PURE021, then INSTALL.BAT.
To restore, enter CD PURE021 and REMOVE.BAT. Use one installation method only.
Keep PUREBAK. Save manual edits before DOS removal: it restores the originals.
After removal, archive/rename PUREBAK before reinstalling. DOS batch syntax was
checked; actual DOS execution was not tested.

## Profile and validation
Author-selected Wikipedia profile: displayed900kg, reference745kW,190mph;
ported-engine0–60mph measured1.55s at20Hz without rollout. Native inertia13 is
not kilograms. This differs from the manufacturer's1350kg production2026 PURE.
The torque envelope and fan grip are approximations; grip524 is unchanged.
Ported tests do not certify DOS operation or real-world performance. Existing
3SH painter-order limitations remain at grazing views. Windows installation and
restoration are tested in isolated fixtures, never in the installed game.
See VALIDATION_INSTALLATION.json, PAYLOAD_SHA256.json and SHA256SUMS.json.
Read CHANGELOG_EN.md and EDES_AVANT_APRES.md for changes.

Sources: https://en.wikipedia.org/wiki/McMurtry_Sp%C3%A9irling ;
https://mcmurtry.com/speirling-pure/ ; https://www.ehelix.com/communication/helix-delivers-ev-technology-for-mcmurtry-automotive/
