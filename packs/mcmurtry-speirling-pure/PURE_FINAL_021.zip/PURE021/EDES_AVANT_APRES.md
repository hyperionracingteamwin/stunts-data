# EDES 015 → 016

## 015

```text
McMurtry Speirling PURE
by Alain il Professore

Twin electric motors - RWD
745 kW / 100 kWh / 900 kg
190 MPH / 0-60 MPH: 1.55s
Fans suck air beneath the car
for downforce, even at rest.
```

## 016

```text
McMurtry Speirling PURE
by Alain il Professore

Twin electric motors/RWD
745kW / 100kWh / 900kg
190MPH / 0-60MPH:1.55s
Fans draw air under car
for downforce at rest.
```

Largeurs mesurées dans FONTN, maximum113px ; budget120px. Le code0x82 affiche une flèche : pas de faux é dans EDES.
