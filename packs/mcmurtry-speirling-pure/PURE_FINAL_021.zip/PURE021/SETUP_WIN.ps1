﻿param([ValidateSet('Install','Remove')][string]$Mode='Install',[string]$GamePath='')
$ErrorActionPreference='Stop'
$packagePath=$PSScriptRoot
if ([string]::IsNullOrWhiteSpace($GamePath)) {$GamePath=Join-Path $packagePath '..'}
$gamePathResolved=(Resolve-Path -LiteralPath $GamePath).Path
$activePath=Join-Path $packagePath 'PUREACT.JSN'
$nativeFiles=@('STDAPURE.VSH','STDBPURE.VSH','CARPURE.RES','STPURE.3SH')
$packedFiles=@('STDAPURE.PVS','STDBPURE.PVS','STPURE.P3S','CARPURE.PRE')
$allFiles=$nativeFiles+$packedFiles
function FileHash([string]$path) {
 $stream=[System.IO.File]::OpenRead($path)
 $algorithm=[System.Security.Cryptography.SHA256]::Create()
 try {[System.BitConverter]::ToString($algorithm.ComputeHash($stream)).Replace('-','')}
 finally {$algorithm.Dispose();$stream.Dispose()}
}
if ($Mode -eq 'Install') {
 if (!(Test-Path -LiteralPath (Join-Path $gamePathResolved 'LOAD.EXE')) -or
     (!(Test-Path -LiteralPath (Join-Path $gamePathResolved 'MISC.PRE')) -and !(Test-Path -LiteralPath (Join-Path $gamePathResolved 'MISC.RES')))) {throw 'Choose the Stunts folder containing LOAD.EXE and MISC.PRE/RES.'}
 if ($gamePathResolved -eq $packagePath) {throw 'The package must be in a subfolder of Stunts, or supply a separate game path.'}
 if (Test-Path -LiteralPath $activePath) {throw 'This package is already installed. Run UNINSTALL_WIN.CMD first.'}
 foreach ($name in $nativeFiles) {if (!(Test-Path -LiteralPath (Join-Path $packagePath $name))) {throw "Missing payload: $name"}}

 if (Test-Path -LiteralPath (Join-Path $packagePath 'PUREBAK\READY.OK')) {throw 'Active DOS installation: run REMOVE.BAT first.'}
 $expected=Get-Content -LiteralPath (Join-Path $packagePath 'PAYLOAD_SHA256.json') -Raw | ConvertFrom-Json
 foreach ($name in $nativeFiles) {
  if ([string]::IsNullOrWhiteSpace($expected.$name) -or (FileHash (Join-Path $packagePath $name)) -ne $expected.$name) {throw "Payload checksum mismatch: $name"}
 }
 $backupName='PURE_BACKUPS\'+(Get-Date -Format 'yyyyMMdd_HHmmss_fff')+'_'+[Guid]::NewGuid().ToString('N').Substring(0,8)
 $backupPath=Join-Path $packagePath $backupName
 New-Item -ItemType Directory -Path $backupPath -Force | Out-Null
 $entries=@()
 foreach ($name in $allFiles) {
  $target=Join-Path $gamePathResolved $name
  $existed=Test-Path -LiteralPath $target
  $oldHash=$null
  if ($existed) {
   $oldHash=FileHash $target
   Copy-Item -LiteralPath $target -Destination (Join-Path $backupPath $name)
   if ((FileHash (Join-Path $backupPath $name)) -ne $oldHash) {throw "Backup verification failed: $name"}
  }
  $newHash=if ($nativeFiles -contains $name) {FileHash (Join-Path $packagePath $name)} else {$null}
  $entries+=@{name=$name;existed=$existed;old_hash=$oldHash;installed_hash=$newHash}
 }
 $manifest=@{game_path=$gamePathResolved;backup=$backupName;files=$entries;version='McMurtry Speirling PURE final021';phase='backup_complete'}
 $manifest | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $activePath -Encoding UTF8
 try {
  foreach ($name in $packedFiles) {$target=Join-Path $gamePathResolved $name;if (Test-Path -LiteralPath $target) {Remove-Item -LiteralPath $target}}
  foreach ($name in $nativeFiles) {Copy-Item -LiteralPath (Join-Path $packagePath $name) -Destination (Join-Path $gamePathResolved $name) -Force}
  foreach ($entry in $entries | Where-Object {$null -ne $_.installed_hash}) {
   if ((FileHash (Join-Path $gamePathResolved $entry.name)) -ne $entry.installed_hash) {throw "Installation verification failed: $($entry.name)"}
  }
  $manifest.phase='installed';$manifest | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $activePath -Encoding UTF8
  Write-Host 'McMurtry Speirling PURE021 installed. Previous files are backed up.'
 } catch {
  foreach ($entry in $entries) {
   $target=Join-Path $gamePathResolved $entry.name
   if ($entry.existed) {Copy-Item -LiteralPath (Join-Path $backupPath $entry.name) -Destination $target -Force}
   elseif (Test-Path -LiteralPath $target) {Remove-Item -LiteralPath $target}
  }
  Move-Item -LiteralPath $activePath -Destination (Join-Path $backupPath 'ROLLED_BACK.json')
  throw
 }
} else {
 if (!(Test-Path -LiteralPath $activePath)) {throw 'No active installation recorded by this package.'}
 $manifest=Get-Content -LiteralPath $activePath -Raw | ConvertFrom-Json
 $gamePathResolved=$manifest.game_path
 $backupRoot=[IO.Path]::GetFullPath((Join-Path $packagePath 'PURE_BACKUPS'))+[IO.Path]::DirectorySeparatorChar
 $backupPath=[IO.Path]::GetFullPath((Join-Path $packagePath $manifest.backup))
 if (!$backupPath.StartsWith($backupRoot,[StringComparison]::OrdinalIgnoreCase)) {throw 'Backup path is outside PURE_BACKUPS.'}
 if (@($manifest.files).Count -ne $allFiles.Count -or @($manifest.files.name | Select-Object -Unique).Count -ne $allFiles.Count) {throw 'Invalid backup file list.'}
 foreach ($entry in $manifest.files) {if ($allFiles -notcontains $entry.name) {throw 'Unexpected backup filename.'}}

 # Check ALL backups and subsequent edits before the first restoration.
 foreach ($entry in $manifest.files) {
  $target=Join-Path $gamePathResolved $entry.name
  if ($entry.existed -and (!(Test-Path -LiteralPath (Join-Path $backupPath $entry.name)) -or (FileHash (Join-Path $backupPath $entry.name)) -ne $entry.old_hash)) {throw "Backup missing or changed: $($entry.name)"}
  if ($manifest.phase -eq 'installed' -and (Test-Path -LiteralPath $target)) {
   if ($null -eq $entry.installed_hash -or (FileHash $target) -ne $entry.installed_hash) {throw "File edited since installation: $($entry.name). Save that edit before uninstalling."}
  }
 }
 foreach ($entry in $manifest.files) {
  $target=Join-Path $gamePathResolved $entry.name
  if ($entry.existed) {Copy-Item -LiteralPath (Join-Path $backupPath $entry.name) -Destination $target -Force}
  elseif (Test-Path -LiteralPath $target) {Remove-Item -LiteralPath $target}
 }
 Move-Item -LiteralPath $activePath -Destination (Join-Path $backupPath 'RESTORED.json')
 Write-Host 'McMurtry Speirling PURE021 removed. Previous files restored; backups retained.'
}
