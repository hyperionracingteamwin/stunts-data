# Reprise PURE — pack complet021

Courant :dashboard_v021, archive PURE_FINAL_021.zip / dossier PURE021.
Assemblage strict :STPURE.3SH identique à020 ; CARPURE.RES / STDAPURE.VSH / STDBPURE.VSH identiques à016. Aucune nouvelle retouche native.
Toutes avancées017–020 intégrées :feux sur3LOD, masques plancher showroom, nuances12livrées CAR0/CAR1, feuxCAR0 agrandis. Profil Wikipédia900kg/745kW/190mph/1,55s, EDES recadré et dot conservés.
README/changelog FR/EN/RUS, installateurs Windows/DOS, sauvegarde/restauration. Windows testé dans copies isolées ; DOS non testé. Audits HISTORIQUE + AUDIT_ASSEMBLAGE.json.
Scripts assemble_final_v021.py et test_package_v021.py. Versions et originaux précédents conservés.
