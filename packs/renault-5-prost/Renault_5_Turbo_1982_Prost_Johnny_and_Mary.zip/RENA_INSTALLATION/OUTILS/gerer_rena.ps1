param(
    [Parameter(Mandatory=$true)][ValidateSet('Installer','Desinstaller')][string]$Action,
    [Parameter(Mandatory=$true)][string]$PackageRoot,
    [string]$GamePath = ''
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0
$Names = @('CARRENA.RES','STRENA.3SH','STDARENA.VSH','STDBRENA.VSH','SDTITL.VSH','TITLE.P3S','MTSKIDMS.VCE','SKIDSLCT.KMS','SKIDTITL.KMS','SKIDVICT.KMS','SKIDOVER.KMS','TDSKIDMS.VCE','ADSKIDMS.VCE','PCSKIDMS.VCE','CARRENA.PRE','STRENA.P3S','STDARENA.PVS','STDBRENA.PVS','SDTITL.PVS','SDTITL.XVS','SDTITL.PES','SDTITL.ESH','TITLE.3SH')
$PayloadNames = @('CARRENA.RES','STRENA.3SH','STDARENA.VSH','STDBRENA.VSH','SDTITL.VSH','TITLE.P3S','MTSKIDMS.VCE','SKIDSLCT.KMS','SKIDTITL.KMS','SKIDVICT.KMS','SKIDOVER.KMS','TDSKIDMS.VCE','ADSKIDMS.VCE','PCSKIDMS.VCE')
$CompressedNames = @('CARRENA.PRE','STRENA.P3S','STDARENA.PVS','STDBRENA.PVS','SDTITL.PVS','SDTITL.XVS','SDTITL.PES','SDTITL.ESH','TITLE.3SH')
$Markers = @('STUNTS_K.EXE','STUNTS.EXE','STUNTS.COM','STUNT.EXE','STUNT.COM','STUNT_K.EXE','GAME.EXE','GAME1.EXE','LOAD.EXE')

function Get-Hash([string]$Path) {
    return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
}
function Write-Json([string]$Path, $Value) {
    $text = $Value | ConvertTo-Json -Depth 6
    [IO.File]::WriteAllText($Path, $text, (New-Object Text.UTF8Encoding($false)))
}
function Is-Game([string]$Path) {
    foreach ($marker in $Markers) {
        if (Test-Path -LiteralPath (Join-Path $Path $marker) -PathType Leaf) { return $true }
    }
    return (Test-Path -LiteralPath (Join-Path $Path 'RENA_COMPLET_SAUVEGARDES\active.json') -PathType Leaf)
}
function Assert-Targets([string]$GameRoot) {
    foreach ($name in $Names) {
        $path = Join-Path $GameRoot $name
        if ((Test-Path -LiteralPath $path) -and !(Test-Path -LiteralPath $path -PathType Leaf)) {
            throw "Un dossier occupe le nom $name. Aucun fichier ne sera remplace."
        }
    }
}
function Save-Snapshot([string]$GameRoot, [string]$Folder) {
    New-Item -ItemType Directory -Path $Folder | Out-Null
    $entries = @()
    foreach ($name in $Names) {
        $path = Join-Path $GameRoot $name
        $present = Test-Path -LiteralPath $path -PathType Leaf
        $hash = ''
        if ($present) {
            $hash = Get-Hash $path
            $copy = Join-Path $Folder $name
            Copy-Item -LiteralPath $path -Destination $copy
            if ((Get-Hash $copy) -ne $hash) { throw "Sauvegarde invalide : $name" }
        }
        $entries += [pscustomobject]@{ name=$name; present=[bool]$present; sha256=$hash }
    }
    Write-Json (Join-Path $Folder 'etat.json') ([pscustomobject]@{ version=1; date=[DateTime]::Now.ToString('o'); entries=$entries })
}
function Read-Snapshot([string]$Folder) {
    $manifest = Get-Content -LiteralPath (Join-Path $Folder 'etat.json') -Raw | ConvertFrom-Json
    if ($manifest.version -ne 1 -or @($manifest.entries).Count -ne $Names.Count) { throw 'Sauvegarde incomplete.' }
    foreach ($name in $Names) {
        $matchedEntries = @($manifest.entries | Where-Object { $_.name -ceq $name })
        if ($matchedEntries.Count -ne 1) { throw "Entree de sauvegarde invalide : $name" }
        $entry = $matchedEntries[0]
        if ($entry.present -isnot [bool]) { throw "Etat invalide : $name" }
        if ($entry.present) {
            $path = Join-Path $Folder $name
            if (!(Test-Path -LiteralPath $path -PathType Leaf) -or (Get-Hash $path) -ne $entry.sha256) {
                throw "Sauvegarde absente ou endommagee : $name"
            }
        }
    }
    return $manifest
}
function Restore-Snapshot([string]$GameRoot, [string]$Folder) {
    # Validate every original before making the first change.
    $manifest = Read-Snapshot $Folder
    Assert-Targets $GameRoot
    foreach ($entry in $manifest.entries) {
        $target = Join-Path $GameRoot $entry.name
        if ($entry.present) {
            Copy-Item -LiteralPath (Join-Path $Folder $entry.name) -Destination $target -Force
            if ((Get-Hash $target) -ne $entry.sha256) { throw "Restauration incomplete : $($entry.name)" }
        } elseif (Test-Path -LiteralPath $target -PathType Leaf) {
            Remove-Item -LiteralPath $target -Force
        }
    }
}
function New-SessionName {
    return ([DateTime]::Now.ToString('yyyyMMdd_HHmmss') + '_' + [Guid]::NewGuid().ToString('N').Substring(0,8))
}

try {
    $PackageRoot = [IO.Path]::GetFullPath($PackageRoot)
    if ($GamePath) {
        $GameRoot = [IO.Path]::GetFullPath($GamePath)
        if (!(Test-Path -LiteralPath $GameRoot -PathType Container) -or !(Is-Game $GameRoot)) {
            throw 'Le dossier indique ne contient pas Stunts.'
        }
    } else {
        $GameRoot = $null
        foreach ($candidate in @($PackageRoot, (Split-Path -Parent $PackageRoot))) {
            if (Is-Game $candidate) { $GameRoot = $candidate; break }
        }
        if (!$GameRoot) {
            throw 'Placez le dossier RENA_INSTALLATION dans le dossier de Stunts, puis relancez le BAT.'
        }
    }
    Assert-Targets $GameRoot
    $backupRoot = Join-Path $GameRoot 'RENA_COMPLET_SAUVEGARDES'
    $activeFile = Join-Path $backupRoot 'active.json'
    Write-Host "Dossier du jeu : $GameRoot"
    $session = $null
    if (Test-Path -LiteralPath $activeFile -PathType Leaf) {
        $active = Get-Content -LiteralPath $activeFile -Raw | ConvertFrom-Json
        if ($active.version -ne 1 -or $active.session -cnotmatch '^\d{8}_\d{6}_[a-f0-9]{8}$') { throw 'Etat de l installation invalide.' }
        $session = Join-Path $backupRoot $active.session
        $original = Join-Path $session 'original'
        $null = Read-Snapshot $original
    }

    if ($Action -eq 'Desinstaller') {
        if (!$session) { Write-Host 'Aucune installation RENA active : rien a desinstaller.'; exit 0 }
        $recovery = Join-Path $session ('avant_desinstallation_' + (New-SessionName))
        Save-Snapshot $GameRoot $recovery
        try {
            Restore-Snapshot $GameRoot $original
            Remove-Item -LiteralPath $activeFile -Force
        } catch {
            $failure = $_
            Restore-Snapshot $GameRoot $recovery
            throw $failure
        }
        Write-Host 'Desinstallation terminee. Les anciens fichiers ont ete retablis.' -ForegroundColor Green
        Write-Host "Le mod retire et les sauvegardes restent disponibles dans : $session"
        exit 0
    }

    # Check the whole payload before creating a backup or changing the game.
    $manifest = Get-Content -LiteralPath (Join-Path $PackageRoot 'OUTILS\payload.json') -Raw | ConvertFrom-Json
    if (@($manifest.files).Count -ne $PayloadNames.Count) { throw 'Pack incomplet.' }
    foreach ($name in $PayloadNames) {
        $entries = @($manifest.files | Where-Object { $_.name -ceq $name })
        $path = Join-Path (Join-Path $PackageRoot 'payload') $name
        if ($entries.Count -ne 1 -or !(Test-Path -LiteralPath $path -PathType Leaf)) { throw "Fichier manquant : $name" }
        if ((Get-Hash $path) -ne $entries[0].sha256) { throw "Fichier endommage : $name" }
    }
    $firstInstall = !$session
    if ($firstInstall) {
        New-Item -ItemType Directory -Path $backupRoot -Force | Out-Null
        $sessionName = New-SessionName
        $session = Join-Path $backupRoot $sessionName
        New-Item -ItemType Directory -Path $session | Out-Null
        $original = Join-Path $session 'original'
        Save-Snapshot $GameRoot $original
        $current = $original
        # If interrupted, DESINSTALLER.BAT can immediately restore this snapshot.
        Write-Json $activeFile ([pscustomobject]@{ version=1; session=$sessionName })
    } else {
        $current = Join-Path $session ('avant_reinstallation_' + (New-SessionName))
        Save-Snapshot $GameRoot $current
    }
    try {
        foreach ($name in $PayloadNames) {
            $source = Join-Path (Join-Path $PackageRoot 'payload') $name
            $target = Join-Path $GameRoot $name
            Copy-Item -LiteralPath $source -Destination $target -Force
            if ((Get-Hash $target) -ne (Get-Hash $source)) { throw "Copie incomplete : $name" }
        }
        foreach ($name in $CompressedNames) {
            $target = Join-Path $GameRoot $name
            if (Test-Path -LiteralPath $target -PathType Leaf) { Remove-Item -LiteralPath $target -Force }
        }
    } catch {
        $failure = $_
        Restore-Snapshot $GameRoot $current
        if ($firstInstall) { Remove-Item -LiteralPath $activeFile -Force }
        throw $failure
    }
    Write-Host 'Installation terminee : Renault 5 Turbo Prost + intro VGA/3D + Johnny and Mary.' -ForegroundColor Green
    Write-Host "Sauvegarde des anciens fichiers : $original"
    Write-Host 'Pour revenir en arriere : double-cliquez sur DESINSTALLER.BAT.'
    exit 0
} catch {
    Write-Host ''
    Write-Host ('ERREUR : ' + $_.Exception.Message) -ForegroundColor Red
    Write-Host 'Fermez Stunts et DOSBox avant de reessayer. Conservez RENA_COMPLET_SAUVEGARDES.'
    exit 1
}