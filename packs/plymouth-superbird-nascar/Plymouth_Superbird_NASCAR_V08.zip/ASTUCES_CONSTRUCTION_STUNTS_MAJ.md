# Astuces de construction Stunts — conservation et dashboards

Mise à jour : 26 octobre 2026. Retour d’expérience du cockpit Plymouth Superbird NASCAR BIRD, jusqu’à V08, pour Stunts 1.1 VGA.

by Alain il Professore

## Spécifications EDES à conserver

Lorsqu’une réforme des caractéristiques physiques d’une voiture modifie `CARXXXX.RES`, conserver la fiche de spécifications déjà affichée en jeu.

Procédure obligatoire :

1. sauvegarder le bloc EDES existant et sa chaîne de spécifications ;
2. modifier uniquement les champs SIMD nécessaires à la physique ;
3. réinjecter la chaîne EDES antérieure, avec ses séparateurs `]`, son octet nul final et le code `GSNA` attendu ;
4. mettre à jour la taille totale du conteneur ;
5. vérifier que les lignes restent lisibles dans la fiche du véhicule.

Une réforme physique ne doit donc jamais supprimer, raccourcir ou réinitialiser les spécifications visibles en jeu.

Complément vérifié : terminer aussi la **dernière ligne** par `]`, avant l’octet nul. Dans le code de fiche examiné, `]` déclenche l’affichage d’une ligne ; le nul seul ne valide pas la dernière. C’était une cause de disparition de la signature. Pour BIRD, conserver notamment `590 hp]`, `Nascar torque curve]` et `by Alain il Professore]`. Un libellé affiché ne transforme pas la courbe de simulation en mesure au banc : conserver les hypothèses et la provenance dans les sources.

## 1. Trois coûts mémoire à mesurer séparément

1. **Taille du VSH brut** : tous les rectangles de pixels, leurs en-têtes, la table des ressources et les alignements.
2. **Occupation après conversion RLE** : dépend aussi du contenu des images, des changements de couleur et des répétitions.
3. **Pic pendant le chargement** : le chemin à deux tampons charge les données brutes, réserve un second bloc aussi grand, convertit, puis libère le premier. Prévoir environ deux fois le brut à ce stade, plus les autres ressources et les frais du gestionnaire. Ce n’est pas simplement brut + taille RLE finale.

Le port restunts utilisé pour l’audit possède aussi une solution de repli avec chevauchement de tampons. Ne pas supposer que le Stunts DOS de l’utilisateur dispose de cette modification. La fragmentation et les autres ressources chargées comptent également.

**Aucun plafond universel de 64 Kio par VSH n’a été démontré dans ces essais.** Des champs et opérations restent sur 16 bits ; cela impose de contrôler chaque structure, pas d’inventer une limite globale. La zone de 95–100 ko atteinte par BIRD est un repère de ce projet, pas une garantie pour toutes les installations.

### Budget d’un rectangle VGA

Pour les bitmaps natifs 8 bits exportés ici, un pixel coûte **un octet**, y compris un pixel transparent ou de fond. Chaque bitmap ajoute un en-tête de 16 octets. Notre conteneur ajoute `6 + 8 × N` octets pour N ressources et notre exporteur aligne chaque bloc sur 16 octets, soit 0 à 15 octets de remplissage par bloc.

Estimation avant export : `6 + 8N + somme(16 + largeur × hauteur + remplissage)`.

| Ressource ou choix | Pixels bruts, hors en-têtes |
| --- | ---: |
| Image + masque 320 × 112 | 71 680 octets |
| Image + masque 72 × 108 | 15 552 octets |
| Trois images de volant de W × H | 3 × W × H octets |
| Une image d’instruments 72 × 34 | 2 448 octets |
| Une image d’instruments 64 × 26 | 1 664 octets |
| Roof 320 × 10 | 3 200 octets |

Un masque binaire 0/255 occupe ici autant d’octets que l’image : il n’est pas stocké sur un seul bit. Réduire une surface d’instruments de 72 × 34 à 64 × 26 économise 784 octets **par image concernée**. Compter séparément ses éventuelles copies et les tampons créés à l’exécution ; ne pas appliquer un multiplicateur sans inventaire.

Réduire le nombre de couleurs ou le bruit peut améliorer le RLE, mais ne réduit pas le produit largeur × hauteur du VSH brut. Compresser en ZIP ne change pas la RAM en jeu. Un PVS réduit le fichier sur disque ; il faut toujours tenir compte de la décompression, de ses éventuels tampons temporaires et de la conversion suivante. Aucun gain RAM par simple passage en PVS n’a été validé pour ce pack.

### Mesures conservées du projet BIRD

| Version / fichier | Brut sur disque | Après conversion RLE | Test du chargeur avec budget de 200 000 octets |
| --- | ---: | ---: | --- |
| V04 STDA | 174 926 | Non mesuré | Échec mémoire |
| V05 STDA | 95 542 | 59 542 | Réussi |
| V06 STDA | 95 286 | 60 366 | Réussi |
| V07 STDA | 97 198 | 60 749 | Réussi, 15 bitmaps |
| V08 STDA | 97 198 | 60 613 | Réussi, 15 bitmaps |
| V06/V07 STDB | 2 102 | 1 388 | Réussi, 18 bitmaps |

Ce banc d’essai utilise le chargeur C restunts sur l’hôte, avec budget contraint et comparaison des pixels décodés. Ce n’est pas une partie de Stunts DOS ni une mesure de toute la mémoire du jeu. Le brut diminue entre V05 et V06 alors que le RLE augmente : les deux mesures sont bien distinctes.

## 2. Gagner de la place sans déformer le cockpit

- Faire l’inventaire de chaque ressource : identifiant, dimensions, position, ancre et coût brut. Repérer les grands rectangles presque vides et les images répétées.
- Recadrer au rectangle utile avant de réduire l’échelle du dessin. Recalculer les positions et ancres après chaque recadrage et vérifier les coordonnées SIMD associées.
- Préserver les proportions du montant, de son rembourrage, des barres et du filet. Leur miniaturisation pour atteindre un budget produit un cockpit incohérent.
- Le rétro est **facultatif** : ne pas en ajouter absolument. Pour BIRD V07, la décision est de le supprimer, avec son pied. Son dessin ne justifie ni une mauvaise place ni un grand masque coûteux.
- Conserver le `roof` demandé comme ressource native. BIRD V07 utilise un bandeau 320 × 10 en (0,0), raccordé au montant. `dast` et `dasm` sont recadrés à 72 × 108 en (0,10), sans répéter cette bande dans leur rectangle.
- Un changement de fond doit être reporté dans toutes les copies qui le contiennent. Retirer un miroir de `dash` seul laisse des fragments s’il est aussi incrusté dans les trois images `whl1`, `whl2`, `whl3`.

Un recadrage du volant doit encore couvrir les zones à restaurer lors des changements de pose. Une petite image mal découpée peut laisser des traces : contrôler l’animation, pas seulement le poids final.

## 3. Masques natifs et ordre des couches

Le PNG transparent est une source de travail ; son canal alpha ne remplace pas les ressources natives image/masque. Utiliser la palette VGA attendue, des dimensions, positions et ancres identiques pour chaque paire.

Pour les paires AND/OR employées ici : masque 0 sur le dessin opaque, 255 là où le fond doit être conservé ; image à 0 dans ces zones transparentes. Éliminer les îlots et pixels isolés. Vérifier ensemble `dast/dasm`, les instruments masqués et `gnob/gnab` ; ne pas créer de masque supplémentaire dont le moteur ne se sert pas.

Les aiguilles doivent passer derrière les gants, les branches et le cerclage prévus. Dans l’implémentation examinée, `ins2` n’a pas de compagnon `inm2` exploité comme les autres paires : contrôler sa restauration et ses fonds explicitement.

## 4. Lisibilité, volant et instruments

Concevoir les grands cadrans dans le jour laissé par le volant. Un léger déplacement des cadrans vers la gauche et du volant vers le bas peut dégager la lecture sans rapetisser le volant. Garder les deux mains et contrôler les trois poses : une position centrale lisible ne garantit pas les virages.

Pour le tachymètre, partager le même centre et la même échelle angulaire entre graduations, chiffres et aiguille. Placer les chiffres à l’intérieur du cerclage sur un rayon cohérent. Vérifier aussi les extrémités de l’échelle, les chevauchements et les positions des aiguilles. Un pourcentage de surface visible aide le diagnostic mais ne suffit pas à juger la lisibilité réelle.

## 5. Levier : respecter l’effet demandé

Pour ce cockpit, le soufflet et le pommeau doivent être **absents au repos** et apparaître seulement pendant le changement de rapport. Ne pas réintroduire un pommeau fixe sous prétexte de réalisme.

- `dash` contient le fond nu, sans soufflet ni pommeau.
- `gbox`, dans STDA, fournit le fond du levier pendant l’animation.
- `gnob` et `gnab`, dans STDB, fournissent le pommeau et son masque, en vue sommitale.
- À la fin du délai de changement, le moteur restaure le fond depuis `dash` : cette disparition est ici intentionnelle.
- Agrandir légèrement le pommeau impose de recalculer son ancre pour conserver les centres des rapports. BIRD conserve 12 × 10 pixels, ancre (6,5).

Dans le SIMD étudié, les sept couples de coordonnées occupent les octets `0x1C` à `0x37`. Un huitième couple écraserait les données suivantes à `0x38`, notamment la traînée. Contrôler les offsets avant toute écriture.

## 6. Contrôle obligatoire avant livraison

1. Réouvrir les fichiers réellement exportés : taille du conteneur, table, offsets, dimensions, ancres, paires de masques et chaînes EDES.
2. Assembler toutes les couches en cadre natif 320 × 200, puis afficher avec correction 4:3, par exemple à 320 × 240 ou 960 × 720. Examiner la vue entière avec recul.
3. Vérifier roof, raccord au montant, taille du filet, ouverture sur la route, volant, gants, cadrans et objets facultatifs. Ne pas valider un dashboard à partir d’un seul détail agrandi.
4. Examiner les trois poses du volant, plusieurs positions d’aiguille, le levier au repos, pendant le changement et après restauration. Rechercher les fragments de l’ancien fond.
5. Relever taille brute, taille après conversion et budget du test de chargement ; archiver l’audit. Tester en jeu DOS pour confirmer la jouabilité et la mémoire dans l’installation cible.

Les aperçus BIRD livrés sont des **assemblages des ressources**, pas des captures d’une partie. Ne pas présenter le test du chargeur comme un essai complet du jeu.

## 7. Complément V08 : chiffres et fermeture 3D de l’habitacle

Les chiffres du compte-tours suivent maintenant la suite complète 0, 1, 2, 3, 4, 5, 6, 7, 8 dans le sens horaire, avec l’unité RPM ×1000. Chaque valeur suit l’angle de son aiguille, de 140° à 400° dans les coordonnées de l’image. Sur le compteur de vitesse, conserver des chiffres 3 × 5 lisibles et des valeurs compatibles avec la table native (0 à 260 mph ; chiffres principaux 0, 100 et 200). Une police trop réduite peut rendre une graduation mathématiquement correcte visuellement erronée. Reporter les nouveaux fonds dans DASH, WHL et INS, en préservant les pixels des mains et du volant.

La fermeture de l’habitacle est un problème distinct du `roof` bitmap du dashboard : il s’agit de géométrie 3SH. Dans le fichier joint pour V08, le toit n°94 était déjà double face avec culling ouvert. Le grand panneau intérieur n°145 pouvait néanmoins le recouvrir dans la file de rendu native, triée selon une profondeur moyenne par primitive. Cocher « double face » ou recalculer seulement le culling ne corrige pas ce conflit de tri.

Solution BIRD vérifiée : garder le toit et ses numéros, puis remplacer la fermeture unique par neuf panneaux jointifs. Les limites intérieures suivent l’emprise du toit (X = −220/+220, Z = −380/+80 dans car0), les bords extérieurs suivent le panneau ajouté par l’utilisateur. Le panneau central et le toit partagent ainsi leur centre horizontal ; les parties périphériques ne prêtent plus leur profondeur moyenne à la zone située sous le toit. Appliquer la même géométrie à car1 à l’échelle 1/20, avec arrondi natif cohérent. Ne pas réutiliser un sommet arrière décalé d’un seul côté.

La correction conserve 241 sommets et 153 primitives par modèle détaillé, sous les limites du format utilisé ici. Les neuf panneaux sont double face, sans superposition avec le toit et sans Z-bias artificiel. Le contrôle de la file de rendu C, sur 288 combinaisons d’angles et de modèles, ne relève plus de pixel du toit recouvert par cette fermeture. Cela ne garantit pas à lui seul tout l’affichage en jeu : conserver l’audit, les vues avant/après et la distinction avec un essai DOS complet.

## Sources techniques et reproductibilité

- [Stressed](https://github.com/dstien/stressed) : palette et conventions des ressources, notamment `resources/conf/defaults.conf`.
- [restunts-bb11](https://github.com/CommonLoon102/restunts-bb11) : code examiné dans `src/restunts/c/shape2d_resources.c`, `dashboard.c` et `menu_car.c`.
- Projet BIRD : exporteurs `build_final_v04.py` à `build_final_v07.py`, banc `test_bird_native_loader.c`, audits V05/V06/V07 et aperçus d’assemblage.

Pour V07, `AUDIT_V07.json` consigne les tailles, la présence du roof, le retrait du rétro, le résultat du chargeur et les SHA-256 des quatre fichiers voiture. Garder ces preuves avec les sources ; les faits propres à cette version ne sont pas des règles universelles du moteur.
