"""BIRD cockpit: native indexed Stunts resources from generated painted artwork.
Technical extraction/compositing only. Masks use AND=0/255 and OR artwork=0 outside.
"""
from pathlib import Path
import struct,json,hashlib,re,math,zipfile,shutil
import numpy as np
from PIL import Image,ImageDraw,ImageFont
from scipy import ndimage
ROOT=Path('/workspace/scratch/4ce29ee9399e')
OUT=ROOT/'outputs/superbird_cockpit_v03'; OUT.mkdir(parents=True,exist_ok=True)
SRC=OUT/'sources_indexees'; SRC.mkdir(exist_ok=True)
G=ROOT/'generated_images'
PAL=np.array(json.loads((ROOT/'work/bird_cockpit/palette.json').read_text()),dtype=np.uint8)
assert PAL.shape==(256,3) and list(PAL[0])==[0,0,0]
def quant(im):
 a=np.asarray(im.convert('RGB')); flat=a.reshape(-1,3).astype(np.int32); colors=PAL[:255].astype(np.int32)
 result=np.empty(len(flat),np.uint8)
 for i in range(0,len(flat),2048):
  dist=((flat[i:i+2048,None,:]-colors[None,:,:])**2).sum(axis=2)
  result[i:i+2048]=dist.argmin(axis=1)
 return result.reshape(a.shape[:2])
def pim(a):
 im=Image.fromarray(np.asarray(a,dtype=np.uint8),'P');im.putpalette(PAL.flatten().tolist());return im
def save(a,name,alpha=False):
 im=pim(a)
 if alpha:im.info['transparency']=255
 im.save(SRC/(name+'.png'))
def parse(path):
 d=Path(path).read_bytes();size,n=struct.unpack_from('<IH',d);assert size==len(d)
 names=[d[6+4*i:10+4*i].decode('ascii') for i in range(n)]
 offsets=struct.unpack_from('<'+'I'*n,d,6+4*n);start=6+8*n
 assert len(set(names))==n and len(set(offsets))==n
 blocks={}
 for i,k in enumerate(names):
  end=min([o for o in offsets if o>offsets[i]]+[len(d)-start]);assert 0<=offsets[i]<end<=len(d)-start
  blocks[k]=d[start+offsets[i]:start+end]
 return names,blocks
def container(names,blocks):
 payload=b'';offsets=[]
 for k in names:
  offsets.append(len(payload));payload+=blocks[k];payload+=b'\0'*(-len(payload)%16)
 return struct.pack('<IH',6+8*len(names)+len(payload),len(names))+b''.join(k.encode('ascii') for k in names)+struct.pack('<'+'I'*len(names),*offsets)+payload
def bmp(a,xy=(0,0),anchor=(0,0)):
 a=np.asarray(a,np.uint8);h,w=a.shape
 return struct.pack('<6h',w,h,*anchor,*xy)+bytes([1,2,4,8])+a.tobytes()
def bitmap(block):
 w,h,cx,cy,x,y=struct.unpack_from('<6h',block);assert 0<w<=320 and 0<h<=200 and len(block)>=16+w*h
 return np.frombuffer(block[16:16+w*h],np.uint8).reshape(h,w).copy(),(x,y),(cx,cy)
def remove_specks(alpha,minimum=3):
 labels,n=ndimage.label(alpha);sz=np.bincount(labels.ravel());return alpha & (sz[labels]>=minimum)
def clean_rgba(path,sz=None):
 im=Image.open(path).convert('RGBA')
 if sz:im=im.resize(sz,Image.Resampling.LANCZOS)
 a=np.asarray(im).copy();keep=remove_specks(a[:,:,3]>=128)
 a[:,:,3]=np.where(keep,255,0);return Image.fromarray(a)
def alpha_blit(dst,src,mask,x,y):
 h,w=src.shape;sl=dst[y:y+h,x:x+w];sl[mask]=src[mask]
def glyphs():
 raw={'0':'111101101101111','1':'010110010010111','2':'111001111100111','3':'111001111001111','4':'101101111001001','5':'111100111001111','6':'111100111101111','7':'111001010010010','8':'111101111101111','9':'111101111001111','R':'110101110101101','P':'110101110100100','M':'101111111101101','H':'101101111101101','X':'101101010101101','K':'101101110101101'}
 return {k:np.array([int(x) for x in v],np.uint8).reshape(5,3) for k,v in raw.items()}
FONT=glyphs()
def text(a,word,cx,y,color=17):
 x=round(cx-(4*len(word)-1)/2)
 for c in word:
  if c in FONT:
   mask=FONT[c].astype(bool);sl=a[y:y+5,x:x+3]
   if sl.shape==(5,3):sl[mask]=color
  x+=4
def line(a,p,q,color):
 im=Image.fromarray(a,'L');ImageDraw.Draw(im).line([tuple(p),tuple(q)],fill=int(color));a[:]=np.array(im)
def line_coords(p,q):
 x,y=p;xx,yy=q;dx=abs(xx-x);sx=1 if x<xx else -1;dy=-abs(yy-y);sy=1 if y<yy else -1;err=dx+dy;points=[]
 while True:
  points.append((x,y))
  if x==xx and y==yy:return points
  e=2*err
  if e>=dy:err+=dy;x+=sx
  if e<=dx:err+=dx;y+=sy

# DAST and DASM form the upper cockpit, including the complete left net.
art=clean_rgba(G/'exec-31487771-2513-403c-89bc-6922f132a7b3.png',(320,200))
artarray=np.array(art); cockpit=quant(art); opaque=artarray[:,:,3]>0
cockpit[~opaque]=0
# DASH is an opaque full-width native bitmap, including its dark recesses.
opaque[122:,:]=True
base=cockpit.copy()

# Gear boot, explicitly top-down. Install on the lower right floor, below gauges.
bootim=clean_rgba(G/'exec-28035876-ecbf-49ba-aae3-8a2824dde262.png')
bootbox=bootim.getbbox();bootim=bootim.crop(bootbox).resize((40,30),Image.Resampling.LANCZOS)
bootq=quant(bootim);bootmask=np.array(bootim)[:,:,3]>=128
alpha_blit(base,bootq,bootmask,270,168)

# Extract the white sphere from the generated zenithal reference, no stem.
knobsrc=Image.open(G/'exec-16cdaa90-4a2d-4923-a1ec-4aff8b2eb1de.png').convert('RGBA')
ka=np.asarray(knobsrc);yy,xx=np.indices(ka.shape[:2]);roi=(xx>500)&(xx<840)&(yy>420)&(yy<770)
light=(ka[:,:,:3].min(axis=2)>125)&roi
lab,n=ndimage.label(light);sizes=np.bincount(lab.ravel());sizes[0]=0;km=lab==sizes.argmax()
ys,xs=np.where(km);kb=(xs.min(),ys.min(),xs.max()+1,ys.max()+1)
karr=ka.copy();karr[:,:,3]=np.where(km,255,0);knobim=Image.fromarray(karr).crop(kb).resize((10,8),Image.Resampling.LANCZOS)
knob=quant(knobim);knobmask=np.array(knobim)[:,:,3]>=128;knob[~knobmask]=0;knab=np.where(knobmask,0,255).astype(np.uint8)

# Gauge calibration is code-native: markings, units and every needle coordinate.
tach=(148,150);speed=(190,151);tachrad=(16,16);speedrad=(11,11)
for val in [0,2,4,6,8]:
 angle=math.radians(140+260*val/8);text(base,str(val),tach[0]+19*math.cos(angle),round(tach[1]+18*math.sin(angle))-2,17)
text(base,'RPM',tach[0],tach[1]+7,19)
for val in [0,100,200]:
 angle=math.radians(140+260*val/260);text(base,str(val),speed[0]+10*math.cos(angle),round(speed[1]+9*math.sin(angle))-2,19)
text(base,'MPH',speed[0],speed[1]+5,19)
for cx in [223,244,266,287]:line(base,(cx,151),(cx-3,146),38)

# Enlarged steering wheel with independently drawn driver poses. The inner holes
# show the exact underlying dashboard. No gray/opaque disc fills the wheel.
wheel_frames={};wheel_masks={};wheel_rgba={};wheelrect=(32,122,224,78)
wx,wy,ww,wh=wheelrect
sx,sy=140/980,100/980
hub=(150,172);source_hub=(727,529)
wheel_sources={'whl1':'exec-c4695802-bea8-41b7-9adf-b6be5afa50df.png','whl2':'exec-fced5874-4aa9-40ad-ac43-1e64c261d93a.png','whl3':'exec-935e5fd7-ecb5-4579-be6c-6e2e10bf5b3f.png'}
for key,filename in wheel_sources.items():
 original=Image.open(G/filename).convert('RGBA')
 assert original.size==(1454,1082)
 # Map the same rim and hub landmarks for all three independently drawn poses.
 im=original.transform((ww,wh),Image.Transform.AFFINE,
  (1/sx,0,source_hub[0]+(wx-hub[0])/sx,0,1/sy,source_hub[1]+(wy-hub[1])/sy),Image.Resampling.BICUBIC)
 q=quant(im);mask=remove_specks(np.array(im)[:,:,3]>=160,3)
 wheel_masks[key]=np.zeros((200,320),bool);wheel_masks[key][wy:wy+wh,wx:wx+ww]=mask
 frame=base[wy:wy+wh,wx:wx+ww].copy();alpha_blit(frame,q,mask,0,0)
 wheel_frames[key]=frame;wheel_rgba[key]=(q,mask)
 save(np.where(mask,q,255),key+'_GANTS_DETOURES',True)

namesA,oldA=parse(ROOT/'work/08-BACK_V14_INSTALLATION/STDABACK.VSH')
namesB,oldB=parse(ROOT/'work/08-BACK_V14_INSTALLATION/STDBBACK.VSH')
A={k:oldA[k] for k in ['!cg0','!eg0']};B={k:oldB[k] for k in ['!cg0','!eg0']}
A['roof']=bmp(base[:10,:],(0,0));A['dast']=bmp(np.where(opaque[10:122,:],base[10:122,:],0),(0,10))
A['dasm']=bmp(np.where(opaque[10:122,:],0,255),(0,10))
# Native Stunts hides GNOB after its shift delay. DASH supplies the resting knob;
# GBOX is the same clean console without that knob while GNOB is moving.
static_dash=base.copy();alpha_blit(static_dash,knob,knobmask,285,179)
A['dash']=bmp(static_dash[122:200,:],(0,122))
for key,frame in wheel_frames.items():A[key]=bmp(frame,(wx,wy),(hub[0]-wx,hub[1]-wy))
gx,gy,gw,gh=256,162,64,38
A['gbox']=bmp(base[gy:gy+gh,gx:gx+gw],(gx,gy))
ix,iy,iw,ih=124,127,84,46
neutral=base.copy();neutral[wy:wy+wh,wx:wx+ww]=wheel_frames['whl2']
A['ins2']=bmp(neutral[iy:iy+ih,ix:ix+iw],(ix,iy))
for key,whl in [('1','whl1'),('3','whl3')]:
 side=base.copy();side[wy:wy+wh,wx:wx+ww]=wheel_frames[whl]
 # Both gloves and all spokes can overlap the complete instrument panel.
 cover=(wheel_masks[whl]|wheel_masks['whl2'])[iy:iy+ih,ix:ix+iw]
 image=np.where(cover,side[iy:iy+ih,ix:ix+iw],0).astype(np.uint8)
 mask=np.where(cover,0,255).astype(np.uint8)
 A['ins'+key]=bmp(image,(0,0));A['inm'+key]=bmp(mask,(0,0))
B['gnob']=bmp(knob,(0,0),(5,4));B['gnab']=bmp(knab,(0,0),(5,4))
dot=np.zeros((8,8),np.uint8);dm=np.full((8,8),255,np.uint8)
B['dot ']=bmp(dot,(0,0),(4,4));B['dota']=bmp(dm,(0,0),(4,4))
for key in ['dot1','dot2']:B[key]=bmp(np.zeros((8,8),np.uint8),(0,0),(4,4))
for key in ['dig'+str(i) for i in range(10)]:B[key]=oldB[key]

# The uploaded CARBIRD is authoritative. Preserve torque, ratios, physics and text.
carorder,carblocks=parse(ROOT/'outputs/superbird_cockpit_v02/CARBIRD.RES');sim=bytearray(carblocks['simd']);before=bytes(sim)
knob_points=[(34,21),(31,18),(31,24),(37,18),(37,24),(37,24),(37,24)]
for i,(x,y) in enumerate(knob_points):struct.pack_into('<hh',sim,0x1c+4*i,x,y)
for i in range(31):
 angle=math.radians(-90+min(i,30)*2.2);x=118+round(64*math.cos(angle));y=50+round(47*math.sin(angle))
 sim[0xea+2*i:0xec+2*i]=bytes([x,y])
needle_stats=[]
for kind,center,rad,pivot_off,count_off,point_off,count,scale in [('speed',speed,speedrad,0x128,0x12c,0x12e,104,260),('rpm',tach,tachrad,0x1fe,0x202,0x204,128,8000)]:
 struct.pack_into('<hh',sim,pivot_off,center[0]-ix,center[1]-iy)
 struct.pack_into('<h',sim,count_off,count)
 minlen=999;clipped=0
 for i in range(count):
  value=i*2.5 if kind=='speed' else i*128
  angle=math.radians(140+260*min(value/scale,1));tip=(round(center[0]+rad[0]*math.cos(angle)),round(center[1]+rad[1]*math.sin(angle)))
  coords=line_coords(center,tip);visible=[]
  for px,py in coords:
   # Native has masks for left/right but no INM2; avoid painting across the neutral rim.
   if wheel_masks['whl2'][py,px]:break
   visible.append((px,py))
  assert len(visible)>3,(kind,i,visible)
  if len(visible)<len(coords):clipped+=1
  tip=visible[-1];minlen=min(minlen,len(visible))
  sim[point_off+2*i:point_off+2*i+2]=bytes([tip[0]-ix,tip[1]-iy])
 needle_stats.append({'gauge':kind,'pivot_screen':center,'points':count,'minimum_line_pixels':minlen,'clipped_at_neutral_wheel':clipped})
struct.pack_into('<H',sim,0xae,38|(38<<8))
carblocks['simd']=bytes(sim)
for name,order,blocks in [('STDABIRD.VSH',namesA,A),('STDBBIRD.VSH',namesB,B)]:
 assert set(order)==set(blocks),(set(order)-set(blocks),set(blocks)-set(order))
 (OUT/name).write_bytes(container(order,blocks))
(OUT/'CARBIRD.RES').write_bytes(container(carorder,carblocks))

# Re-read every native resource and verify mask semantics and unchanged physics.
for name,expected in [('STDABIRD.VSH',A),('STDBBIRD.VSH',B)]:
 _,actual=parse(OUT/name)
 for key,block in actual.items():
  pix,xy,anchor=bitmap(block);assert block[:16+pix.size]==expected[key][:16+pix.size]
  save(pix,name.split('.')[0]+'_'+key.strip(),key in ['dasm','inm1','inm3','gnab','dota'])
for blocks,imkey,maskkey in [(A,'dast','dasm'),(A,'ins1','inm1'),(A,'ins3','inm3'),(B,'gnob','gnab'),(B,'dot ','dota')]:
 image,xy,anchor=bitmap(blocks[imkey]);mask,mxy,ma=bitmap(blocks[maskkey])
 assert image.shape==mask.shape and xy==mxy and anchor==ma
 assert set(np.unique(mask)) <= {0,255}
 assert np.all(image[mask==255]==0),imkey
assert bitmap(A['gbox'])[0].tobytes()==base[162:200,256:320].tobytes()
resting_console=bitmap(A['gbox'])[0].copy();alpha_blit(resting_console,knob,knobmask,29,17)
assert np.array_equal(resting_console,bitmap(A['dash'])[0][40:78,256:320])
_,rereadcar=parse(OUT/'CARBIRD.RES');after=rereadcar['simd'][:776]
assert before[:0x1c]==after[:0x1c]
assert before[0x38:0xae]==after[0x38:0xae]
assert before[0xb0:0xea]==after[0xb0:0xea]
assert all(carblocks[k]==rereadcar[k][:len(carblocks[k])] for k in ['edes','gnam','gsna'])
assert b'by Alain il Professore' in rereadcar['edes']
for x,y in knob_points:
 assert 0<=x-5 and x+5<=gw and 0<=y-4 and y+4<=gh

# Previews follow the native AND/OR composition. Background is a neutral test fixture.
def scene():
 im=Image.new('L',(320,200),130);d=ImageDraw.Draw(im)
 d.rectangle((0,75,320,130),fill=99);d.polygon([(147,75),(173,75),(295,122),(25,122)],fill=25)
 d.line([(160,75),(160,122)],fill=15,width=1)
 for i in range(6):d.line([(0,80+i*8),(320,80+i*8)],fill=109)
 return np.array(im)
def compose(whl,gear=1,rpm=5000,mph=130,moving=True):
 frame=scene();frame[:10]=bitmap(A['roof'])[0]
 image=bitmap(A['dast'])[0];mask=bitmap(A['dasm'])[0];frame[10:122]=(frame[10:122]&mask)|image
 frame[122:]=bitmap(A['dash'])[0];frame[wy:wy+wh,wx:wx+ww]=bitmap(A[whl])[0]
 panel=bitmap(A['ins2'])[0].copy()
 for off,ptoff,index,count in [(0x128,0x12e,math.floor(mph/2.5),104),(0x1fe,0x204,rpm>>7,128)]:
  p=struct.unpack_from('<hh',sim,off);index=min(index,count-1);q=tuple(sim[ptoff+2*index:ptoff+2*index+2]);line(panel,p,q,38)
 if whl!='whl2':
  k='1' if whl=='whl1' else '3';msk=bitmap(A['inm'+k])[0];img=bitmap(A['ins'+k])[0]
  panel=(panel&msk)|img
 frame[iy:iy+ih,ix:ix+iw]=panel
 if moving:
  frame[gy:gy+gh,gx:gx+gw]=bitmap(A['gbox'])[0]
  x,y=knob_points[gear];x+=gx-5;y+=gy-4
  frame[y:y+8,x:x+10]=(frame[y:y+8,x:x+10]&knab)|knob
 return frame
for whl in ['whl1','whl2','whl3']:
 f=compose(whl);pim(f).save(OUT/('APERCU_'+whl+'.png'))
 if whl=='whl2':pim(compose(whl,moving=False)).convert('RGB').resize((960,720),Image.Resampling.NEAREST).save(OUT/'APERCU_COCKPIT.png')
states=Image.new('RGB',(640,480))
for gear in range(1,5):
 f=pim(compose('whl2',gear));states.paste(f.convert('RGB').resize((320,240),Image.Resampling.NEAREST),(((gear-1)%2)*320,((gear-1)//2)*240))
states.save(OUT/'APERCU_4_RAPPORTS.png')
maskpreview=Image.new('RGB',(640,224));maskpreview.paste(pim(bitmap(A['dast'])[0]).convert('RGB'),(0,0));maskpreview.paste(pim(bitmap(A['dasm'])[0]).convert('RGB'),(320,0));maskpreview.save(OUT/'MASQUE_DAST_DASM.png')
# Exhaustive geometry and ghost-restoration checks for all needle pairs/gear moves.
for whl in wheel_frames:
 for rpmi in range(57):
  f=compose(whl,1,rpmi*128,130);assert f.shape==(200,320)
for whl in wheel_frames:
 for spi in range(104):compose(whl,2,5000,spi*2.5)
for g1 in range(1,5):
 for g2 in range(1,5):
  restored=bitmap(A['gbox'])[0].copy();x,y=knob_points[g2];restored[y-4:y+4,x-5:x+5]=(restored[y-4:y+4,x-5:x+5]&knab)|knob
  expected=compose('whl2',g2)[gy:gy+gh,gx:gx+gw]
  assert np.array_equal(restored,expected)
  assert np.array_equal(compose('whl2',g2,moving=False)[gy:gy+gh,gx:gx+gw],resting_console)

audit={'version':'cockpit v0.3','canvas':[320,200],'display_preview':[960,720],'palette_source':'dstien/stressed resources/conf/defaults.conf native VGA','dast':{'xy':[0,10],'size':[320,112],'transparent_pixels':int((bitmap(A['dasm'])[0]==255).sum())},'gbox':{'xy':[gx,gy],'size':[gw,gh],'background_matches_dash_except_resting_knob':True,'native_resting_knob_in_dash':True,'view':'zenithal'},'knob':{'size':[10,8],'anchor':[5,4],'opaque_pixels':int(knobmask.sum()),'points_simd_1c_through_37':knob_points},'needles':needle_stats,'resources':[{'name':k,'size':list(bitmap(v)[0].shape[::-1]),'xy':list(bitmap(v)[1])} for k,v in A.items() if not k.startswith('!')],'engine_data_preserved':True,'shift_geometry_changed':False,'text_preserved':True,'in_game_test_performed':False,'validation':'Native container round trip, mask semantics, clean gbox background and idle restoration, all needle endpoints, all 16 gear transitions','source_car_sha256':hashlib.sha256((ROOT/'outputs/superbird_cockpit_v02/CARBIRD.RES').read_bytes()).hexdigest(),'sha256':{name:hashlib.sha256((OUT/name).read_bytes()).hexdigest() for name in ['STDABIRD.VSH','STDBBIRD.VSH','CARBIRD.RES']}}
(OUT/'AUDIT_COCKPIT_BIRD.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2))
readme='''PLYMOUTH SUPERBIRD NASCAR — COCKPIT v0.3
by Alain il Professore

FICHIERS À COPIER ENSEMBLE DANS STUNTS 1.1
STDABIRD.VSH : fond, montant gauche, arceau NASCAR, filet, rétroviseur, trois positions du volant, instruments et soufflet.
STDBBIRD.VSH : pommeau blanc vu du dessus et masque GNAB.
CARBIRD.RES : réglages du cockpit assortis à ces deux fichiers.
Sauvegarder les anciennes versions avant remplacement. Écarter les éventuels STDABIRD.PVS et STDBBIRD.PVS concurrents, qui seraient chargés en priorité par le jeu.
Le modèle STBIRD.3SH n'est pas inclus : il reste nécessaire pour une voiture complète.

CONCEPTION
Le soufflet noir et son cadre sont intégrés au fond dash. gbox reprend exactement le même fond de console, sans le pommeau fixe. Le moteur natif efface gnob après le changement de rapport : dash contient donc un pommeau de repos, remplacé par le fond propre gbox pendant l'animation. C'est l'unique différence entre ces deux fonds. Cela évite à la fois sa disparition au repos et un double pommeau pendant le mouvement. gnob/gnab fournissent le pommeau mobile, en vue strictement sommitale et sans tige de profil, avec quatre positions en H autour du soufflet.
Les espaces du filet et les vitrages utilisent le couple dast/dasm : couleur noire 0 dans dast aux endroits transparents, masque 255 pour laisser voir la piste, masque 0 pour dessiner les montants, barres et sangles. Aucun fond noir opaque n'est employé dans les ouvertures.
Le volant est porté de 84 à 140 pixels de largeur et son moyeu de x=90 à x=150. Deux mains gantées ivoire et trois poses distinctes sont intégrées. Les ouvertures de la jante et des branches laissent apparaître les cadrans. Les masques ins1/inm1 et ins3/inm3 couvrent maintenant toute la zone des instruments pour que les aiguilles restent derrière les mains et les branches. Le moyeu est plus bas dans la zone dashboard et la partie basse du volant sort du champ.
Les dessins ont été générés d'après les photos fournies puis convertis à la palette VGA native de Stressed et à 320×200. Le fichier APERCU_COCKPIT.png applique l'affichage 4:3 du jeu : ce n'est pas une capture d'une partie.

RÉGLAGES RES
Les courbes de couple, régimes, rapports, masse, adhérence, freinage, dimensions et textes du CARBIRD.RES joint sont conservés. La boîte et son pommeau conservent les réglages de la v0.2. Les points du volant et les extrémités des aiguilles ont été recalés pour le volant agrandi.
Compte-tours : échelle 0–8 000 tr/min. Vitesse : échelle 0–260 mph. Aiguilles rouges.

VÉRIFICATIONS
Conteneurs relus après écriture, palette native de 256 entrées, masques binaires, fond gbox strictement identique à la console avant l'ajout du pommeau de repos, 16 transitions de rapports et retour au repos sans traces dans le compositeur, balayages des aiguilles et trois états du volant. Les paramètres moteur et textes sont inchangés.
Pas de test dans Stunts natif dans cet environnement. À vérifier en jeu : miroirs, trois positions du volant, changements de rapports, aiguilles, ouvertures du filet, affichage en replay. L'aperçu est une composition technique, pas la preuve d'un test en jeu.

SOURCES TECHNIQUES
https://github.com/dstien/stressed — palette VGA native, resources/conf/defaults.conf.
https://github.com/CommonLoon102/restunts-bb11 — src/restunts/c/dashboard.c : composition des couches et coordonnées du pommeau.
https://wiki.stunts.hu/wiki/Car_parameters
https://wiki.stunts.hu/wiki/Car_files
Règles GNOB/GNAB et retour d'expérience de votre projet joints à la demande.
'''
(OUT/'LIRE_MOI.txt').write_text(readme,encoding='utf-8')
print(json.dumps(audit,ensure_ascii=False,indent=2))
