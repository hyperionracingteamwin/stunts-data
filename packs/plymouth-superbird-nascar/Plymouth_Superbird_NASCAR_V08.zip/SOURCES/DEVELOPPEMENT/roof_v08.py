from pathlib import Path
import ast, struct, json, copy, math, subprocess, re
import numpy as np
from PIL import Image, ImageDraw, ImageFont

R=Path('/workspace/scratch/4ce29ee9399e'); O=R/'outputs/superbird_final_v08'
P=O/'APERCUS';S=O/'SOURCES'
P.mkdir(parents=True,exist_ok=True);S.mkdir(exist_ok=True)
t=ast.parse((R/'work/bird_cockpit/build_final_v04.py').read_text())
exec(compile(ast.Module(body=[n for n in t.body if isinstance(n,ast.FunctionDef) and n.name in {'readres','writeres','readshape','writeshape'}],type_ignores=[]),'utils','exec'))
order, blocks = readres(R/'upload/STBIRD.3SH')
models={k:readshape(v) for k,v in blocks.items()}; before=copy.deepcopy(models)
PAL=np.array(json.loads((R/'work/bird_cockpit/palette.json').read_text()),np.uint8)
conf=(R/'work/stressed-src/resources/conf/defaults.conf').read_text()
matcols=list(map(int,re.findall(r'\d+',conf.split('[materials]')[1].split('colors=')[1].split('patterns=')[0])))
patterns=list(map(int,re.findall(r'\d+',conf.split('patterns=')[1].split('\n\n')[0])))

def close_cabin(m,scale):
    # Retain the user's belt-height closure rather than reverting to the older low floor.
    # Partition along the car's length and width so no distant part borrows the
    # mean depth of a nearer half and paints over the roof in the classic queue.
    v=m['v']; p=m['p']; assert len(p)==145
    roof=p[93]; assert roof['ids']==[170,163,160,169]
    roof['f']=1;roof['c1']=roof['c2']=0xffffffff
    template=copy.deepcopy(p[144]);result=[]
    def vertex(point):
        point=tuple(round(t/scale) for t in point)
        for i,old in enumerate(v):
            if tuple(old)==point:return i
        v.append(point);return len(v)-1
    stations=[-680,-380,80,280]
    for za,zb in zip(stations[:-1],stations[1:]):
        def section(z):
            u=(z+680)/960
            return 300+20*u,280-20*u
        wa,ya=section(za);wb,yb=section(zb)
        for interval in range(3):
            xa,xb=[-wa,-220,220,wa][interval:interval+2]
            xc,xd=[-wb,-220,220,wb][interval:interval+2]
            ids=[vertex(q) for q in [(xa,ya,za),(xc,yb,zb),(xd,yb,zb),(xb,ya,za)]]
            # Same upward orientation as roof. Double face prevents underside holes.
            q=copy.deepcopy(template);q.update(t=4,f=1,c1=0xffffffff,c2=0xffffffff,ids=ids,tag='cabin_closure')
            result.append(q)
    p[144]=result[0];p.extend(result[1:])
    assert len(v)<=255 and len(p)<=255
    return list(range(144,len(p)))

closures={}
for name,scale in [('car0',1),('car1',20)]:closures[name]=close_cabin(models[name],scale)
(S/'MODELE_NASCAR_V08.json').write_text(json.dumps(models,indent=2))
(O/'STBIRD.3SH').write_bytes(writeres(order,{k:writeshape(m) for k,m in models.items()}))
for k,b in readres(O/'STBIRD.3SH')[1].items():
    x=readshape(b);assert x['v']==[tuple(v) for v in models[k]['v']]
    assert len(x['p'])==len(models[k]['p']) and x['nj']==8

def queue(m,az,el):
    az=math.radians(az);el=math.radians(el)
    cam=np.array([math.sin(az)*math.cos(el),math.sin(el),math.cos(az)*math.cos(el)])
    right=np.cross([0,1,0],cam);right/=np.linalg.norm(right);up=np.cross(cam,right)
    v=np.array(m['v'],float);v[:,1]*=.8;v[:,2]*=-1
    if abs(v[:,2]).max()<100:v*=20
    v-=np.array([0,210,0]);pts=np.column_stack([v@right,v@up,4500-v@cam])
    b=bytes([len(v),len(m['p']),1,0])+b''.join(struct.pack('<hhh',*np.rint(q).astype(int)) for q in pts)
    # Pretransformed geometry deliberately tests projected backfaces and native
    # queue ordering. Directional cull masks are retained, with visibility=-1.
    b+=struct.pack('<'+'I'*len(m['p']),*[q['c1'] for q in m['p']])
    b+=struct.pack('<'+'I'*len(m['p']),*[q['c2'] for q in m['p']])
    for i,p in enumerate(m['p']):b+=bytes([p['t'],p['f'],i]+p['ids'])
    b+=b'\0\0\0';f=S/'queue_input.bin';f.write_bytes(b)
    r=subprocess.run([str(R/'work/bird_cockpit/bird_shape_queue'),str(f)],capture_output=True,text=True,check=True)
    data=json.loads(r.stdout);assert data['result']==0, data
    return data['queue']

def draw(m,q,highlight=False):
    im=Image.new('RGB',(640,480),(20,28,39));owners=Image.new('I',(640,480),-1)
    d=ImageDraw.Draw(im);od=ImageDraw.Draw(owners)
    for r in q:
        p=m['p'][r['id']];mat=p['m'][0];pts=[tuple(t) for t in r['points']]
        if mat==118:continue
        col=tuple(int(x) for x in PAL[matcols[mat]])
        if highlight and p.get('tag')=='cabin_closure':col=(170,45,45)
        if r['type']==0 and len(pts)>=3:
            if patterns[mat]:
                mask=Image.new('L',im.size);ImageDraw.Draw(mask).polygon(pts,fill=255)
                arr=np.array(mask);yy,xx=np.indices(arr.shape);arr[(xx+yy)%3!=0]=0
                im.paste(col,(0,0,*im.size),Image.fromarray(arr));continue
            d.polygon(pts,fill=col);od.polygon(pts,fill=r['id'])
        elif p['t']==2 and len(pts)==2:d.line(pts,fill=col,width=1)
        elif p['t']==12 and len(pts)>=3:
            # Queue supplies the native wheel bounding points; illustrative wheel.
            x=[t[0] for t in pts];y=[t[1] for t in pts];d.ellipse((min(x),min(y),max(x),max(y)),fill=(18,20,23))
    roof=next(r for r in q if r['id']==93)
    mask=Image.new('1',im.size);ImageDraw.Draw(mask).polygon([tuple(t) for t in roof['points']],fill=1)
    ids=np.array(owners);floor=np.isin(ids,list(range(144,len(m['p']))))
    return im,int((floor&np.array(mask)).sum()),int(np.array(mask).sum())

def run_checks():
    records=[];worst=(0,None)
    for name in ['car0','car1']:
        for el in [12,18,25,35,50,70]:
            for az in range(0,360,15):
                q=queue(models[name],az,el)
                _,bad,area=draw(models[name],q)
                if bad>worst[0]:worst=(bad,(name,az,el))
                records.append({'shape':name,'azimuth':az,'elevation':el,'roof_pixels_overdrawn_by_closure':bad,'roof_projection_pixels':area})
    return records,worst

def card(im,label):
    a=np.array(im);mask=np.any(a!=[20,28,39],axis=2);yy,xx=np.where(mask)
    crop=im.crop((int(xx.min())-6,int(yy.min())-6,int(xx.max())+7,int(yy.max())+7))
    scale=min(610/crop.width,350/crop.height)
    crop=crop.resize((round(crop.width*scale),round(crop.height*scale)),Image.Resampling.NEAREST)
    out=Image.new('RGB',(640,440),(20,28,39));out.paste(crop,((640-crop.width)//2,45+(370-crop.height)//2))
    d=ImageDraw.Draw(out);font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',16)
    d.text((15,12),label,font=font,fill='white');d.text((15,416),'Assemblage de la file C - hors jeu DOS',fill=(158,176,192))
    return out

if __name__=='__main__':
    # Contact sheet includes both low rear quarters and low front quarters.
    contact=Image.new('RGB',(1280,1320),(20,28,39))
    for i,(az,el) in enumerate([(35,18),(145,18),(215,18),(325,18),(60,50),(240,50)]):
        im,bad,area=draw(models['car0'],queue(models['car0'],az,el))
        contact.paste(card(im,f'Azimut {az} / elevation {el}'),(640*(i%2),440*(i//2)))
    contact.save(P/'CONTROLE_TOIT_HABITACLE.png')
    records,worst=run_checks()
    # Reproduce the reported overlap from the actual attached input, then show
    # the same view after correction. Keep the roof and all other panels intact.
    regression=[];worst_before=(0,None)
    for name in ['car0','car1']:
        for az in range(0,360,15):
            for el in [12,18,25,35,50,70]:
                _,bad,area=draw(before[name],queue(before[name],az,el))
                regression.append({'shape':name,'azimuth':az,'elevation':el,'roof_pixels_overdrawn':bad})
                if bad>worst_before[0]:worst_before=(bad,(name,az,el))
    name,az,el=worst_before[1];comp=Image.new('RGB',(1280,440),(20,28,39))
    for i,(m,label) in enumerate([(before[name],'AVANT - fichier joint'),(models[name],'APRES - V08')]):
        im,bad,area=draw(m,queue(m,az,el));comp.paste(card(im,f'{label} / recouvrement toit : {bad} px'),(i*640,0))
    comp.save(P/'TOIT_AVANT_APRES.png')
    (S/'AUDIT_TOIT_V08.json').write_text(json.dumps({'angles_tested':len(records),'worst':worst,'records':records,'baseline_worst':worst_before,'baseline_checks':regression,'mode':'native C queue with pretransformed vertices; PIL illustration, not DOS gameplay'},indent=2))
    print(json.dumps({'shapes':{k:[len(m['v']),len(m['p'])] for k,m in models.items()},'worst':worst,'angles':len(records)}))
