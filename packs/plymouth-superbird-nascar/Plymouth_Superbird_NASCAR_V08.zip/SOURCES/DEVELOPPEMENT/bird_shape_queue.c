#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "externs.h"
#include "shape3d.h"
#include "shape3d_internal.h"
#include "projection.h"
#undef memcpy
#undef printf

legacy_u8 atantable[257];
legacy_u8 vector_saved_z_low, vector_saved_z_high;
static legacy_u8 model[32000], records[32000];
extern legacy_u16 polyinfoptrnext;

int main(int argc, char **argv) {
    assert(argc == 2);
    FILE *file = fopen(argv[1], "rb"); assert(file);
    size_t size = fread(model, 1, sizeof(model), file); fclose(file); assert(size > 4);
    struct SHAPE3D shape; struct TRANSFORMEDSHAPE3D instance; struct RECTANGLE bounds;
    memset(&shape, 0, sizeof(shape)); memset(&instance, 0, sizeof(instance));
    unsigned nv = model[0], np = model[1]; assert(model[2] == 1);
    shape.shape3d_numverts = nv; shape.shape3d_numpaints = 1;
    shape.shape3d_vertex_bytes = model + 4;
    shape.shape3d_visibility_masks = model + 4 + 6 * nv;
    shape.shape3d_front_facing_masks = shape.shape3d_visibility_masks + 4 * np;
    shape.shape3d_primitives = shape.shape3d_front_facing_masks + 4 * np;
    instance.shapeptr = &shape; instance.rectptr = &bounds;
    instance.ts_flags = 10; instance.culling_distance = 16000;
    bounds = (struct RECTANGLE){32767, -32768, 32767, -32768};
    projection_focal_length_x = 700; projection_focal_length_y = 700;
    projection_center_x = 320; projection_center_y = 240;
    select_rect_rc.left = 0; select_rect_rc.right = 639;
    select_rect_rc.top = 0; select_rect_rc.bottom = 479;
    mat_temp = *mat_rot_zxy(0, 0, 0, MATRIX_ROTATION_ORDER_ZXY);
    polyinfoptr = records; polyinfo_reset();
    unsigned result = shape3d_transform_and_queue(&instance);
    printf("{\"result\":%u,\"queue\":[", result);
    polyinfo_index index = POLYINFO_LEGACY_PRIMITIVE_CAPACITY;
    for (unsigned j = 0; j < polyinfonumpolys; j++) {
        index = polygon_next_index[index]; assert(index >= 0);
        legacy_u8 *p = records + polygon_record_offsets[index];
        if(j) printf(",");
        printf("{\"id\":%u,\"depth\":%d,\"type\":%u,\"points\":[", p[2], LEGACY_READ_S16_LE(p), p[4]);
        for(unsigned k=0; k<p[3]; k++) {
            if(k) printf(",");
            printf("[%d,%d]", LEGACY_READ_S16_LE(p+6+4*k), LEGACY_READ_S16_LE(p+8+4*k));
        }
        printf("]}");
    }
    printf("]}\n");
    return 0;
}
