from pathlib import Path
import ast,struct,json,hashlib,shutil,zipfile
import numpy as np
from PIL import Image
R=Path('/workspace/scratch/4ce29ee9399e');O=R/'outputs/superbird_final_v08';S=O/'SOURCES';P=O/'APERCUS';OLD=R/'outputs/superbird_final_v07'
PAL=np.array(json.loads((R/'work/bird_cockpit/palette.json').read_text()),np.uint8)
t=ast.parse((R/'work/bird_cockpit/build_final_v04.py').read_text());exec(compile(ast.Module(body=[n for n in t.body if isinstance(n,ast.FunctionDef) and n.name in {'readres','readshape','bitmap','pim'}],type_ignores=[]),'utils','exec'))
native=['CARBIRD.RES','STBIRD.3SH','STDABIRD.VSH','STDBBIRD.VSH']
_,A=readres(O/'STDABIRD.VSH');_,C=readres(O/'CARBIRD.RES');_,OC=readres(OLD/'CARBIRD.RES')
assert (O/'CARBIRD.RES').read_bytes()==(OLD/'CARBIRD.RES').read_bytes()
assert (O/'STDBBIRD.VSH').read_bytes()==(OLD/'STDBBIRD.VSH').read_bytes()
assert C['edes']==OC['edes'] and b'by Alain il Professore]' in C['edes']
assert (O/'STDABIRD.VSH').stat().st_size==97198
_,baseline=readres(R/'upload/STBIRD.3SH');_,current=readres(O/'STBIRD.3SH')
for name in ['car0','car1']:
    old=readshape(baseline[name]);new=readshape(current[name])
    assert new['v'][:len(old['v'])]==old['v']
    assert new['p'][:144]==old['p'][:144]
    assert len(new['v'])==241 and len(new['p'])==153
    for p in new['p'][144:]:
        assert p['f']==1 and p['m']==[39]*8 and p['c1']==p['c2']==0xffffffff
        pts=np.array([new['v'][i] for i in p['ids']],float);normal=np.cross(pts[1]-pts[0],pts[2]-pts[0])
        assert np.linalg.norm(normal)>0 and np.max(np.abs((pts-pts[0])@normal))<.01
for name in ['car2','exp0','exp1','exp2','exp3']:assert readshape(current[name])==readshape(baseline[name])
roof_audit=json.loads((S/'AUDIT_TOIT_V08.json').read_text());assert roof_audit['worst'][0]==0 and roof_audit['baseline_worst'][0]>0
bmpdir=S/'BITMAPS';bmpdir.mkdir(exist_ok=True)
for key,b in A.items():pim(bitmap(b)[0]).save(bmpdir/(key+'.png'))
shutil.copy2(R/'work/bird_cockpit/palette.json',S/'PALETTE.json')
shutil.copyfile(R/'upload/STBIRD.3SH',S/'STBIRD_AVANT_CORRECTION.3SH')
(S/'queue_input.bin').unlink(missing_ok=True)
dev=S/'DEVELOPPEMENT';dev.mkdir(exist_ok=True)
for name in ['build_final_v08.py','roof_v08.py','bird_shape_queue.c','finalize_v08.py']:
    shutil.copyfile(R/'work/bird_cockpit'/name,dev/name)
(dev/'CONTEXTE.txt').write_text('''Scripts de fabrication et de vérification archivés avec leurs chemins du workspace d'origine.
Ils documentent les opérations appliquées ; ils ne constituent pas un installateur autonome.
Utilitaires de sérialisation : build_final_v04.py. Fonctions de composition : build_final_v06.py.
Police native : build_cockpit_v03.py. Ces trois fichiers de dépendances sont joints ici.
Le test C se compile avec shape3d.c, full_data.c, math.c, legacy.c et les en-têtes du dépôt
https://github.com/CommonLoon102/restunts-bb11 (copie examinée durant ce projet).
Les vertices sont prétransformés avant l'appel, puis l'ordre et les points projetés de la file
C sont illustrés avec PIL. Les roues et les motifs sont illustratifs ; aucune capture DOS.
L'audit porte sur le recouvrement du toit par la fermeture, pas sur tout le rendu de la voiture.
Les bitmaps indexés et le modèle JSON sont les sources éditables directement associées à V08.
''',encoding='utf-8')
for name in ['build_final_v04.py','build_final_v06.py','build_cockpit_v03.py']:shutil.copyfile(R/'work/bird_cockpit'/name,dev/name)
audit={'version':'V08','author':'by Alain il Professore','base_3sh':'STBIRD.3SH joint par utilisateur',
       'source_3sh_sha256':hashlib.sha256((R/'upload/STBIRD.3SH').read_bytes()).hexdigest(),
       'unchanged_files':['CARBIRD.RES','STDBBIRD.VSH'],
       'unchanged_source_geometry':'all 233 existing vertices and first 144 primitives of car0/car1; car2 and exp0-exp3',
       'closure_panels':9,'detailed_models':{'vertices':241,'primitives':153,'paintjobs':8},
       'native_queue_views':roof_audit['angles_tested'],'closure_overdraw_roof_pixels_after':0,
       'baseline_worst':roof_audit['baseline_worst'],'full_DOS_game_test':False,
       'visual_review':{'global_4_3':True,'three_poses':True,'gauge_detail':True,'roof_views_before_after':True},
       'sha256':{f:hashlib.sha256((O/f).read_bytes()).hexdigest() for f in native}}
(S/'AUDIT_V08.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2),encoding='utf-8')
(O/'LIRE_MOI.txt').write_text('''PLYMOUTH SUPERBIRD NASCAR — V08
by Alain il Professore

INSTALLATION
Copier ensemble CARBIRD.RES, STBIRD.3SH, STDABIRD.VSH et STDBBIRD.VSH à la racine
de Stunts 1.1 VGA. Sauvegarder la version précédente et écarter les STBIRD.P3S,
STDABIRD.PVS et STDBBIRD.PVS concurrents éventuels.

COMPTEURS
Compte-tours : 0, 1, 2, 3, 4, 5, 6, 7, 8 dans le sens horaire, unité RPM x1000.
Vitesse : chiffres principaux 0, 100, 200 en vrais glyphes natifs 3x5, en MPH.
Les graduations vont de 0 à 260 MPH. Chiffres, graduations et aiguilles suivent
la même progression angulaire. Les tables SIMD des aiguilles sont conservées.
Les fonds DASH, WHL et INS sont mis à jour ensemble, sans modifier les pixels
du volant et des gants. Les trois poses sont contrôlées.

HABITACLE ET TOIT
Base : STBIRD.3SH joint dans votre dernière demande. Le toit n°94, déjà double
face avec culling ouvert, est conservé ainsi que les numéros blancs.
Le panneau intérieur n°145 est réparti en neuf panneaux raccordés, alignés sur
l'emprise du toit. Cela corrige le conflit de profondeur moyenne qui permettait
à la fermeture de passer devant le toit selon l'angle. Pas de toit superposé
ni de Z-bias ajouté. Correction appliquée à car0 et car1 : 241 sommets et
153 primitives chacun. Les sommets d'origine et les 144 premières primitives
sont conservés. Les formes car2 et exp0-exp3 restent celles du fichier joint.
Les huit peintures de ce fichier sont conservées.

VERIFICATION ET MEMOIRE
STDA : 97 198 octets bruts, 60 613 après conversion RLE. Chargeur C vérifié
pixel par pixel dans le budget de 200 000 octets. STDB : 2 102 / 1 388 octets.
File de tri C testée sur 288 vues (azimuts tous les 15 degrés, élévations
12, 18, 25, 35, 50, 70 degrés, sur les deux modèles détaillés) : aucun pixel
du toit recouvert par la nouvelle fermeture. Le cas précédent est reproduit
dans TOIT_AVANT_APRES.png. Ce contrôle ciblé n'est pas un essai du jeu DOS.
Les aperçus sont des assemblages techniques des ressources.

CONSERVATION
CARBIRD.RES et STDBBIRD.VSH sont identiques à V07. Signature, spécifications,
moteur, couple, boîte, levier, absence du rétro et roof du dashboard conservés.
La courbe Excel reste une courbe de simulation documentée, sans mesure au banc.
Le guide d'astuces est complété avec ce diagnostic de tri des polygones.
Base 3D historique : Superbird.zip / STM1PL.3SH, voiture créditée By Alan Rotoi.
''',encoding='utf-8')
zpath=O/'SUPERBIRD_NASCAR_FINAL_V08.zip'
with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED) as z:
    for f in sorted(O.rglob('*')):
        if f.is_file() and f!=zpath:z.write(f,f.relative_to(O))
with zipfile.ZipFile(zpath) as z:
    assert z.testzip() is None
    for f in native:assert hashlib.sha256(z.read(f)).hexdigest()==audit['sha256'][f]
print(json.dumps({'archive':str(zpath),'bytes':zpath.stat().st_size,'native_bytes':{f:(O/f).stat().st_size for f in native},'checks':'passed'},ensure_ascii=False))
