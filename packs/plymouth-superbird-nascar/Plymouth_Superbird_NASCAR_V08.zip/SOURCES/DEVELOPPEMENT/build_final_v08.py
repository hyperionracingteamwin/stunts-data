"""V08: native gauge typography, matching pose backgrounds; 3D from supplied model."""
from pathlib import Path
import ast,struct,json,math,hashlib,shutil,subprocess,re
import numpy as np
from PIL import Image,ImageDraw,ImageFont
R=Path('/workspace/scratch/4ce29ee9399e');OLD=R/'outputs/superbird_final_v07';O=R/'outputs/superbird_final_v08'
P=O/'APERCUS';S=O/'SOURCES';P.mkdir(parents=True,exist_ok=True);S.mkdir(exist_ok=True)
PAL=np.array(json.loads((R/'work/bird_cockpit/palette.json').read_text()),np.uint8)
for file,names in [('build_final_v04.py',{'readres','writeres','bitmap','bmp','pim','quant'}),('build_cockpit_v03.py',{'glyphs','line','line_coords'})]:
    tree=ast.parse((R/'work/bird_cockpit'/file).read_text());exec(compile(ast.Module(body=[x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name in names],type_ignores=[]),'utils','exec'))
FONT=glyphs();na,A=readres(OLD/'STDABIRD.VSH');_,B=readres(OLD/'STDBBIRD.VSH');_,C=readres(OLD/'CARBIRD.RES');sim=bytearray(C['simd'])
dy=118;ix,iy,iw,ih=124,142,64,26;wx,wy,ww,wh=46,133,208,67
base=np.zeros((200,320),np.uint8);base[dy:]=bitmap(A['dash'])[0]
oldbase=base.copy();tach=(139,157);speed=(176,155)

def text(a,word,cx,cy,color=17):
    x=round(cx-(4*len(word)-1)/2);y=round(cy-2)
    for ch in word:
        mask=FONT[ch].astype(bool);a[y:y+5,x:x+3][mask]=color;x+=4

micro={'x':['101','010','101'],'1':['010','110','010'],'0':['111','101','111']}
def unit(a,word,cx,y):
    x=round(cx-(4*len(word)-1)/2)
    for ch in word:
        mask=np.array([[int(k) for k in row] for row in micro[ch]],bool)
        a[y:y+3,x:x+3][mask]=19;x+=4

yy,xx=np.indices(base.shape)
for center,r in [(tach,18),(speed,13)]:
    dist=(xx-center[0])**2+(yy-center[1])**2
    base[dist<=r*r]=31

labels=[]
for j in range(33):
    t=math.radians(140+260*j/32);r=16 if j%4==0 else 17;c=38 if j>=28 else 19
    line(base,(round(tach[0]+r*math.cos(t)),round(tach[1]+r*math.sin(t))),
         (round(tach[0]+18*math.cos(t)),round(tach[1]+18*math.sin(t))),c)
for value in range(9):
    t=math.radians(140+260*value/8);cx=tach[0]+13*math.cos(t);cy=tach[1]+13*math.sin(t)
    text(base,str(value),cx,cy);labels.append({'value':value,'rpm':1000*value,'angle':140+260*value/8,'center':[cx,cy]})
text(base,'RPM',tach[0],tach[1]+6,19);unit(base,'x1000',tach[0],tach[1]+12)
for value in range(0,261,10):
    t=math.radians(140+260*value/260);r=10 if value%50==0 else 12
    line(base,(round(speed[0]+r*math.cos(t)),round(speed[1]+r*math.sin(t))),
         (round(speed[0]+13*math.cos(t)),round(speed[1]+13*math.sin(t))),19)
# Full 3x5 numeric glyphs replace the ambiguous 3x3 font on the speedometer.
speed_labels=[(0,168,161),(100,172,148),(200,183,153)]
for value,cx,cy in speed_labels:text(base,str(value),cx,cy)
text(base,'MPH',speed[0],speed[1]+8,19)

A['dash']=bmp(base[dy:],(0,dy))
wheel_masks={};wheel_frames={}
changed=(base!=oldbase)
for key in ['whl1','whl2','whl3']:
    indexed=np.array(Image.open(R/'outputs/superbird_cockpit_v03/sources_indexees'/(key+'_GANTS_DETOURES.png')))
    part=indexed[:,14:222];rgba=np.dstack([PAL[part],np.where(part!=255,255,0).astype(np.uint8)])
    mask=np.array(Image.fromarray(rgba).resize((208,70),Image.Resampling.LANCZOS).crop((0,0,208,67)))[:,:,3]>=150
    frame,xy,anc=bitmap(A[key]);foreground=frame[mask].copy()
    repaint=changed[wy:,wx:wx+ww]&~mask;frame[repaint]=base[wy:,wx:wx+ww][repaint]
    assert np.array_equal(frame[mask],foreground)
    A[key]=bmp(frame,xy,anc);wheel_frames[key]=frame
    wheel_masks[key]=np.zeros((200,320),bool);wheel_masks[key][wy:,wx:wx+ww]=mask
neutral=base.copy();neutral[wy:,wx:wx+ww]=wheel_frames['whl2']
A['ins2']=bmp(neutral[iy:iy+ih,ix:ix+iw],(ix,iy))
for num,key in [('1','whl1'),('3','whl3')]:
    side=base.copy();side[wy:,wx:wx+ww]=wheel_frames[key]
    old,(x,y),anc=bitmap(A['ins'+num]);mask=bitmap(A['inm'+num])[0];h,w=old.shape
    piece=side[iy+y:iy+y+h,ix+x:ix+x+w]
    A['ins'+num]=bmp(np.where(mask==0,piece,0).astype(np.uint8),(x,y),anc)
(O/'STDABIRD.VSH').write_bytes(writeres(na,A))
for file in ['CARBIRD.RES','STDBBIRD.VSH','ASTUCES_CONSTRUCTION_STUNTS_MAJ.md']:shutil.copy2(OLD/file,O/file)
for file in ['Plymouth_Superbird_NASCAR_Torque.xlsx','TORQUE_103.csv','ASTUCES_CONSTRUCTION_STUNTS_MAJ.md']:shutil.copy2(OLD/'SOURCES'/file,S/file)
knob=bitmap(B['gnob'])[0];knab=bitmap(B['gnab'])[0]
tree=ast.parse((R/'work/bird_cockpit/build_final_v06.py').read_text());fn=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='compose');fn.name='compose_under_roof';exec(compile(ast.Module(body=[fn],type_ignores=[]),'compose','exec'))
def compose(*args,**kwargs):
    frame=compose_under_roof(*args,**kwargs);frame[:10]=bitmap(A['roof'])[0];return frame

for wheel in ['whl1','whl2','whl3']:
    for rpmi in range(128):compose(wheel,rpmi=rpmi)
    for speedi in range(104):compose(wheel,speedi=speedi)
    frame=compose(wheel);pim(frame).convert('RGB').resize((960,720),Image.Resampling.NEAREST).save(P/(wheel+'.png'))
    if wheel=='whl2':
        pim(frame).save(P/'COCKPIT_NATIF.png');pim(frame).convert('RGB').resize((960,720),Image.Resampling.NEAREST).save(P/'COCKPIT_GLOBAL_4_3.png')
        pim(compose(wheel,True,1)).convert('RGB').resize((960,720),Image.Resampling.NEAREST).save(P/'COCKPIT_CHANGEMENT.png')
contact=Image.new('RGB',(960,260),(15,20,28));d=ImageDraw.Draw(contact)
for i,(key,label) in enumerate([('whl1','GAUCHE'),('whl2','CENTRE'),('whl3','DROITE')]):
    contact.paste(pim(compose(key)).convert('RGB').resize((320,240),Image.Resampling.NEAREST),(i*320,20));d.text((320*i+8,4),label,fill='white')
contact.save(P/'TROIS_POSITIONS_4_3.png')
pim(base[132:179,115:197]).convert('RGB').resize((820,470),Image.Resampling.NEAREST).save(P/'GRADUATIONS_DETAIL.png')
frames=[];font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',13)
for rpm,mph in [(0,0),(1000,25),(2000,50),(3000,75),(4000,100),(5000,125),(6000,150),(7000,200),(8000,250)]:
    # Table indices use 128 RPM and 2.5 mph increments, retained from V07.
    frame=compose(rpmi=min(round(rpm/128),127),speedi=min(round(mph/2.5),103))
    im=Image.new('RGB',(640,510),(15,20,28));im.paste(pim(frame).convert('RGB').resize((640,480),Image.Resampling.NEAREST),(0,30));ImageDraw.Draw(im).text((12,7),f'{rpm} RPM / {mph} MPH - assemblage des ressources',font=font,fill='white');frames.append(im)
frames[0].save(P/'CONTROLE_COMPTEURS_V08.gif',save_all=True,append_images=frames[1:],duration=850,loop=0,disposal=2)
tests={}
for file in ['STDABIRD.VSH','STDBBIRD.VSH']:
    r=subprocess.run([str(R/'work/bird_cockpit/test_bird_native_loader'),str(O/file)],capture_output=True,text=True,check=True)
    match=re.search(r'PASS: (\d+) raw bytes, (\d+) bitmaps, (\d+) parsed bytes',r.stdout);assert match,r.stdout
    tests[file]=dict(zip(['raw_bytes','bitmaps','parsed_bytes'],map(int,match.groups())))
audit={'version':'V08','author':'by Alain il Professore','tach_labels':labels,'tach_unit':'RPM x1000','speed_labels':[v for v,_,_ in speed_labels],
       'speed_scale_mph':[0,260],'needle_tables_unchanged':True,'foreground_wheel_gloves_preserved':True,
       'engine_and_edes_unchanged':True,'mirror_removed_and_roof_preserved':True,'native_C_loader':tests,'full_DOS_game_test':False}
(S/'AUDIT_COCKPIT_V08.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2))
print(json.dumps(audit,ensure_ascii=False))
