"""V06 proportions: full-scale pillar, dashboard mirror, gauges in wheel opening."""
from pathlib import Path
import ast,struct,json,math,hashlib,zipfile,re,copy,shutil
import numpy as np
from PIL import Image,ImageDraw,ImageFont
from scipy import ndimage
R=Path('/workspace/scratch/4ce29ee9399e');OLD=R/'outputs/superbird_final_v05'
O=R/'outputs/superbird_final_v06';O.mkdir(parents=True,exist_ok=True)
P=O/'APERCUS';P.mkdir(exist_ok=True);S=O/'SOURCES';S.mkdir(exist_ok=True)
PAL=np.array(json.loads((R/'work/bird_cockpit/palette.json').read_text()),np.uint8)
tree=ast.parse((R/'work/bird_cockpit/build_final_v04.py').read_text())
defs=[x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name in {'readres','writeres','bitmap','bmp','pim','quant','font'}]
exec(compile(ast.Module(body=defs,type_ignores=[]),'native_utils','exec'))
tree=ast.parse((R/'work/bird_cockpit/build_cockpit_v03.py').read_text())
defs=[x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name in {'glyphs','text','line','line_coords'}]
exec(compile(ast.Module(body=defs,type_ignores=[]),'instrument_utils','exec'))
FONT=glyphs()
na,A=readres(OLD/'STDABIRD.VSH');nb,B=readres(OLD/'STDBBIRD.VSH');nc,C=readres(OLD/'CARBIRD.RES');oldsim=C['simd'];sim=bytearray(oldsim)
painted=R/'generated_images/exec-0c435891-41d7-45ca-9e21-151f081006dd.png'
original=Image.open(R/'generated_images/exec-31487771-2513-403c-89bc-6922f132a7b3.png').convert('RGBA').resize((320,200),Image.Resampling.LANCZOS)
im=Image.open(painted).convert('RGBA').resize((320,200),Image.Resampling.LANCZOS)
base=quant(im);raw=quant(original)
# Restore the actual original scale, not a squeezed all-in-one left overlay.
alpha=np.array(original)[:,:,3]>=150
rgb=np.array(original)[:,:,:3].astype(np.int16)
# Trim the orphaned horizontal roof-bar stub to the blue tube's contour.
# This does not change the scale of the pillar, padding or net below it.
for row in range(24):
 valid=np.where((rgb[row,35:72,2]>rgb[row,35:72,0]+22)&(rgb[row,35:72,2]>rgb[row,35:72,1]+15)&(rgb[row,35:72,2]>60))[0]
 if len(valid):alpha[row,int(valid.max())+35+4:72]=False
upper=np.where(alpha[1:118,:72],raw[1:118,:72],0).astype(np.uint8)
A['dast']=bmp(upper,(0,1));A['dasm']=bmp(np.where(alpha[1:118,:72],0,255).astype(np.uint8),(0,1))
# The native DASH now starts four pixels higher. Mirror stays fully in DASH,
# so there is no full-width alpha bitmap or new memory area for it.
dy=118
# Remove the earlier painted mirror's mount from this strip before relocating
# the complete mirror. Use the original clean coaming, avoiding a second foot.
base[dy:139,230:320]=raw[dy:139,230:320]
# Reinstall the original mirror at normal width, on a short dashboard support.
mirror=original.crop((202,14,267,32)).resize((68,18),Image.Resampling.LANCZOS)
mq=quant(mirror);ma=np.array(mirror)[:,:,3]>=140
# The mirror crop contains the rounded mirror only; cut the old top stalk.
ma[:1,:]=False
mx,my=241,119
base[my:my+18,mx:mx+68][ma]=mq[ma]
for x,c in [(304,28),(305,31),(306,19),(307,31)]:line(base,(x,134),(x,140),c)
line(base,(302,140),(310,140),19);line(base,(302,141),(310,141),31)

# Circular bezels retain the painted metal; the faces are calibrated separately.
tach=(139,157);speed=(176,155)
def face(center,oldcenter,r,inside):
 cx,cy=center;ox,oy=oldcenter
 crop=raw[oy-r:oy+r+1,ox-r:ox+r+1].copy();Y,X=np.indices(crop.shape);disk=(X-r)**2+(Y-r)**2<=r*r
 target=base[cy-r:cy+r+1,cx-r:cx+r+1];target[disk]=crop[disk]
 yy,xx=np.indices(base.shape);dist=(xx-cx)**2+(yy-cy)**2
 base[dist<=inside*inside]=31
 # A very subtle inner-face shadow; no fabricated second ring or outside text.
 base[(dist>=(inside-1)**2)&(dist<=inside*inside)]=30
face(tach,(148,150),22,17)
face(speed,(190,151),16,12)
def stroke(p,q,color):line(base,p,q,color)
for j in range(33):
 theta=math.radians(140+260*j/32);c=38 if j>=26 else 19
 r0=14 if j%4==0 else 16
 stroke((round(tach[0]+r0*math.cos(theta)),round(tach[1]+r0*math.sin(theta))),
        (round(tach[0]+17*math.cos(theta)),round(tach[1]+17*math.sin(theta))),c)
for value in [0,2,4,6,8]:
 theta=math.radians(140+260*value/8)
 text(base,str(value),tach[0]+12*math.cos(theta),round(tach[1]+12*math.sin(theta))-2,17)
text(base,'RPM',tach[0],tach[1]+3,19)
micro={'0':['111','101','111'],'1':['010','110','010'],'2':['110','010','011'],'5':['111','100','011'],'M':['101','111','101'],'P':['110','110','100'],'H':['101','111','101'],'X':['101','010','101']}
def tiny(word,cx,y,color=19):
 width=sum(len(micro[c][0])+1 for c in word)-1;x=round(cx-width/2)
 for ch in word:
  a=np.array([[int(c) for c in row] for row in micro[ch]],bool);h,w=a.shape;sl=base[y:y+h,x:x+w];sl[a]=color;x+=w+1
for j in range(14):
 theta=math.radians(140+260*j/13)
 stroke((round(speed[0]+10*math.cos(theta)),round(speed[1]+10*math.sin(theta))),
        (round(speed[0]+12*math.cos(theta)),round(speed[1]+12*math.sin(theta))),19)
tiny('0',speed[0]-8,speed[1]+2,17)
tiny('100',speed[0]-3,speed[1]-7,17)
tiny('200',speed[0]+6,speed[1]-3,17)
text(base,'MPH',speed[0],speed[1]+6,19)
for cx in [223,244,266,287]:line(base,(cx,151),(cx-3,146),38)
# No shifter at rest. Preserve the clean floor (and all surrounding panels).
old_dash=bitmap(A['dash'])[0];base[168:198,270:310]=old_dash[46:76,270:310]
A['dash']=bmp(base[dy:],(0,dy))

# Keep the big wheel at exactly its previous horizontal size and painted pose.
# Lower it 3 pixels; clip only the forearm tips already exiting the screen.
wx,wy,ww,wh=46,133,208,67;wheel_masks={};wheel_frames={}
for key in ['whl1','whl2','whl3']:
 old=np.array(Image.open(R/'outputs/superbird_cockpit_v03/sources_indexees'/(key+'_GANTS_DETOURES.png')))
 part=old[:,14:222];rgba=np.dstack([PAL[part],np.where(part!=255,255,0).astype(np.uint8)])
 new=Image.fromarray(rgba).resize((208,70),Image.Resampling.LANCZOS).crop((0,0,208,67))
 mask=np.array(new)[:,:,3]>=150;art=quant(new)
 wheel_masks[key]=np.zeros((200,320),bool);wheel_masks[key][wy:,wx:wx+ww]=mask
 frame=base[wy:,wx:wx+ww].copy();frame[mask]=art[mask];wheel_frames[key]=frame
 A[key]=bmp(frame,(wx,wy),(104,45))

# Instruments: common native panel, cropped pose corrections and recalibrated
# paths, avoiding needle paint over the neutral wheel (no native INM2 exists).
ix,iy,iw,ih=124,142,64,26
neutral=base.copy();neutral[wy:,wx:wx+ww]=wheel_frames['whl2']
A['ins2']=bmp(neutral[iy:iy+ih,ix:ix+iw],(ix,iy))
for num,key in [('1','whl1'),('3','whl3')]:
 side=base.copy();side[wy:,wx:wx+ww]=wheel_frames[key]
 cover=(wheel_masks[key]|wheel_masks['whl2'])[iy:iy+ih,ix:ix+iw]
 yy,xx=np.where(cover);left=int(xx.min())//4*4;right=min(iw,(int(xx.max())//4+1)*4);top=int(yy.min());bottom=int(yy.max())+1
 image=np.where(cover,side[iy:iy+ih,ix:ix+iw],0).astype(np.uint8);mask=np.where(cover,0,255).astype(np.uint8)
 A['ins'+num]=bmp(image[top:bottom,left:right],(left,top));A['inm'+num]=bmp(mask[top:bottom,left:right],(left,top))
needle_audit=[]
for name,center,r,off,countoff,ptoff,count,maxvalue in [('speed',speed,10,0x128,0x12c,0x12e,104,260),('rpm',tach,15,0x1fe,0x202,0x204,128,8000)]:
 struct.pack_into('<hh',sim,off,center[0]-ix,center[1]-iy);struct.pack_into('<h',sim,countoff,count)
 lengths=[]
 for j in range(count):
  value=j*2.5 if name=='speed' else j*128;theta=math.radians(140+260*min(value/maxvalue,1));tip=(round(center[0]+r*math.cos(theta)),round(center[1]+r*math.sin(theta)))
  path=line_coords(center,tip);visible=[]
  for x,y in path:
   if wheel_masks['whl2'][y,x]:break
   visible.append((x,y))
  assert len(visible)>=5,(name,j,visible)
  x,y=visible[-1];assert 0<=x-ix<iw and 0<=y-iy<ih
  sim[ptoff+2*j:ptoff+2*j+2]=bytes([x-ix,y-iy]);lengths.append(len(visible))
 needle_audit.append({'name':name,'center':center,'minimum_needle_length':min(lengths),'points':count})
# Slightly larger knob: 12x10 instead of 10x8, same physical centre positions.
knob,_,_=bitmap(B['gnob']);mask=bitmap(B['gnab'])[0]
im=Image.fromarray(np.dstack([PAL[knob],np.where(mask==0,255,0).astype(np.uint8)])).resize((12,10),Image.Resampling.LANCZOS)
knob=quant(im);keep=np.array(im)[:,:,3]>=150;knob[~keep]=0;knab=np.where(keep,0,255).astype(np.uint8)
B['gnob']=bmp(knob,(0,0),(6,5));B['gnab']=bmp(knab,(0,0),(6,5))
C['simd']=bytes(sim)
for name,ids,blocks in [('STDABIRD.VSH',na,A),('STDBBIRD.VSH',nb,B),('CARBIRD.RES',nc,C)]:
 (O/name).write_bytes(writeres(ids,blocks))
 for k,v in blocks.items():assert readres(O/name)[1][k][:len(v)]==v
shutil.copy2(OLD/'STBIRD.3SH',O/'STBIRD.3SH')
assert C['edes']==readres(OLD/'CARBIRD.RES')[1]['edes']
assert sim[:0xea]==oldsim[:0xea]
assert (O/'STDABIRD.VSH').stat().st_size<100000
assert (O/'STDABIRD.VSH').stat().st_size<=(OLD/'STDABIRD.VSH').stat().st_size
assert set(np.unique(knab))<={0,255} and np.all(knob[knab==255]==0)
assert ndimage.label(knab==0)[1]==1

# A full 4:3 view is the primary QA object, never isolated asset thumbnails.
def compose(wheel='whl2',moving=False,gear=0,rpmi=39,speedi=52,road='straight'):
 im=Image.new('L',(320,200),130);dr=ImageDraw.Draw(im);dr.rectangle((0,78,319,dy),fill=99)
 if road=='straight':dr.polygon([(147,78),(173,78),(292,dy),(28,dy)],fill=25);dr.line([(160,78),(160,dy)],fill=15)
 else:dr.polygon([(147,78),(168,78),(320,115),(320,dy),(245,dy)],fill=25);dr.line([(158,78),(290,dy)],fill=15)
 frame=np.array(im);frame[dy:]=bitmap(A['dash'])[0]
 art,(dx,yy),_=bitmap(A['dast']);msk=bitmap(A['dasm'])[0];h,w=art.shape;frame[yy:yy+h,dx:dx+w]=(frame[yy:yy+h,dx:dx+w]&msk)|art
 art,(x,y),_=bitmap(A[wheel]);h,w=art.shape;frame[y:y+h,x:x+w]=art
 panel=bitmap(A['ins2'])[0]
 for off,pt,j in [(0x128,0x12e,speedi),(0x1fe,0x204,rpmi)]:line(panel,struct.unpack_from('<hh',sim,off),sim[pt+2*j:pt+2*j+2],38)
 if wheel!='whl2':
  k=wheel[-1];art,(x,y),_=bitmap(A['ins'+k]);msk=bitmap(A['inm'+k])[0];h,w=art.shape;panel[y:y+h,x:x+w]=(panel[y:y+h,x:x+w]&msk)|art
 frame[iy:iy+ih,ix:ix+iw]=panel
 if moving:
  art,(gx,gy),_=bitmap(A['gbox']);h,w=art.shape;frame[gy:gy+h,gx:gx+w]=art
  x,y=struct.unpack_from('<hh',sim,0x1c+4*gear);x+=gx-6;y+=gy-5;h,w=knob.shape
  frame[y:y+h,x:x+w]=(frame[y:y+h,x:x+w]&knab)|knob
 return frame
occlusion={}
for wheel in ['whl1','whl2','whl3']:
 yy,xx=np.indices((200,320));occlusion[wheel]={name:round(float(wheel_masks[wheel][(xx-cx)**2+(yy-cy)**2<=r*r].mean()),3) for name,(cx,cy),r in [('tach',tach,16),('speed',speed,10)]}
 for rpmi in range(128):compose(wheel,rpmi=rpmi)
 for speedi in range(104):compose(wheel,speedi=speedi)
 pim(compose(wheel)).convert('RGB').resize((960,720),Image.Resampling.NEAREST).save(P/(wheel+'.png'))
 if wheel=='whl2':
  pim(compose(wheel)).save(P/'COCKPIT_NATIF.png');pim(compose(wheel)).convert('RGB').resize((960,720),Image.Resampling.NEAREST).save(P/'COCKPIT_GLOBAL_4_3.png')
  pim(compose(wheel,True,1)).convert('RGB').resize((960,720),Image.Resampling.NEAREST).save(P/'COCKPIT_CHANGEMENT.png')
contact=Image.new('RGB',(960,260),(15,20,28));dr=ImageDraw.Draw(contact)
for i,(wheel,label) in enumerate([('whl1','GAUCHE'),('whl2','CENTRE'),('whl3','DROITE')]):
 contact.paste(pim(compose(wheel)).convert('RGB').resize((320,240),Image.Resampling.NEAREST),(320*i,20));dr.text((i*320+8,4),label,fill='white')
contact.save(P/'TROIS_POSITIONS_4_3.png')
for k in ['dash','dast','dasm','ins2','gbox']:
 im=pim(bitmap(A[k])[0]);im.save(S/(k+'.png'),**({'transparency':255} if k=='dasm' else {}))
for k in ['gnob','gnab']:pim(bitmap(B[k])[0]).save(S/(k+'.png'),transparency=255)
audit={'version':'V06','author':'by Alain il Professore','in_game_test_performed':False,'stda_bytes':(O/'STDABIRD.VSH').stat().st_size,'pillar_scale':'original 320x200, not squeezed','mirror':{'position':[mx,my],'size':[68,18],'placement':'right dashboard coaming, inside DASH'},'wheel':{'rim_width':140,'shift_down_pixels':3,'two_gloves':True,'three_poses':True},'primary_gauges':{'tach_center':tach,'speed_center':speed,'tach_digit_radius':12,'tach_digits':'0 2 4 6 8, centered on radial guides'},'knob':{'before':[10,8],'after':[12,10],'centres_preserved':True},'occlusion_face_area_fraction':occlusion,'needle_paths':needle_audit,'engine_and_edes_preserved':True,'sha256':{f:hashlib.sha256((O/f).read_bytes()).hexdigest() for f in ['CARBIRD.RES','STBIRD.3SH','STDABIRD.VSH','STDBBIRD.VSH']}}
(S/'AUDIT_V06.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2))
print(json.dumps(audit,ensure_ascii=False,indent=2))
