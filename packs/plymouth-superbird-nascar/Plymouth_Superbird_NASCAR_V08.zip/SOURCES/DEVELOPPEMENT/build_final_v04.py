"""Native Stunts Superbird NASCAR, supplied 3SH + cockpit V03.
No raster model substitution: all markings are native type-2 line primitives.
"""
from pathlib import Path
import struct,json,hashlib,copy,re,shutil,zipfile,math
import numpy as np
from PIL import Image,ImageDraw,ImageFont
R=Path('/workspace/scratch/4ce29ee9399e')
O=R/'outputs/superbird_final_v04'; O.mkdir(parents=True,exist_ok=True)
P=O/'APERCUS';P.mkdir(exist_ok=True)
S=O/'SOURCES';S.mkdir(exist_ok=True)
V3=R/'outputs/superbird_cockpit_v03'
PAL=np.array(json.loads((R/'work/bird_cockpit/palette.json').read_text()),np.uint8)
def readres(p):
 d=Path(p).read_bytes();sz,n=struct.unpack_from('<IH',d);assert sz==len(d)
 names=[d[6+4*i:10+4*i].decode('ascii') for i in range(n)]
 ofs=struct.unpack_from('<'+'I'*n,d,6+4*n);st=6+8*n
 return names,{k:d[st+ofs[i]:st+min([x for x in ofs if x>ofs[i]]+[len(d)-st])] for i,k in enumerate(names)}
def writeres(names,blocks):
 b=b'';ofs=[]
 for k in names:
  ofs.append(len(b));b+=blocks[k];b+=b'\0'*(-len(b)%16)
 return struct.pack('<IH',6+8*len(names)+len(b),len(names))+b''.join(k.encode() for k in names)+struct.pack('<'+'I'*len(names),*ofs)+b
def bitmap(b):
 w,h,cx,cy,x,y=struct.unpack_from('<6h',b)
 return np.frombuffer(b[16:16+w*h],np.uint8).reshape(h,w).copy(),(x,y),(cx,cy)
def bmp(a,xy,anchor=(0,0)):
 h,w=a.shape;return struct.pack('<6h',w,h,*anchor,*xy)+bytes([1,2,4,8])+a.tobytes()
def pim(a):
 im=Image.fromarray(np.asarray(a,np.uint8),'P');im.putpalette(PAL.ravel().tolist());return im
def quant(im):
 a=np.asarray(im.convert('RGB'));flat=a.reshape(-1,3).astype(np.int32);c=PAL[:255].astype(np.int32);res=np.empty(len(flat),np.uint8)
 for i in range(0,len(flat),2048):res[i:i+2048]=((flat[i:i+2048,None,:]-c[None,:,:])**2).sum(2).argmin(1)
 return res.reshape(a.shape[:2])

# DASH has neither boot nor knob. GBOX (in STDA, as required by the native
# resource table) retains the top-down boot, and STDB supplies GNOB/GNAB.
na,A=readres(V3/'STDABIRD.VSH');nb,B=readres(V3/'STDBBIRD.VSH');nc,C=readres(V3/'CARBIRD.RES')
dash,dxy,da=bitmap(A['dash']);gx,gy,gw,gh=256,162,64,38
bare=quant(Image.open(R/'generated_images/exec-31487771-2513-403c-89bc-6922f132a7b3.png').convert('RGBA').resize((320,200),Image.Resampling.LANCZOS))
dash[gy-122:gy-122+gh,gx:gx+gw]=bare[gy:gy+gh,gx:gx+gw]
A['dash']=bmp(dash,dxy,da)
assert A['gbox']==readres(V3/'STDABIRD.VSH')[1]['gbox']
assert all(A[k]==readres(V3/'STDABIRD.VSH')[1][k] for k in na if k!='dash')
assert B==readres(V3/'STDBBIRD.VSH')[1]
sim=bytearray(C['simd']);oldsim=bytes(sim)
_,street=readres(R/'work/superbird_original/CARM1PL.RES')
# Restore the donor Superbird eye/camera height; retain engine and transmission.
sim[208:210]=street['simd'][208:210];C['simd']=bytes(sim)
assert sim[:208]==oldsim[:208] and sim[210:]==oldsim[210:]
assert b'by Alain il Professore' in C['edes']
for name,order,blocks in [('STDABIRD.VSH',na,A),('STDBBIRD.VSH',nb,B),('CARBIRD.RES',nc,C)]:
 (O/name).write_bytes(writeres(order,blocks))
 for k,v in blocks.items():assert readres(O/name)[1][k][:len(v)]==v

def readshape(b):
 nv,np_,nj,res=b[:4];assert res==0
 v=[tuple(struct.unpack_from('<hhh',b,4+6*i)) for i in range(nv)]
 off=4+6*nv;c1=struct.unpack_from('<'+'I'*np_,b,off);c2=struct.unpack_from('<'+'I'*np_,b,off+4*np_);off+=8*np_;pr=[]
 for i in range(np_):
  t,f=b[off:off+2];ne=t if t<=10 else 2 if t==11 else 6
  mat=list(b[off+2:off+2+nj]);ids=list(b[off+2+nj:off+2+nj+ne]);assert len(ids)==ne and max(ids)<nv
  pr.append(dict(t=t,f=f,m=mat,ids=ids,c1=c1[i],c2=c2[i],tag='source',source=i));off+=2+nj+ne
 assert not any(b[off:]);return dict(v=v,p=pr,nj=nj)
def writeshape(m):
 v,p=m['v'],m['p'];assert len(v)<=255 and len(p)<=255 and m['nj']==8
 b=bytes([len(v),len(p),8,0])+b''.join(struct.pack('<hhh',*x) for x in v)
 b+=struct.pack('<'+'I'*len(p),*[x['c1'] for x in p])+struct.pack('<'+'I'*len(p),*[x['c2'] for x in p])
 for x in p:
  assert len(x['m'])==8 and all(0<=i<len(v) for i in x['ids'])
  b+=bytes([x['t'],x['f']]+x['m']+x['ids'])
 return b+b'\0\0\0'

# Materials are native material IDs, not raw VGA colour indices.
# Four tones per job: dark, main, upper surface, metal/body trim.
PAINTS=[('Cyan Petty blue',[64,65,66,65]),('Rouge',[52,53,54,53]),('Noir',[44,39,38,39]),('Rose',[116,37,117,37]),('Vert',[68,69,70,69]),('Bronze',[33,25,26,25]),('Jaune',[60,61,62,61]),('Violet',[73,74,75,74])]
def paint(old):
 if old in [48,49,50,51]:
  slot={49:0,50:1,51:2,48:3}[old];return [p[1][slot] for p in PAINTS]
 return [old]*8
order,blocks=readres(R/'work/superbird_original/STM1PL.3SH');original={k:readshape(blocks[k]) for k in order}

# A deliberately economical stick 43: eight independent native segments.
segments=[((0,0),(0,.5)),((0,.5),(.34,.5)),((.34,0),(.34,1)),
          ((.57,0),(1,0)),((1,0),(1,1)),((1,1),(.57,1)),((.57,.5),(1,.5))]
def addpoint(m,pt):
 pt=tuple(int(round(z)) for z in pt)
 try:return m['v'].index(pt)
 except ValueError:m['v'].append(pt);return len(m['v'])-1
def line(m,p,q,mat,tag,parent=None,attached=False):
 ids=[addpoint(m,p),addpoint(m,q)]
 if ids[0]==ids[1]:return None
 return dict(t=2,f=2 if attached else 0,m=[mat]*8,ids=ids,c1=parent['c1'] if parent else 0xffffffff,c2=0xffffffff,tag=tag)
def number(m,fn,parent):
 return [line(m,fn(*a),fn(*b),15,'number43',parent,True) for a,b in segments]
def quad(m,pts,mat,tag):
 return dict(t=4,f=1,m=[mat]*8,ids=[addpoint(m,q) for q in pts],c1=0xffffffff,c2=0xffffffff,tag=tag)

def nascar_detailed(src):
 m=copy.deepcopy(src);m['nj']=8;new=[]
 # Remove road front grille, tail lamps, hood intake, fine road fender vents.
 # Rebuild the hood and full-height doors, freeing vertices for native markings.
 remove=set([7,8,9,18,44,45,104,105]+list(range(10,18))+list(range(78,86)))
 for p in m['p']:
  i=p['source']
  if i in remove:continue
  p['m']=paint(p['m'][0])
  if i==32:p['ids']=[101,102,88,114]
  if i==33:p['ids']=[115,89,107,108]
  if i==103:p['ids']=[173,185,184,176]
  # Open right window; native grate on the left is the NASCAR window net.
  if i==30:p['m']=[118]*8
  if i==31:p['m']=[23]*8;p['f']=1;p['c1']=p['c2']=0xffffffff
  # Windshield / backlight remain patterned glass, allowing cage to show through.
  if i in [88,89,90,93]:p['m']=[122]*8
  if i in [96,97]:p['m']=[118]*8
  new.append(p)
  if i==32:new+=number(m,lambda u,v:(322,75+(1-v)*170,210-u*375),p)
  if i==33:new+=number(m,lambda u,v:(-322,75+(1-v)*170,-165+u*375),p)
  if i==100:new+=number(m,lambda u,v:(-170+u*340,422,-310+v*330),p)
  if i==103:new+=number(m,lambda u,v:(-120+u*240,262,390+v*180),p)
 # Compact welded interior cage, shown through the open windows.
 cage=[((-205,85,-185),(-205,400,-185)),((205,85,-185),(205,400,-185)),
       ((-205,400,-185),(205,400,-185)),((-205,400,-185),(205,85,-185)),
       ((-205,400,-185),(-205,400,55)),((205,400,-185),(205,400,55)),
       ((-205,400,55),(205,400,55)),((-205,400,55),(-280,85,220)),
       ((205,400,55),(280,85,220)),((-280,85,220),(-205,85,-185)),
       ((280,85,220),(205,85,-185))]
 for a,b in cage:new.append(line(m,a,b,65,'cage'))
 # Dark cockpit floor supplies depth behind the native left window net.
 new.append(quad(m,[(-280,65,210),(280,65,210),(280,65,-200),(-280,65,-200)],39,'cockpit_floor'))
 m['p']=[p for p in new if p is not None]
 # Compact only unused vertices. Native bound box and wheel slots 0..31 stay fixed.
 used=set(range(32))|{i for p in m['p'] for i in p['ids']};indices=sorted(used);remap={k:i for i,k in enumerate(indices)}
 m['v']=[m['v'][i] for i in indices]
 for p in m['p']:p['ids']=[remap[i] for i in p['ids']]
 assert m['v'][:32]==src['v'][:32]
 assert len(m['v'])<=255 and len(m['p'])<=255,(len(m['v']),len(m['p']))
 return m
models={};models['car0']=nascar_detailed(original['car0'])
# Detailed driving model: original bounds / all wheel vertices retained exactly;
# other source points keep the author's corresponding low-scale coordinates.
models['car1']=copy.deepcopy(models['car0'])
lookup={tuple(v):original['car1']['v'][i] for i,v in enumerate(original['car0']['v'])}
models['car1']['v']=[lookup.get(tuple(v),tuple(int(round(z/20)) for z in v)) for v in models['car0']['v']]
assert models['car1']['v'][:32]==original['car1']['v'][:32]

# Far-distance shape: retain the original 24 vertices, add simplified 43 only
# where its low-scale outline can still resolve, and the characteristic high wing.
m=copy.deepcopy(original['car2']);m['nj']=8
for p in m['p']:p['m']=paint(p['m'][0])
# Add a proper high wing to the distant silhouette (missing on the donor car2).
for x in [-16,16]:
 p=quad(m,[(x,14,-35),(x,26,-45),(x,26,-42),(x,14,-30)],65,'far_wing');p['m']=paint(50);m['p'].append(p)
p=quad(m,[(-16,26,-45),(16,26,-45),(16,26,-42),(-16,26,-42)],66,'far_wing');p['m']=paint(51);m['p'].append(p)
for x in [-17,17]:
 parent={'c1':0xffffffff}
 fn=(lambda u,v:(x,4+(1-v)*8,-8+u*17)) if x<0 else (lambda u,v:(x,4+(1-v)*8,9-u*17))
 # Free-standing sorted lines here: parentage is unavailable on this coarse mesh.
 for p in number(m,fn,parent):p['f']=0;m['p'].append(p)
models['car2']=m
# Its new wing and side markings extend beyond the donor's coarse bounds.
models['car2']['v'][:8]=[(x//abs(x)*17,26 if y else 0,z) for x,y,z in models['car2']['v'][:8]]
for k in ['exp0','exp1','exp2','exp3']:
 m=copy.deepcopy(original[k]);m['nj']=8
 for p in m['p']:p['m']=paint(p['m'][0])
 models[k]=m
newblocks={k:writeshape(models[k]) for k in order}
for k in ['car0','car1','car2']:
 points=np.array(models[k]['v']);bounds=points[:8]
 assert np.all(points[8:].min(0)>=bounds.min(0)) and np.all(points[8:].max(0)<=bounds.max(0)),k
(O/'STBIRD.3SH').write_bytes(writeres(order,newblocks))
_,again=readres(O/'STBIRD.3SH')
for k in order:
 check=readshape(again[k]);assert check['v']==models[k]['v']
 assert check['nj']==8 and len(check['p'])==len(models[k]['p'])
 assert all(p['m']==q['m'] and p['ids']==q['ids'] and p['t']==q['t'] for p,q in zip(check['p'],models[k]['p']))
(S/'MODELE_NASCAR.json').write_text(json.dumps(models,indent=2))
print(json.dumps({k:{'vertices':len(m['v']),'primitives':len(m['p']),'paintjobs':m['nj']} for k,m in models.items()},indent=2))

# A small z-buffer renderer, for review of the ACTUAL exported geometry.
# It is a technical preview, not the Stunts rasterizer or a native game test.
conf=(R/'work/stressed-src/resources/conf/defaults.conf').read_text()
matcols=list(map(int,re.findall(r'\d+',conf.split('[materials]')[1].split('colors=')[1].split('patterns=')[0])))
patterns=list(map(int,re.findall(r'\d+',conf.split('patterns=')[1].split('\n\n')[0])))
FONT='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
def font(n):return ImageFont.truetype(FONT,n)
def render(m,job=0,size=(700,420),cam=(-2.8,1.6,3.4),label=None):
 w,h=size;cam=np.array(cam,float);cam/=np.linalg.norm(cam)
 right=np.cross([0,1,0],cam);right/=np.linalg.norm(right);up=np.cross(cam,right)
 verts=np.array(m['v'],float);verts[:,1]*=.8
 # scale the far model up for an equivalent review image
 if abs(verts[:,2]).max()<100:verts*=20
 visible=verts[8:] if len(verts)>8 else verts
 xs,ys=visible@right,visible@up
 center=right*((xs.min()+xs.max())/2)+up*((ys.min()+ys.max())/2)
 scale=min((w-70)/(np.ptp(xs)+100),(h-100)/(np.ptp(ys)+100))
 def proj(points):
  rel=np.asarray(points)-center
  return np.array([w/2+(rel@right)*scale,h*.51-(rel@up)*scale,rel@cam]).T
 screen=proj(verts);img=np.zeros((h,w,3),np.uint8);img[:]=[20,28,39];depth=np.full((h,w),-1e9)
 def tri(pts,color,pat=0,bias=0):
  a,b,c=pts;lo=np.maximum(np.floor(np.min(pts[:,:2],axis=0)).astype(int),0);hi=np.minimum(np.ceil(np.max(pts[:,:2],axis=0)).astype(int),[w-1,h-1])
  if np.any(hi<lo):return
  xx,yy=np.meshgrid(np.arange(lo[0],hi[0]+1),np.arange(lo[1],hi[1]+1))
  den=(b[1]-c[1])*(a[0]-c[0])+(c[0]-b[0])*(a[1]-c[1])
  if abs(den)<1e-7:return
  u=((b[1]-c[1])*(xx-c[0])+(c[0]-b[0])*(yy-c[1]))/den
  v=((c[1]-a[1])*(xx-c[0])+(a[0]-c[0])*(yy-c[1]))/den;z=u*a[2]+v*b[2]+(1-u-v)*c[2]+bias
  sl=depth[lo[1]:hi[1]+1,lo[0]:hi[0]+1];mask=(u>=-.001)&(v>=-.001)&(u+v<=1.001)&(z>=sl)
  if pat:mask &= ((xx%3==0)|(yy%3==0)) if pat==2 else ((xx+yy)%3==0)
  sl[mask]=z[mask];img[lo[1]:hi[1]+1,lo[0]:hi[0]+1][mask]=color
 def poly(points,color,pat=0):
  points=np.asarray(points)
  for j in range(1,len(points)-1):tri(points[[0,j,j+1]],color,pat)
 def segment(a,b,color,bias=1):
  n=max(int(np.max(np.abs(b[:2]-a[:2]))*2),1);q=np.linspace(a,b,n+1)
  for x,y,z in q:
   x,y=int(round(x)),int(round(y))
   if 0<=x<w and 0<=y<h and z+bias>=depth[y,x]-1:
    img[y,x]=color;depth[y,x]=max(depth[y,x],z+bias)
 deferred=[]
 for p in m['p']:
  mat=p['m'][job]
  if mat==118:continue
  color=PAL[matcols[mat]];pts=verts[p['ids']];ps=screen[p['ids']]
  if p['t']==2:deferred.append((p,ps,color));continue
  if p['t']==12:
   a,b=pts[0],pts[3];ry=np.linalg.norm(pts[1]-a);rz=np.linalg.norm(pts[2]-a)
   circles=[]
   for c in [a,b]:circles.append(np.array([c+[0,ry*math.cos(t),rz*math.sin(t)] for t in np.linspace(0,2*math.pi,17)[:-1]]))
   rings=[proj(c) for c in circles]
   for j in range(16):poly(np.array([rings[0][j],rings[0][(j+1)%16],rings[1][(j+1)%16],rings[1][j]]),[25,27,32])
   for c,ring in zip([a,b],rings):
    poly(ring,[18,20,24]);rim=proj(np.array([c+[0,ry*.5*math.cos(t),rz*.5*math.sin(t)] for t in np.linspace(0,2*math.pi,17)[:-1]]));poly(rim,[62,64,95])
   continue
  if 3<=p['t']<=10:
   normal=np.cross(pts[1]-pts[0],pts[2]-pts[0]);n=np.linalg.norm(normal)
   shade=.89+.11*abs(normal@np.array([.3,.7,.65])/n) if n else 1
   poly(ps,np.clip(color*shade,0,255).astype(np.uint8),patterns[mat] if mat<len(patterns) else 0)
 for p,ps,color in deferred:segment(ps[0],ps[1],color,5 if p['tag']=='number43' else 0)
 im=Image.fromarray(img);d=ImageDraw.Draw(im)
 if label:d.text((20,18),label,font=font(19),fill=(235,240,248))
 d.text((20,h-25),'Apercu du fichier 3SH - hors moteur Stunts',font=font(12),fill=(149,166,183))
 return im
render(models['car0'],label='43 / PLYMOUTH SUPERBIRD NASCAR').save(P/'MODELE_PETTY_BLUE.png')
contact=Image.new('RGB',(1400,4*390),(14,20,29))
for i,(name,_) in enumerate(PAINTS):contact.paste(render(models['car0'],i,(700,390),label=f'{i+1}. {name}'),((i%2)*700,(i//2)*390))
contact.save(P/'HUIT_PAINTJOBS.png')
for side,cam in [('GAUCHE',(-3.8,1,0)),('DROITE',(3.8,1,0)),('TOIT',(-.1,5,1)),('ARRIERE',(-2.8,1.8,-3.8))]:render(models['car0'],0,cam=cam,label=side).save(P/('MODELE_'+side+'.png'))
render(models['car1'],label='car1 / modele en course').save(P/'MODELE_CAR1.png')
render(models['car2'],label='car2 / modele lointain').save(P/'MODELE_CAR2.png')

# Native dashboard compositor, idle -> shift -> idle. Exported DASH is used.
def needle(a,p,q,c=38):
 im=Image.fromarray(a,'L');ImageDraw.Draw(im).line([tuple(p),tuple(q)],fill=c);a[:]=np.array(im)
def cockpit(whl='whl2',gear=0,moving=False):
 im=Image.new('L',(320,200),130);d=ImageDraw.Draw(im);d.rectangle((0,75,320,130),fill=99);d.polygon([(147,75),(173,75),(295,122),(25,122)],fill=25);d.line([(160,75),(160,122)],fill=15)
 frame=np.array(im);frame[:10]=bitmap(A['roof'])[0];art,_,_=bitmap(A['dast']);mask=bitmap(A['dasm'])[0];frame[10:122]=(frame[10:122]&mask)|art
 frame[122:]=bitmap(A['dash'])[0]
 arr,(x,y),_=bitmap(A[whl]);h,w=arr.shape;frame[y:y+h,x:x+w]=arr
 panel,(ix,iy),_=bitmap(A['ins2'])
 for off,pt,idx in [(0x128,0x12e,52),(0x1fe,0x204,39)]:needle(panel,struct.unpack_from('<hh',sim,off),sim[pt+2*idx:pt+2*idx+2])
 if whl!='whl2':
  k=whl[-1];panel=(panel&bitmap(A['inm'+k])[0])|bitmap(A['ins'+k])[0]
 h,w=panel.shape;frame[iy:iy+h,ix:ix+w]=panel
 if moving:
  frame[gy:gy+gh,gx:gx+gw]=bitmap(A['gbox'])[0];knob,_,anchor=bitmap(B['gnob']);mask=bitmap(B['gnab'])[0]
  x,y=struct.unpack_from('<hh',sim,0x1c+4*gear);x+=gx-anchor[0];y+=gy-anchor[1];h,w=knob.shape
  frame[y:y+h,x:x+w]=(frame[y:y+h,x:x+w]&mask)|knob
 return frame
idle=cockpit();assert np.array_equal(idle[gy:gy+gh,gx:gx+gw],bare[gy:gy+gh,gx:gx+gw])
assert not np.array_equal(idle,cockpit(gear=1,moving=True))
pics=[]
for i,(gear,moving,label) in enumerate([(0,False,'REPOS : ni soufflet ni pommeau'),(0,True,'CHANGEMENT : soufflet + pommeau'),(1,True,'PASSAGE DU RAPPORT 1'),(0,True,'NEUTRE'),(2,True,'PASSAGE DU RAPPORT 2'),(0,False,'REPOS : levier invisible')]):
 frame=pim(cockpit(gear=gear,moving=moving)).convert('RGB').resize((640,480),Image.Resampling.NEAREST)
 canvas=Image.new('RGB',(640,520),(12,18,27));canvas.paste(frame,(0,20));dr=ImageDraw.Draw(canvas);dr.text((12,3),label,font=font(13),fill='white');dr.text((12,502),'Composition des ressources - hors moteur Stunts',font=font(12),fill=(180,195,210));pics.append(canvas)
pics[0].save(P/'LEVIER_REPOS_CHANGEMENT.gif',save_all=True,append_images=pics[1:],duration=[1800,700,700,500,700,1800],loop=0,disposal=2)
pim(idle).convert('RGB').resize((960,720),Image.Resampling.NEAREST).save(P/'COCKPIT_AU_REPOS.png')
pim(cockpit(gear=1,moving=True)).convert('RGB').resize((960,720),Image.Resampling.NEAREST).save(P/'COCKPIT_CHANGEMENT.png')
for g in range(1,5):
 for h in range(1,5):
  assert np.array_equal(cockpit(gear=g,moving=False),cockpit(gear=h,moving=False))
for whl in ['whl1','whl2','whl3']:assert cockpit(whl).shape==(200,320)
for k in ['gnob','gnab']:
 a,_,_=bitmap(B[k]);pim(a).save(S/(k+'.png'),transparency=255)
pim(bitmap(A['dash'])[0]).save(S/'dash.png');pim(bitmap(A['gbox'])[0]).save(S/'gbox.png')

shutil.copy2(R/'outputs/superbird_v01/Plymouth_Superbird_NASCAR_Torque.xlsx',S/'Plymouth_Superbird_NASCAR_Torque.xlsx')
shutil.copy2(R/'outputs/superbird_v01/TORQUE_103.csv',S/'TORQUE_103.csv')
shutil.copy2(R/'outputs/superbird_v01/LIRE_MOI.txt',S/'NOTES_MOTEUR.txt')
shutil.copy2(V3/'PROMPTS_ARTISTIQUES.txt',S/'PROMPTS_ARTISTIQUES.txt')
(S/'build_final_v04.py').unlink(missing_ok=True)
audit={'version':'Final V04','author':'by Alain il Professore','date':'2026-10-26','in_game_test_performed':False,
 'model_source':'Superbird.zip / STM1PL.3SH','original_car_credit':'By Alan Rotoi (CARM1PL.RES / EDES)','model_source_sha256':hashlib.sha256((R/'work/superbird_original/STM1PL.3SH').read_bytes()).hexdigest(),
 'paintjobs':[{'number':i+1,'name':n,'native_material_tones':m} for i,(n,m) in enumerate(PAINTS)],
 'shapes':{k:{'vertices':len(m['v']),'primitives':len(m['p']),'paintjobs':8,'line_markings':sum(p['tag']=='number43' for p in m['p'])} for k,m in models.items()},
 'wheel_vertex_slots_preserved':True,'original_silhouette_preserved':True,'marking_type':'native line primitives, white material 15',
 'cockpit':{'dash_no_knob':True,'dash_no_boot':True,'boot_only_in_gbox':True,'gnob_gnab_in_stdb':True,'gbox_in_stda':True,'wheel_and_gloves_preserved':True,'gear_transition_pairs_checked':16,'all_idle_states_identical':True},
 'simd':{'engine_and_gears_unchanged':sim[:0xc8]==oldsim[:0xc8],'changed_offsets':[i for i,(a,b) in enumerate(zip(sim,oldsim)) if a!=b],'car_height_restored_from_superbird':struct.unpack_from('<h',sim,208)[0],'edes_preserved':C['edes']==readres(V3/'CARBIRD.RES')[1]['edes']},
 'validation':'All containers parsed, shapes round-tripped, indices/material counts/limits/zero padding checked; cockpit idle and 16 shift pairs composited. Technical previews only.',
 'sha256':{n:hashlib.sha256((O/n).read_bytes()).hexdigest() for n in ['CARBIRD.RES','STBIRD.3SH','STDABIRD.VSH','STDBBIRD.VSH']}}
(S/'AUDIT_FINAL.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2))
(O/'LIRE_MOI.txt').write_text('''PLYMOUTH SUPERBIRD NASCAR 1970 — PACK FINAL V04
by Alain il Professore

INSTALLATION — STUNTS 1.1
Copier ensemble ces quatre fichiers à la racine du jeu :
CARBIRD.RES / STBIRD.3SH / STDABIRD.VSH / STDBBIRD.VSH.
Sauvegarder vos anciennes versions. Écarter les anciens STBIRD.P3S,
STDABIRD.PVS et STDBBIRD.PVS s'ils existent : leur priorité peut empêcher
le chargement de ces nouvelles ressources non compressées.
Sélectionner Plymouth Superbird et parcourir les huit peintures.

PEINTURES DANS L'ORDRE DEMANDÉ
1 Cyan Petty blue ; 2 Rouge ; 3 Noir ; 4 Rose ; 5 Vert ; 6 Bronze ;
7 Jaune ; 8 Violet. Palette et matériaux natifs de Stunts.
Le cyan est une interprétation Petty blue dans la palette limitée du jeu.

MODÈLE 3D
Base : votre STM1PL.3SH provenant de Superbird.zip ; la voiture source porte
le crédit « By Alan Rotoi » dans son CARM1PL.RES. Conversion NASCAR et
cockpit : by Alain il Professore. Silhouette, nez long,
grand aileron et positions natives des roues conservés. Les niveaux car0
(sélection), car1 (course) et car2 (lointain) ont huit peintures cohérentes,
ainsi que les débris d'accident exp0 à exp3.
Numéros 43 en vrais segments blancs sur les deux flancs, le toit et le capot
des modèles détaillés ; numéros latéraux simplifiés à distance.
Calandre routière, feux arrière et prise d'air de capot retirés au profit
des panneaux peints ; ouverture latérale, filet noir à gauche et arceau.
Les petits reliefs des ouïes d'ailes sont simplifiés pour respecter les
limites du format. Décoration de course stylisée, sans décalcomanies sponsors.

LEVIER — CORRECTION DEMANDÉE
DASH ne contient ni soufflet ni pommeau. Son sol est restauré à nu.
GBOX contient le soufflet noir en vue sommitale et apparaît pendant le
changement de rapport. GNOB/GNAB ajoutent le pommeau blanc mobile vu du dessus.
Après le délai de changement, le moteur restaure DASH : le levier disparaît.
Dans le format natif, GBOX se trouve bien dans STDABIRD.VSH ; GNOB et GNAB
sont dans STDBBIRD.VSH. Les noms et les emplacements attendus sont conservés.
Le grand volant décalé à droite, les deux mains gantées et les trois poses,
les instruments visibles à travers le volant, le rétroviseur, l'arceau et
les ouvertures du filet sont conservés de la V03.

CARBIRD.RES
Moteur NASCAR, boîte quatre rapports, tables de couple et réglages du
cockpit conservés. Hauteur de vue rétablie à 21, valeur du CARM1PL.RES
joint, pour accompagner sa carrosserie. La fiche EDES et la signature
« by Alain il Professore » restent identiques.
La courbe moteur demeure une reconstruction estimée, et non une mesure au
banc d'une Superbird NASCAR. Le classeur Excel et ses notes sont dans SOURCES.

VÉRIFICATION
Les quatre conteneurs et chaque forme 3D sont relus ; nombres de sommets,
primitives, indices, huit matériaux par primitive, cases réservées des roues,
terminaisons et masques GNAB sont contrôlés. Composition du cockpit au repos,
des trois positions du volant et des 16 couples de rapports : aucune trace
de levier dans le fond au repos. Paramètres moteur et texte comparés à V03.
Les images et le GIF dans APERCUS sont produits à partir des ressources
exportées ; ce sont des rendus de contrôle, pas des captures du jeu.
Aucun essai dans Stunts natif effectué ici. Le pilotage, les animations et
l'affichage en replay restent à valider en jeu.

PROVENANCE TECHNIQUE
https://github.com/dstien/stressed — sérialisation des formes, palette et matériaux.
https://github.com/CommonLoon102/restunts-bb11 — dashboard.c, simd.c et externs.h.
https://wiki.stunts.hu/wiki/Resource_file_format
https://wiki.stunts.hu/wiki/Shape_materials
Règle GNOB/GNAB et documents de construction de votre projet.
''',encoding='utf-8')
archive=O/'SUPERBIRD_NASCAR_FINAL_V04.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for f in sorted(O.rglob('*')):
  if f.is_file() and f!=archive:z.write(f,str(f.relative_to(O)))
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
print(json.dumps({'files':audit['sha256'],'zip_bytes':archive.stat().st_size,'validation':'passed'},indent=2))
